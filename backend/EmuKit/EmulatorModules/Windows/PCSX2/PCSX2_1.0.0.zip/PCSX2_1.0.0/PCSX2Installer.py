from __future__ import annotations

import json
import shutil
import subprocess
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from _PCSX2Common import *


def result(success: bool, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "pcsx2", "operation": "install", "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def release_asset(info: dict[str, Any]) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    source = info["Source"]
    repository = str(source["Repository"])
    release_tag = str(source["ReleaseTag"])
    asset_name = str(source["Asset"])
    url = f"https://api.github.com/repos/{repository}/releases/tags/{release_tag}"
    try:
        release = request_json(url)
    except urllib.error.HTTPError as exc:
        return None, result(False, "download_failed", f'PCSX2 pinned release "{release_tag}" could not be retrieved from GitHub.', "github_release_http_error", {"http_status": exc.code, "url": url})
    except Exception as exc:
        return None, result(False, "download_failed", "PCSX2 release information could not be retrieved from GitHub.", "github_release_lookup_failed", str(exc))
    if str(release.get("tag_name", "")) != release_tag or bool(release.get("prerelease")):
        return None, result(False, "download_failed", "The pinned PCSX2 release metadata no longer matches the module contract.", "release_metadata_mismatch", {"expected_tag": release_tag, "actual_tag": release.get("tag_name"), "prerelease": release.get("prerelease")})
    for asset in release.get("assets", []):
        if not isinstance(asset, dict) or asset.get("name") != asset_name:
            continue
        browser_url = asset.get("browser_download_url")
        if not isinstance(browser_url, str):
            continue
        digest = str(asset.get("digest", ""))
        expected_digest = "sha256:" + str(source["SHA256"]).lower()
        if digest and digest.lower() != expected_digest:
            return None, result(False, "pinned_release_changed", "The official PCSX2 asset checksum no longer matches the module pin.", "asset_digest_changed", {"expected": expected_digest, "current": digest})
        size = asset.get("size")
        if isinstance(size, int) and size != int(source["Size"]):
            return None, result(False, "pinned_release_changed", "The official PCSX2 asset size no longer matches the module pin.", "asset_size_changed", {"expected": source["Size"], "current": size})
        return {"url": browser_url, "digest": digest, "size": size, "published_at": release.get("published_at")}, None
    return None, result(False, "download_failed", f'Pinned PCSX2 release "{release_tag}" does not contain the expected asset "{asset_name}".', "release_asset_missing")


def download_file(url: str, destination: Path, expected_sha256: str, expected_size: int | None, progress: ProgressCallback | None = None) -> dict[str, Any] | None:
    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
        request = urllib.request.Request(url, headers={"User-Agent": "ProjectHomelab-EmuKit-PCSX2/1.0.0"})
        with urllib.request.urlopen(request, timeout=120) as response, destination.open("wb") as output:
            raw_length = response.headers.get("Content-Length")
            total = int(raw_length) if raw_length and raw_length.isdigit() else expected_size
            downloaded = 0
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)
                downloaded += len(chunk)
                percent = min(100, int(downloaded * 100 / total)) if total else None
                emit_progress(progress, percent, "Downloading")
        actual_size = destination.stat().st_size
        if expected_size is not None and actual_size != int(expected_size):
            return result(False, "download_failed", "A downloaded file failed size validation.", "download_size_mismatch", {"url": url, "expected_size": expected_size, "actual_size": actual_size})
        actual_sha256 = hash_file(destination, "sha256").lower()
        if actual_sha256 != expected_sha256.lower():
            return result(False, "download_failed", "A downloaded file failed SHA-256 validation.", "download_hash_mismatch", {"url": url, "expected_sha256": expected_sha256.lower(), "actual_sha256": actual_sha256})
        emit_progress(progress, 100, "Downloading")
        return None
    except urllib.error.HTTPError as exc:
        return result(False, "download_failed", "A required file could not be downloaded.", "download_http_error", {"url": url, "http_status": exc.code})
    except Exception as exc:
        return result(False, "download_failed", "A required file could not be downloaded.", "download_failed", {"url": url, "exception": str(exc)})


def stage_bios(info: dict[str, Any], destination: Path, progress: ProgressCallback | None = None) -> tuple[list[Path] | None, dict[str, Any] | None]:
    emit_progress(progress, 2, "Reading resource catalogue")
    try:
        catalog = load_resource_catalog(info)
    except Exception as exc:
        return None, result(False, "resource_failed", "The EmuKit resource catalogue could not be loaded.", "resource_catalog_unavailable", str(exc))
    specifications = bios_files(info)
    if not specifications:
        return None, result(False, "resource_failed", "PCSX2 has no BIOS resources defined.", "bios_resources_missing")
    try:
        for specification in specifications:
            validate_catalog_entry(catalog, specification)
    except Exception as exc:
        return None, result(False, "resource_failed", "A required PlayStation 2 BIOS resource no longer matches the PCSX2 module contract.", "resource_catalog_mismatch", str(exc))
    staged: list[Path] = []
    total = len(specifications)
    for index, specification in enumerate(specifications):
        target = destination / str(specification["InstallAs"])
        start = round(index * 100 / total)
        end = round((index + 1) * 100 / total)
        error = download_file(
            resource_url(info, str(specification["Path"])),
            target,
            str(specification["SHA256"]),
            int(specification["Size"]),
            scaled_progress(progress, start, end),
        )
        if error is not None:
            return None, error
        actual_md5 = hash_file(target, "md5").lower()
        if actual_md5 != str(specification["MD5"]).lower():
            return None, result(False, "resource_failed", "A downloaded PlayStation 2 BIOS resource failed MD5 validation.", "bios_md5_mismatch", {"path": specification["Path"], "expected": specification["MD5"], "actual": actual_md5})
        staged.append(target)
    selected_spec = selected_bios_specification(info)
    if selected_spec is None:
        return None, result(False, "resource_failed", "PCSX2 has no valid selected BIOS definition.", "selected_bios_missing")
    selected_path = destination / str(selected_spec["InstallAs"])
    romver = parse_romver(selected_path)
    if romver is None:
        return None, result(False, "resource_failed", "The selected PlayStation 2 BIOS failed ROMVER validation.", "bios_romver_invalid", {"path": selected_spec["Path"]})
    return staged, None


def install_bios(staged: list[Path]) -> list[str]:
    INSTALLED_BIOS_DIR.mkdir(parents=True, exist_ok=True)
    copied: list[str] = []
    for source in staged:
        target = INSTALLED_BIOS_DIR / source.name
        shutil.copy2(source, target)
        copied.append(target.name)
    return copied


def write_minimal_config(selected_bios_name: str) -> None:
    INIS_DIR.mkdir(parents=True, exist_ok=True)
    config = f"[UI]\nSettingsVersion = 1\nSetupWizardIncomplete = false\n\n[Folders]\nBios = bios\n\n[Filenames]\nBIOS = {selected_bios_name}\n"
    CONFIG_PATH.write_text(config, encoding="utf-8")


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, "Checking host")
    supported, reason = is_supported_host()
    if not supported:
        return result(False, "unsupported", reason or "Unsupported host.", "unsupported_host")
    seven_zip = seven_zip_executable()
    if seven_zip is None:
        return result(False, "dependency_missing", "PCSX2 requires the EmuKit Core 7-Zip dependency, but no usable 7-Zip executable was found.", "core_dependency_missing", {"dependency": "7zip"})
    info = load_info()
    version = emulator_version(info)
    if EMULATOR_DIR.exists():
        return result(False, "install_failed", "The PCSX2 emulator directory already exists. Use repair for a clean reinstall.", "emulator_already_exists", {"path": str(EMULATOR_DIR)})
    EMULATOR_DIR.mkdir(parents=True)
    temp = EMULATOR_DIR / ".install"
    bios_stage = temp / "bios"
    extract = temp / "extracted"
    archive_path = temp / str(info["Source"]["Asset"])
    bios_stage.mkdir(parents=True)
    extract.mkdir()
    install_complete = False
    try:
        emit_progress(progress, 7, "Verifying pinned release")
        asset, release_error = release_asset(info)
        if release_error is not None:
            return release_error
        assert asset is not None
        emit_progress(progress, 12, "Downloading PlayStation 2 BIOS resources")
        staged_bios, bios_error = stage_bios(info, bios_stage, scaled_progress(progress, 12, 35))
        if bios_error is not None:
            return bios_error
        assert staged_bios is not None
        source = info["Source"]
        emit_progress(progress, 38, "Downloading PCSX2")
        archive_error = download_file(
            str(asset["url"]),
            archive_path,
            str(source["SHA256"]),
            int(source["Size"]),
            scaled_progress(progress, 38, 70),
        )
        if archive_error is not None:
            return archive_error
        emit_progress(progress, 73, "Extracting PCSX2")
        completed = subprocess.run([str(seven_zip), "x", str(archive_path), f"-o{extract}", "-y"], capture_output=True, text=True, check=False)
        if completed.returncode != 0:
            return result(False, "extract_failed", "The PCSX2 archive downloaded successfully but could not be extracted.", "archive_extract_failed", {"exit_code": completed.returncode, "stdout": completed.stdout[-4000:], "stderr": completed.stderr[-4000:]})
        executable = next(extract.rglob("pcsx2-qt.exe"), None)
        if executable is None or not executable.is_file():
            return result(False, "install_failed", "The PCSX2 archive was extracted but pcsx2-qt.exe was not found.", "executable_validation_failed", {"archive": str(archive_path)})
        emit_progress(progress, 81, "Installing PCSX2")
        for item in executable.parent.iterdir():
            target = EMULATOR_DIR / item.name
            if item.is_dir():
                shutil.copytree(item, target, dirs_exist_ok=True)
            else:
                shutil.copy2(item, target)
        if not EXECUTABLE_PATH.is_file():
            return result(False, "install_failed", "PCSX2 extraction completed but pcsx2-qt.exe is missing.", "post_install_validation_failed", {"expected": str(EXECUTABLE_PATH)})
        emit_progress(progress, 87, "Enabling portable mode")
        PORTABLE_MARKER.touch(exist_ok=True)
        emit_progress(progress, 90, "Installing PlayStation 2 BIOS")
        copied_bios = install_bios(staged_bios)
        selected_name = str(info["Resources"]["BIOS"]["SelectedBIOS"])
        selected_path = INSTALLED_BIOS_DIR / selected_name
        if not selected_path.is_file():
            return result(False, "install_failed", "PCSX2 installed, but the selected BIOS was not copied.", "bios_copy_failed", {"expected": str(selected_path)})
        write_minimal_config(selected_name)
        if not CONFIG_PATH.is_file():
            return result(False, "install_failed", "PCSX2 installed but its portable configuration was not created.", "config_creation_failed", {"expected": str(CONFIG_PATH)})
        romver = parse_romver(selected_path)
        if romver is None:
            return result(False, "install_failed", "PCSX2 installed but the selected BIOS failed ROMVER validation.", "bios_romver_invalid", {"path": str(selected_path)})
        emit_progress(progress, 96, "Writing receipt")
        receipt = {
            "EmuKitModule": "pcsx2",
            "ModuleVersion": module_version(info),
            "EmulatorVersion": version,
            "ReleaseTag": source["ReleaseTag"],
            "Asset": source["Asset"],
            "ArchiveSHA256": source["SHA256"],
            "SourceRepository": source["Repository"],
            "ReleasePublishedAt": asset.get("published_at"),
            "ResourceManifest": info["ResourceCatalog"]["ManifestURL"],
            "SelectedBIOS": {
                "file": selected_name,
                "romver": romver["romver"],
                "region": romver["region"],
                "version": romver["version"],
                "sha256": hash_file(selected_path, "sha256"),
            },
            "BIOS": copied_bios,
            "InstalledAtUTC": datetime.now(timezone.utc).isoformat(),
        }
        RECEIPT_PATH.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        emit_progress(progress, 98, "Verifying")
        install_complete = True
        return result(
            True,
            "installed",
            f'PCSX2 "{version}" installed successfully.',
            details={
                "module_version": module_version(info),
                "version": version,
                "path": str(EXECUTABLE_PATH),
                "portable": True,
                "bios": receipt["SelectedBIOS"],
                "bios_files": copied_bios,
                "source": source["OfficialRepository"],
            },
        )
    except PermissionError as exc:
        return result(False, "install_failed", "PCSX2 installation could not write one or more required files.", "permission_denied", str(exc))
    except Exception as exc:
        return result(False, "install_failed", "PCSX2 installation failed unexpectedly.", "install_exception", str(exc))
    finally:
        shutil.rmtree(temp, ignore_errors=True)
        if not install_complete:
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
