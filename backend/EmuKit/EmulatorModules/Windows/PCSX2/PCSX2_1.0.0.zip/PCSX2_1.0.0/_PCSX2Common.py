from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import sys
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Callable

MODULE_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
INFO_PATH = MODULE_DIR / "EmuKitPCSX2Info.json"
ROOT_MARKER = ".ProjectHomelabRoot"
ProgressCallback = Callable[[int | None, str | None, str | None], None]
ROMVER_PATTERN = re.compile(b"([0-9]{4})([JAEHCTXP])([A-Z])([0-9]{8})")
REGION_MAP = {"J": "Japan", "A": "USA", "E": "Europe", "H": "Asia", "C": "China", "T": "Test", "X": "Test", "P": "Free"}


def resolve_root() -> Path:
    current = MODULE_DIR.resolve()
    for candidate in (current, *current.parents):
        if (candidate / ROOT_MARKER).is_file():
            return candidate
    for candidate in (current, *current.parents):
        if (candidate / "EmuKit.py").is_file() and (candidate / "EmuKitModules").is_dir():
            return candidate
    if MODULE_DIR.parent.name.casefold() == "emukitmodules":
        return MODULE_DIR.parent.parent
    return MODULE_DIR.parent


ROOT = resolve_root()
EMULATOR_DIR = ROOT / "Emulators" / "PCSX2"
EXECUTABLE_PATH = EMULATOR_DIR / "pcsx2-qt.exe"
PORTABLE_MARKER = EMULATOR_DIR / "portable.txt"
INSTALLED_BIOS_DIR = EMULATOR_DIR / "bios"
INIS_DIR = EMULATOR_DIR / "inis"
CONFIG_PATH = INIS_DIR / "PCSX2.ini"
RECEIPT_PATH = EMULATOR_DIR / ".emukit_install.json"


def load_info() -> dict[str, Any]:
    return json.loads(INFO_PATH.read_text(encoding="utf-8"))


def module_version(info: dict[str, Any] | None = None) -> str:
    source = info if isinstance(info, dict) else load_info()
    return str(source["ModuleVersion"])


def emulator_version(info: dict[str, Any] | None = None) -> str:
    source = info if isinstance(info, dict) else load_info()
    return str(source["EmulatorVersion"])


def emit_progress(progress: ProgressCallback | None, percent: int | None, stage: str | None, message: str | None = None) -> None:
    if progress is not None:
        progress(percent, stage, message)


def scaled_progress(progress: ProgressCallback | None, start: int, end: int) -> ProgressCallback | None:
    if progress is None:
        return None

    def callback(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
        if percent is None:
            mapped = None
        else:
            bounded = max(0, min(100, int(percent)))
            mapped = start + round((end - start) * bounded / 100)
        progress(mapped, stage, message)

    return callback


def is_supported_host() -> tuple[bool, str | None]:
    if platform.system().lower() != "windows":
        return False, "PCSX2 module 1.0.0 currently supports Windows only."
    if platform.machine().lower() not in {"amd64", "x86_64"}:
        return False, f'PCSX2 module 1.0.0 requires Windows x86_64. Current architecture: "{platform.machine()}".'
    return True, None


def seven_zip_executable() -> Path | None:
    managed = ROOT / "dependencies" / "7Zip" / "26.03" / "Windows" / "x86_64" / "7z.exe"
    candidates = [managed]
    for command in ("7z", "7zz"):
        found = shutil.which(command)
        if found:
            candidates.append(Path(found))
    for environment_name in ("ProgramFiles", "ProgramFiles(x86)"):
        program_root = os.environ.get(environment_name)
        if program_root:
            candidates.append(Path(program_root) / "7-Zip" / "7z.exe")
    seen: set[str] = set()
    for candidate in candidates:
        identity = str(candidate).casefold()
        if identity in seen:
            continue
        seen.add(identity)
        if candidate.is_file():
            return candidate
    return None


def hash_file(path: Path, algorithm: str) -> str:
    digest = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_receipt() -> dict[str, Any] | None:
    try:
        value = json.loads(RECEIPT_PATH.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def request_json(url: str, timeout: int = 30) -> dict[str, Any]:
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": "ProjectHomelab-EmuKit-PCSX2/1.0.0",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        value = json.loads(response.read().decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Remote JSON root is not an object.")
    return value


def load_resource_catalog(info: dict[str, Any]) -> dict[str, dict[str, Any]]:
    manifest = request_json(str(info["ResourceCatalog"]["ManifestURL"]))
    resources = manifest.get("resources")
    if not isinstance(resources, list):
        raise ValueError("EmuKit resource manifest does not contain a resources list.")
    mapping: dict[str, dict[str, Any]] = {}
    for entry in resources:
        if isinstance(entry, dict) and isinstance(entry.get("path"), str):
            mapping[entry["path"]] = entry
    return mapping


def validate_catalog_entry(catalog: dict[str, dict[str, Any]], specification: dict[str, Any]) -> dict[str, Any]:
    path = str(specification["Path"])
    entry = catalog.get(path)
    if not isinstance(entry, dict):
        raise ValueError(f'Required EmuKit resource is not registered: "{path}".')
    if int(entry.get("size", -1)) != int(specification["Size"]):
        raise ValueError(f'Resource size changed for "{path}".')
    if str(entry.get("sha256", "")).lower() != str(specification["SHA256"]).lower():
        raise ValueError(f'Resource SHA-256 changed for "{path}".')
    if str(entry.get("md5", "")).lower() != str(specification["MD5"]).lower():
        raise ValueError(f'Resource MD5 changed for "{path}".')
    return entry


def resource_url(info: dict[str, Any], relative_path: str) -> str:
    base = str(info["ResourceCatalog"]["RawBaseURL"]).rstrip("/")
    return base + "/" + urllib.parse.quote(relative_path, safe="/")


def bios_sets(info: dict[str, Any]) -> list[dict[str, Any]]:
    value = info.get("Resources", {}).get("BIOS", {}).get("Sets", [])
    return [item for item in value if isinstance(item, dict)] if isinstance(value, list) else []


def bios_files(info: dict[str, Any]) -> list[dict[str, Any]]:
    files: list[dict[str, Any]] = []
    for bios_set in bios_sets(info):
        entries = bios_set.get("Files", [])
        if isinstance(entries, list):
            files.extend(entry for entry in entries if isinstance(entry, dict))
    return files


def selected_bios_specification(info: dict[str, Any]) -> dict[str, Any] | None:
    selected = str(info.get("Resources", {}).get("BIOS", {}).get("SelectedBIOS", ""))
    for entry in bios_files(info):
        if str(entry.get("InstallAs", "")) == selected and str(entry.get("Role", "")).casefold() == "main":
            return entry
    return None


def parse_romver(path: Path) -> dict[str, Any] | None:
    try:
        data = path.read_bytes()
    except OSError:
        return None
    match = ROMVER_PATTERN.search(data)
    if match is None:
        return None
    version_raw = match.group(1).decode("ascii")
    region_code = match.group(2).decode("ascii")
    console_code = match.group(3).decode("ascii")
    date_raw = match.group(4).decode("ascii")
    try:
        major = int(version_raw[:2])
        minor = int(version_raw[2:])
        version = f"{major}.{minor:02d}"
        date = f"{date_raw[0:4]}-{date_raw[4:6]}-{date_raw[6:8]}"
    except ValueError:
        return None
    return {
        "romver": match.group(0).decode("ascii"),
        "version": version,
        "version_raw": version_raw,
        "region_code": region_code,
        "region": REGION_MAP.get(region_code, "Unknown"),
        "console_code": console_code,
        "date": date,
    }
