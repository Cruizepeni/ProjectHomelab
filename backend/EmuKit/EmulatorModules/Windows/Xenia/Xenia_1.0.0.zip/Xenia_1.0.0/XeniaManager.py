from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

if not getattr(sys, "frozen", False):
    module_dir = Path(__file__).resolve().parent
    if str(module_dir) not in sys.path:
        sys.path.insert(0, str(module_dir))

from _XeniaCommon import *
import XeniaInstaller
import XeniaRepair
import XeniaUninstall


def base(success: bool, operation: str, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "xenia", "operation": operation, "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def check(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 20, "Checking")
    supported, reason = is_supported_host()
    if not supported:
        return base(False, "check", "unsupported", reason or "Xenia is not supported on this host.", "unsupported_host")
    info = load_info()
    pinned_version = emulator_version(info)
    if not EMULATOR_DIR.exists():
        return base(True, "check", "missing", "Xenia is not installed.", details={"expected_path": str(EMULATOR_DIR)})
    if not EXECUTABLE_PATH.is_file():
        return base(True, "check", "broken", "The Xenia emulator directory exists but xenia_canary.exe is missing.", details={"expected_executable": str(EXECUTABLE_PATH)})
    emit_progress(progress, 50, "Validating executable")
    if EXECUTABLE_PATH.stat().st_size < 100000:
        return base(True, "check", "broken", "xenia_canary.exe exists but failed basic file validation.", details={"path": str(EXECUTABLE_PATH), "size": EXECUTABLE_PATH.stat().st_size})
    emit_progress(progress, 75, "Validating receipt")
    receipt = read_receipt()
    if receipt is None:
        return base(True, "check", "broken", "Xenia is present but its EmuKit installation receipt is missing or invalid.", details={"receipt": str(RECEIPT_PATH)})
    installed_version = receipt.get("Version")
    if installed_version != pinned_version:
        return base(True, "check", "broken", "The installed Xenia build does not match the version pinned by this EmuKit module.", details={"installed_version": installed_version, "pinned_version": pinned_version})
    if receipt.get("AssetSHA256") != info["Source"]["SHA256"]:
        return base(True, "check", "broken", "The installed Xenia receipt does not match the pinned archive checksum.", details={"installed_sha256": receipt.get("AssetSHA256"), "pinned_sha256": info["Source"]["SHA256"]})
    emit_progress(progress, 95, "Ready")
    return base(True, "check", "installed", f'Xenia Canary "{pinned_version}" is installed and valid.', details={"version": pinned_version, "path": str(EXECUTABLE_PATH), "source": info["Source"]["OfficialRepository"]})


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return XeniaInstaller.install(progress=progress)


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return XeniaUninstall.uninstall(progress=progress)


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return XeniaRepair.repair(progress=progress)


def update(progress: ProgressCallback | None = None) -> dict[str, Any]:
    current = check(progress=scaled_progress(progress, 0, 20))
    if not current.get("success") and current.get("state") == "unsupported":
        current["operation"] = "update"
        return current
    if current.get("state") == "installed":
        return base(True, "update", "already_current", f'Xenia Canary "{emulator_version()}" is already the module-pinned version.', details=current.get("details"))
    repaired = XeniaRepair.repair(progress=scaled_progress(progress, 20, 98))
    repaired["operation"] = "update"
    repaired["state"] = "updated" if repaired.get("success") else "update_failed"
    if repaired.get("success"):
        repaired["message"] = f'Xenia was updated to pinned build "{emulator_version()}".'
    return repaired


def cli() -> int:
    args = sys.argv[1:]
    json_mode = False
    filtered = []
    for arg in args:
        if arg == "--json":
            json_mode = True
        else:
            filtered.append(arg)
    operation = filtered[0].casefold() if filtered else ""
    operations = {"check": check, "install": install, "uninstall": uninstall, "repair": repair, "update": update}
    if operation not in operations:
        response = base(False, operation or "unknown", "invalid_operation", "Unsupported Xenia module operation.", "invalid_operation", {"supported": sorted(operations)})
        if json_mode:
            print(json.dumps(response, separators=(",", ":")))
        else:
            print(response["message"])
        return 2
    try:
        response = operations[operation]()
    except Exception as exc:
        response = base(False, operation, f"{operation}_failed", "Xenia module operation failed unexpectedly.", "operation_exception", str(exc))
    if json_mode:
        print(json.dumps(response, separators=(",", ":")))
    else:
        print(response.get("message", ""))
    return 0 if response.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(cli())
