from __future__ import annotations

import json
import os
import platform
import shutil
import sys
from pathlib import Path
from typing import Any, Callable


def runtime_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def resolve_project_root(module_dir: Path) -> Path:
    current = module_dir.resolve()
    for candidate in (current, *current.parents):
        if (candidate / ".ProjectHomelabRoot").is_file():
            return candidate
    for candidate in (current, *current.parents):
        if candidate.name == "EmuKitModules":
            return candidate.parent
    return current


MODULE_DIR = runtime_dir()
INFO_PATH = MODULE_DIR / "EmuKitXeniaInfo.json"
PROJECT_ROOT = resolve_project_root(MODULE_DIR)
EMULATOR_DIR = PROJECT_ROOT / "Emulators" / "Xenia"
DEPENDENCY_DIR = EMULATOR_DIR
EXECUTABLE_PATH = EMULATOR_DIR / "xenia_canary.exe"
RECEIPT_PATH = EMULATOR_DIR / ".emukit_install.json"
ProgressCallback = Callable[[int | None, str | None, str | None], None]


def load_info() -> dict[str, Any]:
    return json.loads(INFO_PATH.read_text(encoding="utf-8"))


def emulator_version(info: dict[str, Any] | None = None) -> str:
    source = info if isinstance(info, dict) else load_info()
    return str(source["EmulatorVersion"])


def emit_progress(progress: ProgressCallback | None, percent: int | None, stage: str | None, message: str | None = None) -> None:
    if progress is not None:
        progress(percent, stage, message)


def scaled_progress(progress: ProgressCallback | None, start: int, end: int) -> ProgressCallback | None:
    if progress is None:
        return None
    def callback(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
        if percent is None:
            mapped = None
        else:
            bounded = max(0, min(100, int(percent)))
            mapped = start + round((end - start) * bounded / 100)
        progress(mapped, stage, message)
    return callback


def is_supported_host() -> tuple[bool, str | None]:
    if platform.system().lower() != "windows":
        return False, "The Xenia EmuKit module 1.0.0 currently supports Windows only."
    machine = platform.machine().lower()
    if machine not in {"amd64", "x86_64"}:
        return False, f'The Xenia EmuKit module 1.0.0 requires a Windows x86-64 host. Current architecture: "{platform.machine()}".'
    return True, None


def seven_zip_executable() -> Path | None:
    managed = PROJECT_ROOT / "dependencies" / "7Zip" / "26.03" / "Windows" / "x86_64" / "7z.exe"
    candidates = [managed]
    for command in ("7z", "7zz"):
        found = shutil.which(command)
        if found:
            candidates.append(Path(found))
    for environment_name in ("ProgramFiles", "ProgramFiles(x86)"):
        program_root = os.environ.get(environment_name)
        if program_root:
            candidates.append(Path(program_root) / "7-Zip" / "7z.exe")
    seen = set()
    for candidate in candidates:
        resolved = str(candidate).casefold()
        if resolved in seen:
            continue
        seen.add(resolved)
        if candidate.is_file():
            return candidate
    return None


def read_receipt() -> dict[str, Any] | None:
    try:
        value = json.loads(RECEIPT_PATH.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except Exception:
        return None
