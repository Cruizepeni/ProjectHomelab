from __future__ import annotations

import json
import shutil
import stat
import urllib.error
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from _PPSSPPCommon import EMULATOR_DIR, EXECUTABLE_PATH, INSTALLED_MARKER, MEMSTICK_DIR, RECEIPT_PATH, ProgressCallback, emit_progress, emulator_version, hash_file, is_supported_host, load_info, module_version


def result(success: bool, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "ppsspp", "operation": "install", "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def safe_extract_zip(archive_path: Path, destination: Path) -> None:
    destination = destination.resolve()
    with zipfile.ZipFile(archive_path, "r") as archive:
        for member in archive.infolist():
            member_path = Path(member.filename)
            if member_path.is_absolute() or ".." in member_path.parts:
                raise ValueError(f'Unsafe archive path "{member.filename}".')
            mode = (member.external_attr >> 16) & 0xFFFF
            if stat.S_ISLNK(mode):
                raise ValueError(f'Symbolic links are not allowed in the PPSSPP archive: "{member.filename}".')
            target = (destination / member_path).resolve()
            try:
                target.relative_to(destination)
            except ValueError as exc:
                raise ValueError(f'Unsafe archive path "{member.filename}".') from exc
        bad_member = archive.testzip()
        if bad_member is not None:
            raise ValueError(f'PPSSPP archive CRC validation failed at "{bad_member}".')
        archive.extractall(destination)


def download(url: str, destination: Path, expected_size: int, expected_sha256: str, progress: ProgressCallback | None = None) -> dict[str, Any] | None:
    request = urllib.request.Request(url, headers={"User-Agent": "ProjectHomelab-EmuKit-PPSSPP/1.0.0"})
    try:
        with urllib.request.urlopen(request, timeout=120) as response, destination.open("wb") as output:
            raw_total = response.headers.get("Content-Length")
            total = int(raw_total) if raw_total and raw_total.isdigit() else expected_size
            received = 0
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                output.write(block)
                received += len(block)
                if total > 0:
                    emit_progress(progress, min(100, round(received * 100 / total)), "Downloading Emulator", destination.name)
    except urllib.error.HTTPError as exc:
        return result(False, "download_failed", "The official PPSSPP archive could not be downloaded.", "download_http_error", {"url": url, "http_status": exc.code})
    except Exception as exc:
        return result(False, "download_failed", "The official PPSSPP archive could not be downloaded.", "download_failed", str(exc))

    emit_progress(progress, 100, "Downloading Emulator", destination.name)
    emit_progress(progress, 100, "Validating Emulator", destination.name)
    if not destination.is_file():
        return result(False, "download_failed", "The PPSSPP archive was not created after download.", "download_missing", {"url": url})
    actual_size = destination.stat().st_size
    if actual_size != expected_size:
        return result(False, "download_failed", "The downloaded PPSSPP archive size does not match the pinned release asset.", "archive_size_mismatch", {"expected": expected_size, "actual": actual_size})
    actual_sha256 = hash_file(destination)
    if actual_sha256.lower() != expected_sha256.lower():
        return result(False, "download_failed", "The downloaded PPSSPP archive failed SHA-256 verification.", "archive_checksum_mismatch", {"expected": expected_sha256, "actual": actual_sha256})
    return None


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, "Checking Host")
    supported, reason = is_supported_host()
    if not supported:
        return result(False, "unsupported", reason or "Unsupported host.", "unsupported_host")

    info = load_info()
    version = emulator_version(info)
    source = info["Source"]
    if EMULATOR_DIR.exists():
        return result(False, "install_failed", "The PPSSPP emulator directory already exists. Use repair for a clean reinstall.", "emulator_already_exists", {"path": str(EMULATOR_DIR)})

    emit_progress(progress, 8, "Preparing Install", source["Asset"])
    EMULATOR_DIR.mkdir(parents=True, exist_ok=False)
    temp_dir = EMULATOR_DIR / ".install"
    extract_dir = temp_dir / "extracted"
    archive_path = temp_dir / source["Asset"]
    temp_dir.mkdir(parents=True, exist_ok=True)
    extract_dir.mkdir(parents=True, exist_ok=True)
    complete = False

    try:
        def download_progress(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
            mapped = None if percent is None else 10 + round(max(0, min(100, int(percent))) * 50 / 100)
            emit_progress(progress, mapped, stage, message)

        failure = download(str(source["DownloadURL"]), archive_path, int(source["Size"]), str(source["SHA256"]), download_progress)
        if failure is not None:
            return failure

        emit_progress(progress, 64, "Extracting Emulator", archive_path.name)
        safe_extract_zip(archive_path, extract_dir)
        extracted_executable = next(extract_dir.rglob("PPSSPPWindows64.exe"), None)
        if extracted_executable is None or not extracted_executable.is_file():
            return result(False, "install_failed", "The PPSSPP archive extracted successfully but PPSSPPWindows64.exe was not found.", "executable_validation_failed", {"archive": str(archive_path)})

        extracted_root = extracted_executable.parent
        emit_progress(progress, 76, "Installing Emulator", extracted_executable.name)
        for item in extracted_root.iterdir():
            destination = EMULATOR_DIR / item.name
            if item.is_dir():
                shutil.copytree(item, destination)
            else:
                shutil.copy2(item, destination)

        if not EXECUTABLE_PATH.is_file():
            return result(False, "install_failed", "PPSSPP extraction completed but its 64-bit executable is missing.", "post_install_validation_failed", {"expected": str(EXECUTABLE_PATH)})

        emit_progress(progress, 88, "Configuring Emulator", "memstick")
        if INSTALLED_MARKER.exists():
            INSTALLED_MARKER.unlink()
        for path in (
            MEMSTICK_DIR / "PSP" / "SYSTEM",
            MEMSTICK_DIR / "PSP" / "SAVEDATA",
            MEMSTICK_DIR / "PSP" / "PPSSPP_STATE",
        ):
            path.mkdir(parents=True, exist_ok=True)

        emit_progress(progress, 94, "Writing Receipt")
        receipt = {
            "EmuKitModule": "ppsspp",
            "ModuleVersion": module_version(info),
            "EmulatorVersion": version,
            "ReleaseTag": source["ReleaseTag"],
            "ReleaseCommit": source["ReleaseCommit"],
            "Asset": source["Asset"],
            "AssetSize": source["Size"],
            "AssetSHA256": source["SHA256"],
            "DownloadURL": source["DownloadURL"],
            "PortableMode": True,
            "MemstickPath": str(MEMSTICK_DIR),
            "InstalledAtUTC": datetime.now(timezone.utc).isoformat(),
        }
        RECEIPT_PATH.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")

        emit_progress(progress, 98, "Verifying Installation", EXECUTABLE_PATH.name)
        complete = True
        return result(True, "installed", f'PPSSPP "{version}" installed successfully.', details={"module_version": module_version(info), "version": version, "path": str(EXECUTABLE_PATH), "portable": True, "memstick": str(MEMSTICK_DIR), "archive_sha256": source["SHA256"], "source": source["OfficialRepository"]})
    except PermissionError as exc:
        return result(False, "install_failed", "PPSSPP installation could not write one or more required files.", "permission_denied", str(exc))
    except Exception as exc:
        return result(False, "install_failed", "PPSSPP installation failed unexpectedly.", "install_exception", str(exc))
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        if not complete:
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
