from __future__ import annotations

import ctypes
import hashlib
import json
import os
import subprocess
import platform
import re
import shutil
import sys
from pathlib import Path
from typing import Any, Callable

MODULE_DIR = (
    Path(sys.executable).resolve().parent
    if getattr(sys, "frozen", False)
    else Path(__file__).resolve().parent
)
INFO_PATH = MODULE_DIR / "EmuKitRPCS3Info.json"
ROOT_MARKER = ".ProjectHomelabRoot"
ProgressCallback = Callable[[int | None, str | None, str | None], None]


def resolve_root() -> Path:
    current = MODULE_DIR.resolve()
    for candidate in (current, *current.parents):
        if (candidate / ROOT_MARKER).is_file():
            return candidate
    for candidate in (current, *current.parents):
        if candidate.name.casefold() == "emukitmodules":
            return candidate.parent
    for candidate in (current, *current.parents):
        if (candidate / "EmuKit.py").is_file() and (candidate / "EmuKitModules").is_dir():
            return candidate
    return MODULE_DIR.parent


ROOT = resolve_root()
EMULATOR_DIR = ROOT / "Emulators" / "RPCS3"
EXECUTABLE_PATH = EMULATOR_DIR / "rpcs3.exe"
GUI_CONFIG_DIR = EMULATOR_DIR / "GuiConfigs"
GUI_CONFIG_PATH = GUI_CONFIG_DIR / "CurrentSettings.ini"
DEV_FLASH_DIR = EMULATOR_DIR / "dev_flash"
FIRMWARE_SENTINEL = DEV_FLASH_DIR / "vsh" / "module" / "vsh.self"
FIRMWARE_VERSION_PATH = DEV_FLASH_DIR / "vsh" / "etc" / "version.txt"
RECEIPT_PATH = EMULATOR_DIR / ".emukit_install.json"


def load_info() -> dict[str, Any]:
    return json.loads(INFO_PATH.read_text(encoding="utf-8"))


def module_version(info: dict[str, Any] | None = None) -> str:
    source = info if isinstance(info, dict) else load_info()
    return str(source["ModuleVersion"])


def emulator_version(info: dict[str, Any] | None = None) -> str:
    source = info if isinstance(info, dict) else load_info()
    return str(source["EmulatorVersion"])


def emit_progress(progress: ProgressCallback | None, percent: int | None, stage: str | None, message: str | None = None) -> None:
    if progress is not None:
        progress(percent, stage, message)


def scaled_progress(progress: ProgressCallback | None, start: int, end: int) -> ProgressCallback | None:
    if progress is None:
        return None

    def callback(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
        if percent is None:
            mapped = None
        else:
            bounded = max(0, min(100, int(percent)))
            mapped = start + round((end - start) * bounded / 100)
        progress(mapped, stage, message)

    return callback


def is_supported_host() -> tuple[bool, str | None]:
    if platform.system().lower() != "windows":
        return False, "RPCS3 module 1.0.0 currently supports Windows only."
    if platform.machine().lower() not in {"amd64", "x86_64"}:
        return False, f'RPCS3 module 1.0.0 requires Windows x86_64. Current architecture: "{platform.machine()}".'
    return True, None


def seven_zip_executable() -> Path | None:
    managed = ROOT / "dependencies" / "7Zip" / "26.03" / "Windows" / "x86_64" / "7z.exe"
    candidates = [managed]
    for command in ("7z", "7zz"):
        found = shutil.which(command)
        if found:
            candidates.append(Path(found))
    for variable in ("ProgramFiles", "ProgramFiles(x86)"):
        value = os.environ.get(variable)
        if value:
            candidates.append(Path(value) / "7-Zip" / "7z.exe")
    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate).casefold()
        if key in seen:
            continue
        seen.add(key)
        if candidate.is_file():
            return candidate
    return None


def run_external_process(args: list[str], detach_console: bool = False, **kwargs: Any) -> subprocess.CompletedProcess[Any]:
    frozen_windows = os.name == "nt" and getattr(sys, "frozen", False)
    restore_directory: str | None = None
    console_detached = False
    kernel32 = ctypes.windll.kernel32 if frozen_windows else None
    if kernel32 is not None:
        restore_directory = str(getattr(sys, "_MEIPASS", "")) or None
        kernel32.SetDllDirectoryW(None)
        if detach_console and kernel32.GetConsoleWindow():
            console_detached = bool(kernel32.FreeConsole())
    try:
        return subprocess.run(args, **kwargs)
    finally:
        if kernel32 is not None:
            if console_detached:
                kernel32.AttachConsole(0xFFFFFFFF)
            kernel32.SetDllDirectoryW(restore_directory)


def hash_file(path: Path, algorithm: str = "sha256") -> str:
    digest = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_receipt() -> dict[str, Any] | None:
    try:
        value = json.loads(RECEIPT_PATH.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def parse_firmware_version(path: Path) -> str | None:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    match = re.search(r"release:\s*0*(\d+)\.(\d{2})\d*:", text, flags=re.IGNORECASE)
    if match is None:
        return None
    try:
        major = int(match.group(1))
    except ValueError:
        return None
    return f"{major}.{match.group(2)}"


def firmware_health(info: dict[str, Any]) -> dict[str, Any]:
    expected_version = str(info["Firmware"]["Version"])
    if not FIRMWARE_SENTINEL.is_file():
        return {"valid": False, "reason": "missing_vsh", "message": "RPCS3 firmware is missing dev_flash/vsh/module/vsh.self.", "details": {"expected": str(FIRMWARE_SENTINEL)}}
    if not FIRMWARE_VERSION_PATH.is_file():
        return {"valid": False, "reason": "missing_version_file", "message": "RPCS3 firmware is missing its version file.", "details": {"expected": str(FIRMWARE_VERSION_PATH)}}
    detected_version = parse_firmware_version(FIRMWARE_VERSION_PATH)
    if detected_version is None:
        return {"valid": False, "reason": "unreadable_firmware_version", "message": "RPCS3 firmware exists but EmuKit could not read its release version.", "details": {"path": str(FIRMWARE_VERSION_PATH)}}
    if detected_version != expected_version:
        return {"valid": False, "reason": "firmware_version_mismatch", "message": "RPCS3 firmware does not match the version pinned by this module.", "details": {"installed_version": detected_version, "pinned_version": expected_version}}
    return {"valid": True, "version": detected_version, "sentinel": str(FIRMWARE_SENTINEL), "version_file": str(FIRMWARE_VERSION_PATH)}
