from __future__ import annotations

import json
import shutil
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

from _AresCommon import EMULATOR_DIR, EXECUTABLE_PATH, FIRMWARE_DIR, RECEIPT_PATH, SETTINGS_PATH, ProgressCallback, emit_progress, emulator_version, hash_file, is_supported_host, load_info, module_version, resource_path, run_external_process


def result(success: bool, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "ares", "operation": "install", "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def download(url: str, destination: Path, progress: ProgressCallback | None = None, stage: str = "Downloading") -> dict[str, Any] | None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(url, headers={"User-Agent": "ProjectHomelab-EmuKit-Ares/1.0.0", "Accept": "*/*"})
    try:
        with urllib.request.urlopen(request, timeout=180) as response, destination.open("wb") as output:
            raw_total = response.headers.get("Content-Length")
            total = int(raw_total) if raw_total and raw_total.isdigit() else None
            received = 0
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                output.write(block)
                received += len(block)
                percent = min(100, round(received * 100 / total)) if total else None
                emit_progress(progress, percent, stage)
        if not destination.is_file():
            return result(False, "download_failed", "The requested file was not created.", "download_missing", {"url": url})
        return None
    except urllib.error.HTTPError as exc:
        return result(False, "download_failed", "A required Ares file could not be downloaded.", "download_http_error", {"url": url, "http_status": exc.code})
    except Exception as exc:
        return result(False, "download_failed", "A required Ares file could not be downloaded.", "download_failed", str(exc))


def safe_extract(archive: zipfile.ZipFile, destination: Path) -> None:
    root = destination.resolve()
    for member in archive.infolist():
        relative = PurePosixPath(member.filename.replace("\\", "/"))
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f'Unsafe archive path: "{member.filename}"')
        target = destination.joinpath(*relative.parts)
        resolved = target.resolve()
        resolved.relative_to(root)
        if member.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(member, "r") as source, target.open("wb") as output:
                shutil.copyfileobj(source, output)


def bml_path_lines(path: str, value: str) -> list[str]:
    parts = path.split("/")
    return [f'{"  " * index}{part}' for index, part in enumerate(parts[:-1])] + [f'{"  " * (len(parts) - 1)}{parts[-1]}: {value}']


def write_settings(info: dict[str, Any]) -> None:
    firmware_root = FIRMWARE_DIR.as_posix()
    tree: dict[str, Any] = {"Paths": {"Firmware": firmware_root}}
    for setting_path, resource_id in info["FirmwareBindings"].items():
        parts = setting_path.split("/")
        node = tree
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        node[parts[-1]] = resource_path(info, resource_id).as_posix()

    lines: list[str] = []
    def render(node: dict[str, Any], depth: int = 0) -> None:
        for key, value in node.items():
            if isinstance(value, dict):
                lines.append(f'{"  " * depth}{key}')
                render(value, depth + 1)
            else:
                lines.append(f'{"  " * depth}{key}: {value}')
    render(tree)
    SETTINGS_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")


def install_resources(info: dict[str, Any], progress: ProgressCallback | None = None) -> dict[str, Any] | None:
    FIRMWARE_DIR.mkdir(parents=True, exist_ok=True)
    items = list(info["Resources"].items())
    total = len(items)
    base = str(info["ResourceCatalog"]["RawBaseURL"]).rstrip("/")
    for index, (resource_id, spec) in enumerate(items):
        start = round(index * 100 / total)
        end = round((index + 1) * 100 / total)
        target = FIRMWARE_DIR / str(spec["ManagedFilename"])
        encoded = urllib.parse.quote(str(spec["Path"]).replace("\\", "/"), safe="/")
        url = f"{base}/{encoded}"
        def mapped(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
            value = None if percent is None else start + round((end - start) * max(0, min(100, int(percent))) / 100)
            emit_progress(progress, value, "Downloading firmware", str(spec["ManagedFilename"]))
        error = download(url, target, mapped, "Downloading firmware")
        if error is not None:
            error["details"] = {"resource": resource_id, "resource_path": spec["Path"], "download": error.get("details")}
            return error
        actual = hash_file(target).lower()
        expected = str(spec["SHA256"]).lower()
        if actual != expected:
            return result(False, "invalid_resources", "An Ares firmware resource failed SHA-256 validation.", "resource_hash_mismatch", {"resource": resource_id, "expected_sha256": expected, "actual_sha256": actual, "path": str(target)})
    return None


def validate_runtime(expected_version: str) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    try:
        completed = run_external_process(
            [str(EXECUTABLE_PATH), "--version"],
            isolate_console=True,
            cwd=str(EMULATOR_DIR),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
            timeout=30,
        )
    except Exception as exc:
        return None, result(False, "install_failed", "The installed Ares executable could not complete its version self-check.", "runtime_validation_exception", str(exc))
    combined = "\n".join(part for part in [completed.stdout.strip(), completed.stderr.strip()] if part)
    if completed.returncode != 0:
        return None, result(False, "install_failed", "Ares failed its version self-check.", "runtime_validation_failed", {"exit_code": completed.returncode, "output": combined[-4000:]})
    if expected_version not in combined:
        return None, result(False, "install_failed", "Ares started but reported an unexpected version.", "runtime_version_mismatch", {"expected_version": expected_version, "reported": combined})
    return {"exit_code": completed.returncode, "reported": combined}, None


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, "Checking host")
    supported, reason = is_supported_host()
    if not supported:
        return result(False, "unsupported", reason or "Unsupported host.", "unsupported_host")

    info = load_info()
    version = emulator_version(info)
    if EMULATOR_DIR.exists():
        return result(False, "install_failed", "The Ares emulator directory already exists. Use repair for a clean reinstall.", "emulator_already_exists", {"path": str(EMULATOR_DIR)})

    EMULATOR_DIR.mkdir(parents=True)
    temp_dir = EMULATOR_DIR / ".install"
    archive_path = temp_dir / str(info["Source"]["Asset"])
    extract_dir = temp_dir / "extracted"
    extract_dir.mkdir(parents=True)
    complete = False

    try:
        emit_progress(progress, 8, "Downloading emulator")
        def emulator_progress(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
            mapped = None if percent is None else 8 + round(max(0, min(100, int(percent))) * 42 / 100)
            emit_progress(progress, mapped, "Downloading emulator", message)
        error = download(str(info["Source"]["DownloadURL"]), archive_path, emulator_progress)
        if error is not None:
            return error

        emit_progress(progress, 52, "Validating emulator")
        actual_archive = hash_file(archive_path).lower()
        expected_archive = str(info["Source"]["SHA256"]).lower()
        if actual_archive != expected_archive:
            return result(False, "invalid_download", "The official Ares archive failed SHA-256 validation.", "archive_hash_mismatch", {"expected_sha256": expected_archive, "actual_sha256": actual_archive})

        try:
            with zipfile.ZipFile(archive_path, "r") as archive:
                bad = archive.testzip()
                if bad:
                    return result(False, "extract_failed", "The official Ares ZIP failed its internal CRC validation.", "archive_crc_failed", {"member": bad})
                emit_progress(progress, 56, "Extracting")
                safe_extract(archive, extract_dir)
        except Exception as exc:
            return result(False, "extract_failed", "The official Ares ZIP could not be safely extracted.", "invalid_archive", str(exc))

        extracted_exe = next((path for path in extract_dir.rglob("ares.exe") if path.is_file()), None)
        if extracted_exe is None:
            return result(False, "install_failed", "The official Ares archive did not contain ares.exe.", "executable_missing")

        emit_progress(progress, 62, "Installing emulator")
        for item in extracted_exe.parent.iterdir():
            destination = EMULATOR_DIR / item.name
            if item.resolve() == temp_dir.resolve():
                continue
            if item.is_dir():
                shutil.copytree(item, destination, dirs_exist_ok=True)
            else:
                shutil.copy2(item, destination)

        if not EXECUTABLE_PATH.is_file():
            return result(False, "install_failed", "Ares extraction completed but ares.exe is missing.", "post_install_validation_failed", {"expected": str(EXECUTABLE_PATH)})

        emit_progress(progress, 68, "Installing firmware")
        resource_error = install_resources(info, progress=lambda p, s, m=None: emit_progress(progress, None if p is None else 68 + round(p * 20 / 100), s, m))
        if resource_error is not None:
            return resource_error

        emit_progress(progress, 89, "Configuring")
        write_settings(info)

        emit_progress(progress, 92, "Verifying")
        runtime, runtime_error = validate_runtime(version)
        if runtime_error is not None:
            return runtime_error

        executable_sha = hash_file(EXECUTABLE_PATH)
        receipt = {
            "EmuKitModule": "ares",
            "ModuleVersion": module_version(info),
            "EmulatorVersion": version,
            "ReleaseTag": info["Source"]["ReleaseTag"],
            "ReleaseCommit": info["Source"]["ReleaseCommit"],
            "ArchiveSHA256": info["Source"]["SHA256"],
            "ExecutableSHA256": executable_sha,
            "ResourceCatalog": info["ResourceCatalog"]["ManifestURL"],
            "Resources": {resource_id: {"ManagedFilename": spec["ManagedFilename"], "SHA256": spec["SHA256"]} for resource_id, spec in info["Resources"].items()},
            "RuntimeValidation": runtime,
            "InstalledAtUTC": datetime.now(timezone.utc).isoformat(),
        }

        emit_progress(progress, 97, "Writing receipt")
        RECEIPT_PATH.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        complete = True
        return result(True, "installed", f'Ares "{version}" installed successfully with managed EmuKit firmware resources.', details={"module_version": module_version(info), "version": version, "path": str(EXECUTABLE_PATH), "settings": str(SETTINGS_PATH), "firmware_dir": str(FIRMWARE_DIR), "resource_count": len(info["Resources"]), "systems": sorted(info["Systems"].keys()), "source": info["Source"]["OfficialRepository"]})
    except PermissionError as exc:
        return result(False, "install_failed", "Ares installation could not write one or more required files.", "permission_denied", str(exc))
    except Exception as exc:
        return result(False, "install_failed", "Ares installation failed unexpectedly.", "install_exception", str(exc))
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        if not complete:
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
