from __future__ import annotations

import json
import shutil
import urllib.error
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from _DuckStationCommon import *


def result(success: bool, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "duckstation", "operation": "install", "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def github_json(url: str) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    try:
        return request_json(url), None
    except urllib.error.HTTPError as exc:
        return None, result(False, "download_failed", "DuckStation release information could not be retrieved from GitHub.", "github_http_error", {"http_status": exc.code, "url": url})
    except Exception as exc:
        return None, result(False, "download_failed", "DuckStation release information could not be retrieved from GitHub.", "github_lookup_failed", str(exc))


def release_asset(info: dict[str, Any]) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    source = info["Source"]
    repository = str(source["Repository"])
    release_tag = str(source["ReleaseTag"])
    pinned_commit = str(source["PinnedCommit"]).lower()
    asset_name = str(source["Asset"])
    ref_url = f"https://api.github.com/repos/{repository}/git/ref/tags/{release_tag}"
    ref, error = github_json(ref_url)
    if error is not None:
        return None, error
    assert ref is not None
    ref_object = ref.get("object", {})
    if not isinstance(ref_object, dict):
        return None, result(False, "download_failed", "DuckStation's GitHub tag reference did not contain a valid object.", "invalid_tag_reference", {"release_tag": release_tag})
    current_object_type = str(ref_object.get("type", "")).lower()
    current_sha = str(ref_object.get("sha", "")).lower()
    dereference_depth = 0
    while current_object_type == "tag" and current_sha:
        dereference_depth += 1
        if dereference_depth > 4:
            return None, result(False, "download_failed", "DuckStation's GitHub release tag could not be safely resolved.", "tag_resolution_depth_exceeded", {"release_tag": release_tag})
        tag_object, tag_error = github_json(f"https://api.github.com/repos/{repository}/git/tags/{current_sha}")
        if tag_error is not None:
            return None, tag_error
        assert tag_object is not None
        target = tag_object.get("object", {})
        if not isinstance(target, dict):
            return None, result(False, "download_failed", "DuckStation's annotated GitHub tag has an invalid target.", "invalid_annotated_tag_target", {"release_tag": release_tag})
        current_object_type = str(target.get("type", "")).lower()
        current_sha = str(target.get("sha", "")).lower()
    if current_object_type != "commit" or not current_sha:
        return None, result(False, "download_failed", "DuckStation's GitHub release tag did not resolve to a commit.", "tag_did_not_resolve_to_commit", {"release_tag": release_tag, "resolved_type": current_object_type or None})
    if not current_sha.startswith(pinned_commit):
        return None, result(False, "pinned_release_changed", "DuckStation's rolling release has changed since this EmuKit module was tested. Update the module pin before installing the newer build.", "pinned_release_changed", {"expected_commit": pinned_commit, "current_release_commit": current_sha, "release_tag": release_tag})
    release, release_error = github_json(f"https://api.github.com/repos/{repository}/releases/tags/{release_tag}")
    if release_error is not None:
        return None, release_error
    assert release is not None
    for asset in release.get("assets", []):
        if not isinstance(asset, dict) or asset.get("name") != asset_name:
            continue
        url = asset.get("browser_download_url")
        if not isinstance(url, str):
            continue
        digest = str(asset.get("digest", ""))
        expected_digest = "sha256:" + str(source["SHA256"]).lower()
        if digest and digest.lower() != expected_digest:
            return None, result(False, "pinned_release_changed", "DuckStation's release asset checksum no longer matches this module pin.", "release_asset_hash_changed", {"expected": expected_digest, "current": digest.lower()})
        size = asset.get("size")
        if isinstance(source.get("Size"), int) and isinstance(size, int) and size != int(source["Size"]):
            return None, result(False, "pinned_release_changed", "DuckStation's release asset size no longer matches this module pin.", "release_asset_size_changed", {"expected": source["Size"], "current": size})
        return {"url": url, "digest": digest, "size": size, "published_at": release.get("published_at"), "commit": current_sha}, None
    return None, result(False, "download_failed", f'DuckStation release "{release_tag}" does not contain the expected official asset "{asset_name}".', "release_asset_missing")


def download_file(url: str, destination: Path, expected_sha256: str, expected_size: int | None, progress: ProgressCallback | None = None) -> dict[str, Any] | None:
    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
        request = urllib.request.Request(url, headers={"User-Agent": "ProjectHomelab-EmuKit-DuckStation/1.0.0"})
        with urllib.request.urlopen(request, timeout=90) as response, destination.open("wb") as output:
            raw_length = response.headers.get("Content-Length")
            total = int(raw_length) if raw_length and raw_length.isdigit() else expected_size
            downloaded = 0
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)
                downloaded += len(chunk)
                percent = min(100, int(downloaded * 100 / total)) if total else None
                emit_progress(progress, percent, "Downloading", destination.name)
        if expected_size is not None and destination.stat().st_size != int(expected_size):
            return result(False, "download_failed", "A downloaded file failed size validation.", "download_size_mismatch", {"url": url, "expected_size": expected_size, "actual_size": destination.stat().st_size})
        actual = hash_file(destination, "sha256").lower()
        if actual != expected_sha256.lower():
            return result(False, "download_failed", "A downloaded file failed SHA-256 validation.", "download_hash_mismatch", {"url": url, "expected_sha256": expected_sha256.lower(), "actual_sha256": actual})
        emit_progress(progress, 100, "Downloading", destination.name)
        return None
    except urllib.error.HTTPError as exc:
        return result(False, "download_failed", "A required file could not be downloaded.", "download_http_error", {"url": url, "http_status": exc.code})
    except Exception as exc:
        return result(False, "download_failed", "A required file could not be downloaded.", "download_failed", {"url": url, "exception": str(exc)})


def safe_extract(archive_path: Path, destination: Path) -> None:
    destination = destination.resolve()
    with zipfile.ZipFile(archive_path) as archive:
        for member in archive.infolist():
            target = (destination / member.filename).resolve()
            if target != destination and destination not in target.parents:
                raise ValueError("Archive contains an unsafe path.")
        archive.extractall(destination)


def stage_bios(info: dict[str, Any], destination: Path, progress: ProgressCallback | None = None):
    emit_progress(progress, 2, "Reading resource catalogue")
    try:
        catalog = load_resource_catalog(info)
    except Exception as exc:
        return None, result(False, "resource_failed", "The EmuKit resource catalogue could not be loaded.", "resource_catalog_unavailable", str(exc))
    accepted = info["Resources"]["BIOS"]["Accepted"]
    try:
        for specification in accepted:
            validate_catalog_entry(catalog, specification)
    except Exception as exc:
        return None, result(False, "resource_failed", "A required PlayStation BIOS no longer matches the DuckStation module contract.", "resource_catalog_mismatch", str(exc))
    staged: list[Path] = []
    total = len(accepted)
    for index, specification in enumerate(accepted):
        start = round(index * 100 / total)
        end = round((index + 1) * 100 / total)
        target = destination / str(specification["InstallAs"])
        error = download_file(
            resource_url(info, str(specification["Path"])),
            target,
            str(specification["SHA256"]),
            int(specification["Size"]),
            scaled_progress(progress, start, end),
        )
        if error:
            return None, error
        if hash_file(target, "md5").lower() != str(specification["MD5"]).lower():
            return None, result(False, "resource_failed", "A downloaded PlayStation BIOS failed MD5 validation.", "bios_md5_mismatch", {"path": specification["Path"]})
        staged.append(target)
    return staged, None


def install_bios(staged: list[Path], progress: ProgressCallback | None = None) -> list[str]:
    INSTALLED_BIOS_DIR.mkdir(parents=True, exist_ok=True)
    copied: list[str] = []
    total = len(staged)
    for index, source in enumerate(staged):
        percent = round(index * 100 / total) if total else 100
        emit_progress(progress, percent, "Installing PlayStation BIOS", source.name)
        target = INSTALLED_BIOS_DIR / source.name
        shutil.copy2(source, target)
        copied.append(target.name)
    if staged:
        emit_progress(progress, 100, "Installing PlayStation BIOS", staged[-1].name)
    return copied


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, "Checking host")
    supported, reason = is_supported_host()
    if not supported:
        return result(False, "unsupported", reason or "Unsupported host.", "unsupported_host")
    info = load_info()
    version = emulator_version(info)
    if EMULATOR_DIR.exists():
        return result(False, "install_failed", "The DuckStation emulator directory already exists. Use repair for a clean reinstall.", "emulator_already_exists", {"path": str(EMULATOR_DIR)})
    EMULATOR_DIR.mkdir(parents=True)
    temp = EMULATOR_DIR / ".install"
    bios_stage = temp / "bios"
    extract = temp / "extracted"
    archive_path = temp / str(info["Source"]["Asset"])
    bios_stage.mkdir(parents=True)
    extract.mkdir()
    try:
        emit_progress(progress, 7, "Verifying pinned release", str(info["Source"]["ReleaseTag"]))
        asset, release_error = release_asset(info)
        if release_error is not None:
            return release_error
        assert asset is not None
        emit_progress(progress, 12, "Downloading PlayStation BIOS resources", f'{len(info["Resources"]["BIOS"]["Accepted"])} BIOS files')
        staged_bios, bios_error = stage_bios(info, bios_stage, scaled_progress(progress, 12, 27))
        if bios_error is not None:
            return bios_error
        assert staged_bios is not None
        source = info["Source"]
        emit_progress(progress, 30, "Downloading DuckStation", archive_path.name)
        archive_error = download_file(
            str(asset["url"]),
            archive_path,
            str(source["SHA256"]),
            int(source["Size"]),
            scaled_progress(progress, 30, 70),
        )
        if archive_error is not None:
            return archive_error
        emit_progress(progress, 73, "Extracting DuckStation", archive_path.name)
        try:
            safe_extract(archive_path, extract)
        except (zipfile.BadZipFile, ValueError) as exc:
            return result(False, "extract_failed", "The DuckStation release archive could not be safely extracted.", "archive_extract_failed", str(exc))
        executable = next(extract.rglob("duckstation-qt-x64-ReleaseLTCG.exe"), None)
        if executable is None or not executable.is_file():
            return result(False, "install_failed", "The DuckStation archive was extracted but the expected Windows x64 executable was not found.", "executable_validation_failed", {"expected": "duckstation-qt-x64-ReleaseLTCG.exe"})
        emit_progress(progress, 81, "Installing DuckStation", executable.name)
        for item in executable.parent.iterdir():
            target = EMULATOR_DIR / item.name
            if item.is_dir():
                shutil.copytree(item, target, dirs_exist_ok=True)
            else:
                shutil.copy2(item, target)
        if not EXECUTABLE_PATH.is_file():
            return result(False, "install_failed", "DuckStation extraction completed but its executable is missing.", "post_install_validation_failed", {"expected": str(EXECUTABLE_PATH)})
        emit_progress(progress, 88, "Enabling portable mode")
        PORTABLE_MARKER.touch(exist_ok=True)
        emit_progress(progress, 91, "Installing PlayStation BIOS", f"{len(staged_bios)} BIOS files")
        copied_bios = install_bios(staged_bios, scaled_progress(progress, 91, 95))
        minimum = int(info["Resources"]["BIOS"].get("MinimumValidBIOS", 1))
        if len(copied_bios) < minimum:
            return result(False, "install_failed", "DuckStation installed, but the required PlayStation BIOS set was not copied.", "bios_copy_failed")
        emit_progress(progress, 96, "Writing receipt")
        receipt = {
            "EmuKitModule": "duckstation",
            "ModuleVersion": module_version(info),
            "EmulatorVersion": version,
            "PinnedCommit": info["PinnedCommit"],
            "ReleaseTag": source["ReleaseTag"],
            "Asset": source["Asset"],
            "ArchiveSHA256": source["SHA256"],
            "SourceRepository": source["Repository"],
            "ReleasePublishedAt": asset.get("published_at"),
            "ResourceManifest": info["ResourceCatalog"]["ManifestURL"],
            "BIOS": copied_bios,
            "InstalledAtUTC": datetime.now(timezone.utc).isoformat(),
        }
        RECEIPT_PATH.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        emit_progress(progress, 98, "Verifying")
        return result(
            True,
            "installed",
            f'DuckStation "{version}" installed successfully.',
            details={
                "module_version": module_version(info),
                "version": version,
                "path": str(EXECUTABLE_PATH),
                "portable": True,
                "bios": copied_bios,
                "source": source["OfficialRepository"],
            },
        )
    except PermissionError as exc:
        return result(False, "install_failed", "DuckStation installation could not write one or more required files.", "permission_denied", str(exc))
    except Exception as exc:
        return result(False, "install_failed", "DuckStation installation failed unexpectedly.", "install_exception", str(exc))
    finally:
        shutil.rmtree(temp, ignore_errors=True)
        if not EXECUTABLE_PATH.exists():
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
