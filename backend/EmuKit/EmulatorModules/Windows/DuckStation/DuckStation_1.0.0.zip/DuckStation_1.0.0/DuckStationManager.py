from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

MODULE_DIR = (
    Path(sys.executable).resolve().parent
    if getattr(sys, "frozen", False)
    else Path(__file__).resolve().parent
)
if str(MODULE_DIR) not in sys.path:
    sys.path.insert(0, str(MODULE_DIR))

from _DuckStationCommon import *
import DuckStationInstaller
import DuckStationRepair
import DuckStationUninstall


def base(success: bool, operation: str, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "duckstation", "operation": operation, "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def check(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 10, "Checking host")
    supported, reason = is_supported_host()
    if not supported:
        return base(False, "check", "unsupported", reason or "DuckStation is not supported on this host.", "unsupported_host")
    info = load_info()
    version = emulator_version(info)
    if not EMULATOR_DIR.exists():
        return base(True, "check", "missing", "DuckStation is not installed.", details={"expected_path": str(EMULATOR_DIR)})
    emit_progress(progress, 30, "Checking executable")
    if not EXECUTABLE_PATH.is_file():
        return base(True, "check", "broken", "The DuckStation emulator directory exists but its Windows x64 executable is missing.", details={"expected_executable": str(EXECUTABLE_PATH)})
    if not PORTABLE_MARKER.is_file():
        return base(True, "check", "broken", "DuckStation is installed but portable mode is not enabled.", details={"expected": str(PORTABLE_MARKER)})
    if not INSTALLED_BIOS_DIR.is_dir():
        return base(True, "check", "broken", "DuckStation is installed but its BIOS directory is missing.", details={"expected": str(INSTALLED_BIOS_DIR)})
    emit_progress(progress, 55, "Checking BIOS")
    recognized_bios, ignored_bios = scan_bios_directory(INSTALLED_BIOS_DIR, info)
    minimum = int(info["Resources"]["BIOS"].get("MinimumValidBIOS", 1))
    if len(recognized_bios) < minimum:
        return base(True, "check", "broken", "DuckStation is installed but no recognized PlayStation BIOS image is available in its portable BIOS directory.", details={"bios_directory": str(INSTALLED_BIOS_DIR), "ignored": ignored_bios})
    emit_progress(progress, 75, "Checking receipt")
    receipt = read_receipt()
    if receipt is None:
        return base(True, "check", "broken", "DuckStation is present but its EmuKit installation receipt is missing or invalid.", details={"receipt": str(RECEIPT_PATH)})
    if receipt.get("EmulatorVersion") != version:
        return base(True, "check", "broken", "The installed DuckStation build does not match the module-pinned emulator version.", details={"installed_version": receipt.get("EmulatorVersion"), "pinned_version": version})
    installed_commit = str(receipt.get("PinnedCommit", "")).lower()
    pinned_commit = str(info.get("PinnedCommit", "")).lower()
    if installed_commit != pinned_commit:
        return base(True, "check", "broken", "The installed DuckStation receipt does not match the module-pinned upstream commit.", details={"installed_commit": installed_commit or None, "pinned_commit": pinned_commit})
    bios_details = [
        {"name": bios.get("name"), "region": bios.get("region"), "md5": bios.get("md5"), "file": Path(bios["path"]).name}
        for bios in recognized_bios
    ]
    emit_progress(progress, 95, "Ready")
    return base(
        True,
        "check",
        "installed",
        f'DuckStation "{version}" is installed and valid.',
        details={
            "module_version": module_version(info),
            "version": version,
            "path": str(EXECUTABLE_PATH),
            "portable": True,
            "bios": bios_details,
            "source": info["Source"]["OfficialRepository"],
        },
    )


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return DuckStationInstaller.install(progress=progress)


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return DuckStationUninstall.uninstall(progress=progress)


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return DuckStationRepair.repair(progress=progress)


def update(progress: ProgressCallback | None = None) -> dict[str, Any]:
    current = check(progress=scaled_progress(progress, 0, 20))
    if not current.get("success") and current.get("state") == "unsupported":
        current["operation"] = "update"
        return current
    if current.get("state") == "installed":
        return base(True, "update", "already_current", f'DuckStation "{emulator_version()}" is already the module-pinned version.', details=current.get("details"))
    repaired = DuckStationRepair.repair(progress=scaled_progress(progress, 20, 98))
    repaired["operation"] = "update"
    repaired["state"] = "updated" if repaired.get("success") else "update_failed"
    if repaired.get("success"):
        repaired["message"] = f'DuckStation was updated to pinned version "{emulator_version()}".'
    return repaired


def _run_cli() -> int:
    args = [arg for arg in sys.argv[1:] if arg.casefold() != "--json"]
    operation = args[0].casefold() if len(args) == 1 else ""
    handlers = {
        "check": check,
        "install": install,
        "uninstall": uninstall,
        "repair": repair,
        "update": update,
    }
    handler = handlers.get(operation)
    if handler is None:
        result = base(False, operation or "manager", "invalid_operation", "DuckStationManager requires one lifecycle operation: check, install, uninstall, repair, or update.", "invalid_operation")
    else:
        try:
            result = handler(progress=None)
        except Exception as exc:
            result = base(False, operation, f"{operation}_failed", f"DuckStationManager failed during {operation}.", "manager_exception", str(exc))
    print(json.dumps(result, ensure_ascii=False, default=str))
    return 0 if result.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(_run_cli())
