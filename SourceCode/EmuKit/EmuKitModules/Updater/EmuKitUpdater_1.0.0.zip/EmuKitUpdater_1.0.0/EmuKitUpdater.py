from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path


WAIT_TIMEOUT_SECONDS = 60.0


def _self_path() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve()
    return Path(__file__).resolve()


def _pid_running(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes

            process_query_limited_information = 0x1000
            handle = ctypes.windll.kernel32.OpenProcess(
                process_query_limited_information,
                False,
                pid,
            )
            if not handle:
                return False
            ctypes.windll.kernel32.CloseHandle(handle)
            return True
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False


def _wait_for_process_exit(pid: int, timeout: float = WAIT_TIMEOUT_SECONDS) -> None:
    deadline = time.monotonic() + timeout
    while _pid_running(pid):
        if time.monotonic() >= deadline:
            raise TimeoutError(f"EmuKit process {pid} did not exit within {timeout:.0f} seconds.")
        time.sleep(0.1)


def _safe_extract_zip(package: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    destination_root = destination.resolve()
    with zipfile.ZipFile(package, "r") as archive:
        for member in archive.infolist():
            target = (destination / member.filename).resolve()
            try:
                target.relative_to(destination_root)
            except ValueError as exc:
                raise ValueError(f'Unsafe path in Core package: "{member.filename}".') from exc
        archive.extractall(destination)


def _discover_core_root(extracted: Path, executable_relative: Path) -> Path:
    direct_executable = extracted / executable_relative
    if direct_executable.is_file():
        return extracted

    directories = [item for item in extracted.iterdir() if item.is_dir()]
    candidates = [item for item in directories if (item / executable_relative).is_file()]
    if len(candidates) != 1:
        raise ValueError(
            "Core package must contain exactly one runnable Core root, either at the package root "
            "or inside one top-level Core directory."
        )
    return candidates[0]


def _move_directory(source: Path, destination: Path) -> None:
    if destination.exists():
        raise FileExistsError(f'Update destination already exists: "{destination}".')
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(source), str(destination))


def _remove_path(path: Path) -> None:
    if path.is_dir():
        shutil.rmtree(path)
    elif path.exists():
        path.unlink()


def _apply_windows_folder_icon(core_directory: Path, executable_relative: Path) -> None:
    if os.name != "nt":
        return
    executable = (core_directory / executable_relative).resolve()
    try:
        executable.relative_to(core_directory.resolve())
    except ValueError:
        return
    if not executable.is_file():
        return

    desktop_ini = core_directory / "desktop.ini"
    icon_resource = executable_relative.as_posix().replace("/", "\\")
    desktop_ini.write_text(
        "[.ShellClassInfo]\r\n" f"IconResource={icon_resource},0\r\n",
        encoding="utf-16",
    )
    subprocess.run(
        ["attrib", "+h", "+s", str(desktop_ini)],
        capture_output=True,
        text=True,
        check=False,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    subprocess.run(
        ["attrib", "+r", str(core_directory)],
        capture_output=True,
        text=True,
        check=False,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )


def perform_update(
    *,
    old_pid: int,
    from_version: str,
    to_version: str,
    core_package: Path,
    core_directory: Path,
    core_executable: Path,
) -> Path:
    core_package = core_package.resolve()
    core_directory = core_directory.resolve()
    core_executable = Path(core_executable)
    if core_executable.is_absolute() or ".." in core_executable.parts:
        raise ValueError("Core executable must be a safe relative path inside the Core package.")

    if not core_package.is_file():
        raise FileNotFoundError(f'Core update package was not found: "{core_package}".')
    if not core_directory.is_dir():
        raise FileNotFoundError(f'Current Core directory was not found: "{core_directory}".')

    staging_root = core_package.parent.resolve()
    extracted_root = staging_root / "_extracted_core"
    old_core_backup = staging_root / f"OldCore_{from_version}"

    _remove_path(extracted_root)
    if old_core_backup.exists():
        raise FileExistsError(
            f'Previous Core backup still exists in the update staging directory: "{old_core_backup}".'
        )

    _safe_extract_zip(core_package, extracted_root)
    packaged_core = _discover_core_root(extracted_root, core_executable)
    expected_root_name = f"EmuKit_{to_version}"
    if packaged_core.name != expected_root_name:
        raise ValueError(
            f'Core package root must be "{expected_root_name}", got "{packaged_core.name}".'
        )
    new_executable = packaged_core / core_executable

    # Keep a cheap rollback executable with the new Core until the new Core has
    # initialized successfully and performs the fresh-update cleanup.
    old_executable = core_directory / core_executable
    backup_name = f"{core_executable.stem}Old{core_executable.suffix}"
    backup_relative = core_executable.with_name(backup_name)
    if old_executable.is_file():
        backup_target = packaged_core / backup_relative
        backup_target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(old_executable, backup_target)

    final_directory = core_directory.parent / packaged_core.name
    if final_directory == core_directory:
        # The package may intentionally retain the same directory name. Moving
        # the old Core into staging frees the canonical location for replacement.
        pass
    elif final_directory.exists():
        raise FileExistsError(f'New Core directory already exists: "{final_directory}".')

    _wait_for_process_exit(old_pid)

    moved_old = False
    installed_new = False
    try:
        _move_directory(core_directory, old_core_backup)
        moved_old = True
        _move_directory(packaged_core, final_directory)
        installed_new = True

        launched_executable = final_directory / core_executable
        if not launched_executable.is_file():
            raise FileNotFoundError(
                f'Updated Core executable was not installed: "{launched_executable}".'
            )

        _apply_windows_folder_icon(final_directory, core_executable)

        command = [
            str(launched_executable),
            "--fresh-update",
            "--from-version", from_version,
            "--updater-pid", str(os.getpid()),
            "--updater-path", str(_self_path()),
            "--staging-path", str(staging_root),
        ]
        subprocess.Popen(command, cwd=str(final_directory))
        return launched_executable
    except Exception:
        # If handoff fails before the new Core can take ownership, restore the
        # old directory so the user is not left without a runnable Core.
        try:
            if installed_new and final_directory.exists():
                _remove_path(final_directory)
            if moved_old and old_core_backup.exists() and not core_directory.exists():
                _move_directory(old_core_backup, core_directory)
        finally:
            raise


def _arguments(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Disposable updater for EmuKit Core.")
    parser.add_argument("--old-pid", required=True, type=int)
    parser.add_argument("--from-version", required=True)
    parser.add_argument("--to-version", required=True)
    parser.add_argument("--core-package", required=True)
    parser.add_argument("--core-directory", required=True)
    parser.add_argument("--core-executable", required=True)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _arguments(sys.argv[1:] if argv is None else argv)
    try:
        perform_update(
            old_pid=args.old_pid,
            from_version=args.from_version,
            to_version=args.to_version,
            core_package=Path(args.core_package),
            core_directory=Path(args.core_directory),
            core_executable=Path(args.core_executable),
        )
        return 0
    except Exception as exc:
        # The updater is intentionally dependency-free. A simple stderr message
        # is preferable to introducing another logging/runtime dependency.
        print(f"EmuKit update failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
