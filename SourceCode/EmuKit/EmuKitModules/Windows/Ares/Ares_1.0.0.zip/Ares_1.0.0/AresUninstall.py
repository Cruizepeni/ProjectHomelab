from __future__ import annotations

import shutil
from typing import Any

from _AresCommon import EMULATOR_DIR, ProgressCallback, emit_progress


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Preparing Uninstall', "Emulators/Ares")
    emit_progress(progress, 10, 'Removing Emulator', "Emulators/Ares")
    try:
        if not EMULATOR_DIR.exists():
            emit_progress(progress, 100, 'Uninstall Complete', "Emulators/Ares")
            return {"success": True, "module": "ares", "operation": "uninstall", "state": "uninstalled", "message": "Ares is already uninstalled.", "details": None}
        shutil.rmtree(EMULATOR_DIR)
        emit_progress(progress, 90, 'Verifying Uninstall', "Emulators/Ares")
        if EMULATOR_DIR.exists():
            return {"success": False, "module": "ares", "operation": "uninstall", "state": "uninstall_failed", "error": "emulator_directory_remains", "message": "Ares uninstall completed but its managed emulator directory still exists.", "details": {"path": str(EMULATOR_DIR)}}
        emit_progress(progress, 100, 'Uninstall Complete', "Emulators/Ares")
        return {"success": True, "module": "ares", "operation": "uninstall", "state": "uninstalled", "message": "Ares uninstalled successfully.", "details": None}
    except PermissionError as exc:
        return {"success": False, "module": "ares", "operation": "uninstall", "state": "uninstall_failed", "error": "permission_denied", "message": "Ares could not be uninstalled because one or more files are in use or EmuKit does not have permission to remove them.", "details": str(exc)}
    except Exception as exc:
        return {"success": False, "module": "ares", "operation": "uninstall", "state": "uninstall_failed", "error": "uninstall_exception", "message": "Ares could not be uninstalled.", "details": str(exc)}
