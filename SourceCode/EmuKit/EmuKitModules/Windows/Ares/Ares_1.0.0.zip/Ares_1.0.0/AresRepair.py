from __future__ import annotations

from typing import Any

from _AresCommon import ProgressCallback, scaled_progress
import AresInstaller
import AresUninstall


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Preparing Repair', "Emulators/Ares")
    uninstall_result = AresUninstall.uninstall(progress=scaled_progress(progress, 0, 15))
    if not uninstall_result.get("success"):
        return {"success": False, "module": "ares", "operation": "repair", "state": "repair_failed", "error": uninstall_result.get("error", "uninstall_failed"), "message": "Ares repair could not continue because the existing emulator could not be removed.", "details": uninstall_result}
    install_result = AresInstaller.install(progress=scaled_progress(progress, 15, 98))
    if not install_result.get("success"):
        return {"success": False, "module": "ares", "operation": "repair", "state": "repair_failed", "error": install_result.get("error", "install_failed"), "message": ("Ares was removed successfully, but the clean reinstall failed. " + str(install_result.get("message", ""))).strip(), "details": install_result}
    emit_progress(progress, 100, 'Repair Complete', "Version 148")
    return {"success": True, "module": "ares", "operation": "repair", "state": "repaired", "message": 'Ares repaired successfully.', "details": install_result.get("details")}
