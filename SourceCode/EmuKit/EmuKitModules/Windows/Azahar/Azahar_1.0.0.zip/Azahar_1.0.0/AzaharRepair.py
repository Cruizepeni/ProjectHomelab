from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

import AzaharInstaller
import AzaharUninstall
from _AzaharCommon import (
    EMULATOR_DIR,
    PORTABLE_DIR,
    RECOVERY_PARENT,
    ProgressCallback,
    emit_progress,
    emulator_version,
    scaled_progress,
)


def move_state_out(state_dir: Path) -> list[str]:
    preserved: list[str] = []

    if PORTABLE_DIR.exists():
        shutil.move(str(PORTABLE_DIR), str(state_dir / "user"))
        preserved.append("user")

    return preserved


def restore_state(state_dir: Path) -> list[str]:
    restored: list[str] = []
    portable = state_dir / "user"

    if portable.exists():
        if PORTABLE_DIR.exists():
            shutil.rmtree(PORTABLE_DIR)
        shutil.move(str(portable), str(PORTABLE_DIR))
        restored.append("user")

    return restored


def repair(progress: ProgressCallback | None = None) -> dict:
    emit_progress(progress, 3, 'Preparing Repair', "Emulators/Azahar")
    RECOVERY_PARENT.mkdir(parents=True, exist_ok=True)
    recovery_root = Path(
        tempfile.mkdtemp(prefix="Azahar-Repair-", dir=str(RECOVERY_PARENT))
    )
    state_dir = recovery_root / "state"
    state_dir.mkdir(parents=True, exist_ok=True)

    try:
        emit_progress(progress, 3, 'Preserving User Data', "user/")
        preserved = move_state_out(state_dir) if EMULATOR_DIR.exists() else []

        uninstall_result = AzaharUninstall.uninstall(
            progress=scaled_progress(progress, 5, 18)
        )

        if not uninstall_result.get("success"):
            EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
            restored = restore_state(state_dir)
            return {
                "success": False,
                "module": "azahar",
                "operation": "repair",
                "state": "repair_failed",
                "error": uninstall_result.get("error", "uninstall_failed"),
                "message": "Azahar repair could not continue because the existing emulator could not be removed. Portable state was restored.",
                "details": {
                    "uninstall": uninstall_result,
                    "restored": restored,
                },
            }

        install_result = AzaharInstaller.install(
            progress=scaled_progress(progress, 18, 91)
        )

        if not install_result.get("success"):
            EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
            restored = restore_state(state_dir)
            return {
                "success": False,
                "module": "azahar",
                "operation": "repair",
                "state": "repair_failed",
                "error": install_result.get("error", "install_failed"),
                "message": (
                    "Azahar was removed successfully, but the clean reinstall failed. "
                    "Portable state was restored. "
                    + str(install_result.get("message", ""))
                ).strip(),
                "details": {
                    "install": install_result,
                    "restored": restored,
                },
            }

        emit_progress(progress, 93, 'Restoring User Data', "user/")
        restored = restore_state(state_dir)

        emit_progress(progress, 100, 'Repair Complete', "Version 2126.1.1")
        return {
            "success": True,
            "module": "azahar",
            "operation": "repair",
            "state": "repaired",
            "message": 'Azahar repaired successfully.',
            "details": {
                "install": install_result.get("details"),
                "preserved": preserved,
                "restored": restored,
            },
        }
    except Exception as exc:
        return {
            "success": False,
            "module": "azahar",
            "operation": "repair",
            "state": "repair_failed",
            "error": "repair_exception",
            "message": "Azahar repair failed unexpectedly.",
            "details": {
                "exception": str(exc),
                "recovery_path": str(recovery_root),
            },
        }
    finally:
        shutil.rmtree(recovery_root, ignore_errors=True)
