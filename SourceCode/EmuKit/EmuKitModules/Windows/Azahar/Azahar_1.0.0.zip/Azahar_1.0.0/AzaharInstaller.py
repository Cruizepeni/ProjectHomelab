from __future__ import annotations

import shutil
import urllib.error
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

from _AzaharCommon import (
    EMULATOR_DIR,
    EXECUTABLE_PATH,
    PORTABLE_DIR,
    ProgressCallback,
    emit_progress,
    emulator_version,
    hash_file,
    is_supported_host,
    load_info,
    module_version,
    write_receipt,
)


def result(
    success: bool,
    state: str,
    message: str,
    error: str | None = None,
    details: Any = None,
) -> dict[str, Any]:
    value = {
        "success": success,
        "module": "azahar",
        "operation": "install",
        "state": state,
        "message": message,
        "details": details,
    }
    if error:
        value["error"] = error
    return value


def download(
    url: str,
    destination: Path,
    expected_size: int,
    progress: ProgressCallback | None = None,
) -> dict[str, Any] | None:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "EmuKit-Azahar/1.0.0", "Accept": "*/*"},
    )
    try:
        with urllib.request.urlopen(request, timeout=180) as response, destination.open("wb") as output:
            raw_total = response.headers.get("Content-Length")
            total = int(raw_total) if raw_total and raw_total.isdigit() else None
            received = 0

            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                output.write(block)
                received += len(block)
                if total and total > 0:
                    emit_progress(progress, min(100, round(received * 100 / total)), 'Downloading Emulator', "azahar-windows-msys2-2126.1.1.zip")

        if not destination.is_file():
            return result(
                False,
                "download_failed",
                "The official Azahar Windows archive was not created.",
                "download_missing",
                {"url": url},
            )

        size = destination.stat().st_size
        if size != expected_size:
            return result(
                False,
                "download_failed",
                "The downloaded Azahar archive has an unexpected size.",
                "download_size_mismatch",
                {
                    "url": url,
                    "expected_size": expected_size,
                    "actual_size": size,
                },
            )

        emit_progress(progress, 100, 'Downloading Emulator', "azahar-windows-msys2-2126.1.1.zip")
        return None
    except urllib.error.HTTPError as exc:
        return result(
            False,
            "download_failed",
            "The official Azahar Windows archive could not be downloaded.",
            "download_http_error",
            {"http_status": exc.code, "url": url},
        )
    except Exception as exc:
        return result(
            False,
            "download_failed",
            "The official Azahar Windows archive could not be downloaded.",
            "download_failed",
            str(exc),
        )


def safe_extract(archive: zipfile.ZipFile, destination: Path) -> None:
    root = destination.resolve()

    for member in archive.infolist():
        relative = PurePosixPath(member.filename.replace("\\", "/"))
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f'Unsafe archive member: "{member.filename}"')
        target = (destination / Path(*relative.parts)).resolve()
        if target != root and root not in target.parents:
            raise ValueError(f'Unsafe archive member: "{member.filename}"')

    archive.extractall(destination)


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Checking Host', "Windows x86_64")
    supported, reason = is_supported_host()

    if not supported:
        return result(
            False,
            "unsupported",
            reason or "Azahar is not supported on this host.",
            "unsupported_host",
        )

    info = load_info()
    source = info["Source"]

    if EMULATOR_DIR.exists():
        return result(
            False,
            "install_failed",
            "The Azahar managed emulator directory already exists. Use Repair for a clean reinstall.",
            "emulator_directory_already_exists",
            {"path": str(EMULATOR_DIR)},
        )

    emit_progress(progress, 7, 'Preparing Install', "azahar-windows-msys2-2126.1.1.zip")
    EMULATOR_DIR.mkdir(parents=True, exist_ok=False)
    temp_dir = EMULATOR_DIR / ".install"
    extract_dir = temp_dir / "extracted"
    archive_path = temp_dir / source["Asset"]
    temp_dir.mkdir(parents=True, exist_ok=True)
    extract_dir.mkdir(parents=True, exist_ok=True)
    install_complete = False

    try:
        def download_progress(
            percent: int | None = None,
            stage: str | None = None,
            message: str | None = None,
        ) -> None:
            mapped = None if percent is None else 10 + round(
                max(0, min(100, int(percent))) * 50 / 100
            )
            emit_progress(progress, mapped, stage, message)

        download_error = download(
            source["DownloadURL"],
            archive_path,
            int(source["Size"]),
            download_progress,
        )
        if download_error is not None:
            return download_error

        emit_progress(progress, 63, 'Validating Emulator', "azahar-windows-msys2-2126.1.1.zip")
        archive_sha256 = hash_file(archive_path).lower()
        expected_sha256 = str(source["SHA256"]).lower()

        if archive_sha256 != expected_sha256:
            return result(
                False,
                "invalid_download",
                "The downloaded Azahar archive failed SHA-256 validation.",
                "archive_hash_mismatch",
                {
                    "expected_sha256": expected_sha256,
                    "actual_sha256": archive_sha256,
                    "path": str(archive_path),
                },
            )

        try:
            with zipfile.ZipFile(archive_path, "r") as archive:
                bad_member = archive.testzip()
                if bad_member is not None:
                    return result(
                        False,
                        "extract_failed",
                        f'The official Azahar ZIP failed its internal CRC check at "{bad_member}".',
                        "archive_crc_failed",
                        {"member": bad_member},
                    )

                emit_progress(progress, 70, 'Extracting Emulator', "azahar-windows-msys2-2126.1.1.zip")
                safe_extract(archive, extract_dir)
        except (zipfile.BadZipFile, ValueError) as exc:
            return result(
                False,
                "extract_failed",
                "The downloaded Azahar archive could not be safely extracted.",
                "invalid_archive",
                str(exc),
            )

        extracted_executable = next(
            (
                path for path in extract_dir.rglob("*")
                if path.is_file() and path.name.casefold() == "azahar.exe"
            ),
            None,
        )

        if extracted_executable is None:
            return result(
                False,
                "install_failed",
                "The Azahar archive extracted successfully, but azahar.exe was not found.",
                "executable_validation_failed",
            )

        emit_progress(progress, 79, 'Installing Emulator', "azahar.exe")
        extracted_root = extracted_executable.parent

        for item in extracted_root.iterdir():
            destination = EMULATOR_DIR / item.name
            if destination.exists():
                if destination.is_dir():
                    shutil.rmtree(destination)
                else:
                    destination.unlink()

            if item.is_dir():
                shutil.copytree(item, destination)
            else:
                shutil.copy2(item, destination)

        if not EXECUTABLE_PATH.is_file():
            return result(
                False,
                "install_failed",
                "Azahar extraction completed but azahar.exe is missing.",
                "post_install_validation_failed",
                {"expected": str(EXECUTABLE_PATH)},
            )

        emit_progress(progress, 87, 'Configuring Emulator', "user/")
        PORTABLE_DIR.mkdir(parents=True, exist_ok=True)

        if not PORTABLE_DIR.is_dir():
            return result(
                False,
                "install_failed",
                "Azahar portable user storage could not be established.",
                "portable_mode_failed",
                {"portable_directory": str(PORTABLE_DIR)},
            )

        emit_progress(progress, 92, 'Verifying Installation', "azahar.exe")
        if EXECUTABLE_PATH.stat().st_size < 1_000_000:
            return result(
                False,
                "install_failed",
                "The installed Azahar executable is unexpectedly small.",
                "executable_validation_failed",
                {
                    "path": str(EXECUTABLE_PATH),
                    "size": EXECUTABLE_PATH.stat().st_size,
                },
            )

        executable_sha256 = hash_file(EXECUTABLE_PATH).lower()

        emit_progress(progress, 97, 'Writing Receipt', ".emukit_install.json")
        write_receipt(
            {
                "EmuKitModule": "azahar",
                "Name": info["Name"],
                "ModuleVersion": module_version(info),
                "EmulatorVersion": emulator_version(info),
                "ReleaseTag": source["ReleaseTag"],
                "ReleaseCommit": source["ReleaseCommit"],
                "Asset": source["Asset"],
                "DownloadURL": source["DownloadURL"],
                "ArchiveSHA256": archive_sha256,
                "ExecutableSHA256": executable_sha256,
                "PortableMode": True,
                "PortableDirectory": str(PORTABLE_DIR),
                "SourceRepository": source["Repository"],
                "InstalledAtUTC": datetime.now(timezone.utc).isoformat(),
            }
        )

        emit_progress(progress, 100, 'Install Complete', "Version 2126.1.1")
        install_complete = True

        return result(
            True,
            "installed",
            f'Azahar Version {emulator_version(info)} installed successfully.',
            details={
                "module_version": module_version(info),
                "version": emulator_version(info),
                "path": str(EXECUTABLE_PATH),
                "systems": ["nintendo.3ds"],
                "archive_sha256": archive_sha256,
                "executable_sha256": executable_sha256,
                "portable_directory": str(PORTABLE_DIR),
                "bios_required": False,
                "user_supplied_resources_required": False,
                "ffmpeg_required": False,
                "source": source["OfficialWebsite"],
            },
        )
    except PermissionError as exc:
        return result(
            False,
            "install_failed",
            "Azahar installation could not write one or more required files.",
            "permission_denied",
            str(exc),
        )
    except Exception as exc:
        return result(
            False,
            "install_failed",
            "Azahar installation failed unexpectedly.",
            "install_exception",
            str(exc),
        )
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        if not install_complete:
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
