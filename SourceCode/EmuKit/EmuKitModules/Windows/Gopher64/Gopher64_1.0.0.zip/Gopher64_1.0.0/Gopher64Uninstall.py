from __future__ import annotations

import shutil
from typing import Any

from _Gopher64Common import EMULATOR_DIR, ProgressCallback, emit_progress


def result(
    success: bool,
    state: str,
    message: str,
    error: str | None = None,
    details: Any = None,
) -> dict[str, Any]:
    value = {
        "success": success,
        "module": "gopher64",
        "operation": "uninstall",
        "state": state,
        "message": message,
        "details": details,
    }
    if error:
        value["error"] = error
    return value


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Preparing Uninstall', "Emulators/Gopher64")
    emit_progress(progress, 10, 'Removing Emulator', "Emulators/Gopher64")
    try:
        if not EMULATOR_DIR.exists():
            return result(
                True,
                "uninstalled",
                "Gopher64 is already uninstalled.",
            )

        shutil.rmtree(EMULATOR_DIR)
        emit_progress(progress, 90, 'Verifying Uninstall', "Emulators/Gopher64")

        if EMULATOR_DIR.exists():
            return result(
                False,
                "uninstall_failed",
                "Gopher64 uninstall completed but its managed emulator directory still exists.",
                "emulator_directory_remains",
                {"path": str(EMULATOR_DIR)},
            )

        emit_progress(progress, 100, 'Uninstall Complete', "Emulators/Gopher64")
        return result(
            True,
            "uninstalled",
            'Gopher64 uninstalled successfully.',
        )
    except PermissionError as exc:
        return result(
            False,
            "uninstall_failed",
            "Gopher64 could not be uninstalled because one or more files are in use or EmuKit does not have permission to remove them.",
            "permission_denied",
            str(exc),
        )
    except Exception as exc:
        return result(
            False,
            "uninstall_failed",
            "Gopher64 could not be uninstalled.",
            "uninstall_exception",
            str(exc),
        )
