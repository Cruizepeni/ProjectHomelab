from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

import Gopher64Installer
import Gopher64Uninstall
from _Gopher64Common import (
    EMULATOR_DIR,
    PORTABLE_DATA_DIR,
    RECOVERY_PARENT,
    ProgressCallback,
    emit_progress,
    emulator_version,
    scaled_progress,
)


def move_state_out(state_dir: Path) -> list[str]:
    preserved: list[str] = []
    if PORTABLE_DATA_DIR.exists():
        shutil.move(str(PORTABLE_DATA_DIR), str(state_dir / "portable_data"))
        preserved.append("portable_data")
    return preserved


def restore_state(state_dir: Path) -> list[str]:
    restored: list[str] = []
    portable_data = state_dir / "portable_data"

    if portable_data.exists():
        if PORTABLE_DATA_DIR.exists():
            shutil.rmtree(PORTABLE_DATA_DIR)
        shutil.move(str(portable_data), str(PORTABLE_DATA_DIR))
        restored.append("portable_data")

    return restored


def repair(progress: ProgressCallback | None = None) -> dict:
    emit_progress(progress, 3, 'Preparing Repair', "Emulators/Gopher64")
    RECOVERY_PARENT.mkdir(parents=True, exist_ok=True)
    recovery_root = Path(
        tempfile.mkdtemp(prefix="Gopher64-Repair-", dir=str(RECOVERY_PARENT))
    )
    state_dir = recovery_root / "state"
    state_dir.mkdir(parents=True, exist_ok=True)
    preserved: list[str] = []

    try:
        emit_progress(progress, 3, 'Preserving User Data', "portable_data/")

        if EMULATOR_DIR.exists():
            preserved = move_state_out(state_dir)

        uninstall_result = Gopher64Uninstall.uninstall(
            progress=scaled_progress(progress, 5, 18)
        )

        if not uninstall_result.get("success"):
            try:
                EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
                restored = restore_state(state_dir)
            except Exception as restore_exc:
                return {
                    "success": False,
                    "module": "gopher64",
                    "operation": "repair",
                    "state": "repair_failed",
                    "error": "uninstall_and_restore_failed",
                    "message": "Gopher64 repair could not remove the existing emulator and portable-state recovery also failed.",
                    "details": {
                        "uninstall": uninstall_result,
                        "restore_exception": str(restore_exc),
                        "recovery_path": str(recovery_root),
                    },
                }

            return {
                "success": False,
                "module": "gopher64",
                "operation": "repair",
                "state": "repair_failed",
                "error": uninstall_result.get("error", "uninstall_failed"),
                "message": "Gopher64 repair could not continue because the existing emulator could not be removed. Portable state was restored.",
                "details": {
                    "uninstall": uninstall_result,
                    "restored": restored,
                },
            }

        install_result = Gopher64Installer.install(
            progress=scaled_progress(progress, 18, 91)
        )

        if not install_result.get("success"):
            try:
                EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
                restored = restore_state(state_dir)
            except Exception as restore_exc:
                return {
                    "success": False,
                    "module": "gopher64",
                    "operation": "repair",
                    "state": "repair_failed",
                    "error": "install_and_restore_failed",
                    "message": "Gopher64 reinstall failed and portable-state recovery could not be completed automatically.",
                    "details": {
                        "install": install_result,
                        "restore_exception": str(restore_exc),
                        "recovery_path": str(recovery_root),
                    },
                }

            return {
                "success": False,
                "module": "gopher64",
                "operation": "repair",
                "state": "repair_failed",
                "error": install_result.get("error", "install_failed"),
                "message": (
                    "Gopher64 was removed successfully, but the clean reinstall failed. "
                    "Portable state was restored. "
                    + str(install_result.get("message", ""))
                ).strip(),
                "details": {
                    "install": install_result,
                    "restored": restored,
                },
            }

        emit_progress(progress, 93, 'Restoring User Data', "portable_data/")

        try:
            restored = restore_state(state_dir)
        except Exception as exc:
            return {
                "success": False,
                "module": "gopher64",
                "operation": "repair",
                "state": "repair_failed",
                "error": "state_restore_failed",
                "message": "Gopher64 was reinstalled, but its preserved portable state could not be restored automatically.",
                "details": {
                    "install": install_result,
                    "exception": str(exc),
                    "recovery_path": str(recovery_root),
                },
            }

        emit_progress(progress, 100, 'Repair Complete', "Version 1.1.36")

        return {
            "success": True,
            "module": "gopher64",
            "operation": "repair",
            "state": "repaired",
            "message": 'Gopher64 repaired successfully.',
            "details": {
                "install": install_result.get("details"),
                "preserved": preserved,
                "restored": restored,
            },
        }
    finally:
        shutil.rmtree(recovery_root, ignore_errors=True)
