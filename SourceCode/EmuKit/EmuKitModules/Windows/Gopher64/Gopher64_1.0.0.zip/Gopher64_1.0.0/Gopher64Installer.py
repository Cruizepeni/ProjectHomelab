from __future__ import annotations

import shutil
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from _Gopher64Common import (
    EMULATOR_DIR,
    EXECUTABLE_PATH,
    PORTABLE_MARKER,
    ProgressCallback,
    emit_progress,
    emulator_version,
    hash_file,
    is_supported_host,
    load_info,
    module_version,
    write_receipt,
)


def result(
    success: bool,
    state: str,
    message: str,
    error: str | None = None,
    details: Any = None,
) -> dict[str, Any]:
    value = {
        "success": success,
        "module": "gopher64",
        "operation": "install",
        "state": state,
        "message": message,
        "details": details,
    }
    if error:
        value["error"] = error
    return value


def download(
    url: str,
    destination: Path,
    expected_size: int,
    progress: ProgressCallback | None = None,
) -> dict[str, Any] | None:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "EmuKit-Gopher64/1.0.0", "Accept": "*/*"},
    )
    try:
        with urllib.request.urlopen(request, timeout=180) as response, destination.open("wb") as output:
            raw_total = response.headers.get("Content-Length")
            total = int(raw_total) if raw_total and raw_total.isdigit() else None
            received = 0
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                output.write(block)
                received += len(block)
                if total and total > 0:
                    emit_progress(progress, min(100, round(received * 100 / total)), 'Downloading Emulator', "gopher64-windows-x86_64.exe")

        if not destination.is_file():
            return result(
                False,
                "download_failed",
                "The official Gopher64 Windows executable was not created.",
                "download_missing",
                {"url": url},
            )

        size = destination.stat().st_size
        if size != expected_size:
            return result(
                False,
                "download_failed",
                "The downloaded Gopher64 executable has an unexpected size.",
                "download_size_mismatch",
                {
                    "url": url,
                    "expected_size": expected_size,
                    "actual_size": size,
                },
            )

        emit_progress(progress, 100, 'Downloading Emulator', "gopher64-windows-x86_64.exe")
        return None
    except urllib.error.HTTPError as exc:
        return result(
            False,
            "download_failed",
            "The official Gopher64 Windows executable could not be downloaded.",
            "download_http_error",
            {"http_status": exc.code, "url": url},
        )
    except Exception as exc:
        return result(
            False,
            "download_failed",
            "The official Gopher64 Windows executable could not be downloaded.",
            "download_failed",
            str(exc),
        )


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Checking Host', "Windows x86_64")
    supported, reason = is_supported_host()
    if not supported:
        return result(
            False,
            "unsupported",
            reason or "Gopher64 is not supported on this host.",
            "unsupported_host",
        )

    info = load_info()
    source = info["Source"]

    if EMULATOR_DIR.exists():
        return result(
            False,
            "install_failed",
            "The Gopher64 managed emulator directory already exists. Use Repair for a clean reinstall.",
            "emulator_directory_already_exists",
            {"path": str(EMULATOR_DIR)},
        )

    emit_progress(progress, 7, 'Preparing Install', "gopher64-windows-x86_64.exe")
    EMULATOR_DIR.mkdir(parents=True, exist_ok=False)
    temp_dir = EMULATOR_DIR / ".install"
    downloaded_path = temp_dir / source["Asset"]
    temp_dir.mkdir(parents=True, exist_ok=True)
    install_complete = False

    try:
        def download_progress(
            percent: int | None = None,
            stage: str | None = None,
            message: str | None = None,
        ) -> None:
            mapped = None if percent is None else 10 + round(
                max(0, min(100, int(percent))) * 58 / 100
            )
            emit_progress(progress, mapped, stage, message)

        download_error = download(
            source["DownloadURL"],
            downloaded_path,
            int(source["Size"]),
            download_progress,
        )
        if download_error is not None:
            return download_error

        emit_progress(progress, 72, 'Validating Emulator', "gopher64-windows-x86_64.exe")
        asset_sha256 = hash_file(downloaded_path).lower()
        expected_sha256 = str(source["SHA256"]).lower()

        if asset_sha256 != expected_sha256:
            return result(
                False,
                "invalid_download",
                "The downloaded Gopher64 executable failed SHA-256 validation.",
                "asset_hash_mismatch",
                {
                    "expected_sha256": expected_sha256,
                    "actual_sha256": asset_sha256,
                    "path": str(downloaded_path),
                },
            )

        emit_progress(progress, 82, 'Installing Emulator', "Gopher64.exe")
        shutil.copy2(downloaded_path, EXECUTABLE_PATH)

        emit_progress(progress, 87, 'Configuring Emulator', "portable.txt")
        PORTABLE_MARKER.touch(exist_ok=True)

        if not EXECUTABLE_PATH.is_file():
            return result(
                False,
                "install_failed",
                "Gopher64 installation completed but Gopher64.exe is missing.",
                "post_install_validation_failed",
                {"expected": str(EXECUTABLE_PATH)},
            )

        if not PORTABLE_MARKER.is_file():
            return result(
                False,
                "install_failed",
                "Gopher64 was installed but portable mode could not be enabled.",
                "portable_marker_missing",
                {"expected": str(PORTABLE_MARKER)},
            )

        emit_progress(progress, 92, 'Verifying Installation', "Gopher64.exe")
        executable_sha256 = hash_file(EXECUTABLE_PATH).lower()

        if executable_sha256 != asset_sha256:
            return result(
                False,
                "install_failed",
                "The installed Gopher64 executable does not match the validated download.",
                "installed_hash_mismatch",
                {
                    "download_sha256": asset_sha256,
                    "installed_sha256": executable_sha256,
                },
            )

        emit_progress(progress, 97, 'Writing Receipt', ".emukit_install.json")
        write_receipt(
            {
                "EmuKitModule": "gopher64",
                "Name": info["Name"],
                "ModuleVersion": module_version(info),
                "EmulatorVersion": emulator_version(info),
                "ReleaseTag": source["ReleaseTag"],
                "ReleaseCommit": source["ReleaseCommit"],
                "Asset": source["Asset"],
                "DownloadURL": source["DownloadURL"],
                "AssetSHA256": asset_sha256,
                "ExecutableSHA256": executable_sha256,
                "PortableMode": True,
                "SourceRepository": source["Repository"],
                "InstalledAtUTC": datetime.now(timezone.utc).isoformat(),
            }
        )

        emit_progress(progress, 100, 'Install Complete', "Version 1.1.36")
        install_complete = True

        return result(
            True,
            "installed",
            f'Gopher64 Version {emulator_version(info)} installed successfully.',
            details={
                "module_version": module_version(info),
                "version": emulator_version(info),
                "path": str(EXECUTABLE_PATH),
                "systems": ["nintendo.n64"],
                "asset_sha256": asset_sha256,
                "executable_sha256": executable_sha256,
                "portable_marker": str(PORTABLE_MARKER),
                "bios_required": False,
                "source": source["OfficialWebsite"],
            },
        )
    except PermissionError as exc:
        return result(
            False,
            "install_failed",
            "Gopher64 installation could not write one or more required files.",
            "permission_denied",
            str(exc),
        )
    except Exception as exc:
        return result(
            False,
            "install_failed",
            "Gopher64 installation failed unexpectedly.",
            "install_exception",
            str(exc),
        )
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        if not install_complete:
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
