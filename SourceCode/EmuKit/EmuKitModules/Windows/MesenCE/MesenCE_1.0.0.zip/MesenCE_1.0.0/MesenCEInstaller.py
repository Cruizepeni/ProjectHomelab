from __future__ import annotations

import shutil
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

from _MesenCECommon import (
    EMULATOR_DIR,
    EXECUTABLE_PATH,
    SETTINGS_PATH,
    ProgressCallback,
    emit_progress,
    emulator_version,
    hash_file,
    is_supported_host,
    load_info,
    module_version,
    resource_status,
    write_receipt,
)


def result(
    success: bool,
    state: str,
    message: str,
    error: str | None = None,
    details: Any = None,
) -> dict[str, Any]:
    value = {
        "success": success,
        "module": "mesence",
        "operation": "install",
        "state": state,
        "message": message,
        "details": details,
    }
    if error:
        value["error"] = error
    return value


def download(
    url: str,
    destination: Path,
    minimum_size: int,
    progress: ProgressCallback | None = None,
) -> dict[str, Any] | None:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "EmuKit-MesenCE/1.0.0", "Accept": "*/*"},
    )
    try:
        with urllib.request.urlopen(request, timeout=180) as response, destination.open("wb") as output:
            raw_total = response.headers.get("Content-Length")
            total = int(raw_total) if raw_total and raw_total.isdigit() else None
            received = 0
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                output.write(block)
                received += len(block)
                if total and total > 0:
                    emit_progress(progress, min(100, round(received * 100 / total)), 'Downloading Emulator', "Mesen_2.2.1_Windows.zip")
        if not destination.is_file():
            return result(
                False,
                "download_failed",
                "The official MesenCE Windows archive was not created.",
                "download_missing",
                {"url": url},
            )
        if destination.stat().st_size < minimum_size:
            return result(
                False,
                "download_failed",
                "The downloaded MesenCE archive is unexpectedly small.",
                "download_validation_failed",
                {
                    "url": url,
                    "size": destination.stat().st_size,
                    "minimum_size": minimum_size,
                },
            )
        emit_progress(progress, 100, 'Downloading Emulator', "Mesen_2.2.1_Windows.zip")
        return None
    except urllib.error.HTTPError as exc:
        return result(
            False,
            "download_failed",
            "The official MesenCE Windows archive could not be downloaded.",
            "download_http_error",
            {"http_status": exc.code, "url": url},
        )
    except Exception as exc:
        return result(
            False,
            "download_failed",
            "The official MesenCE Windows archive could not be downloaded.",
            "download_failed",
            str(exc),
        )


def safe_extract(archive: zipfile.ZipFile, destination: Path) -> None:
    root = destination.resolve()
    for member in archive.infolist():
        path = PurePosixPath(member.filename.replace("\\", "/"))
        if path.is_absolute() or ".." in path.parts:
            raise ValueError(f'Unsafe archive member: "{member.filename}"')
        target = (destination / Path(*path.parts)).resolve()
        if target != root and root not in target.parents:
            raise ValueError(f'Unsafe archive member: "{member.filename}"')
    archive.extractall(destination)


def install_resources(info: dict[str, Any], progress: ProgressCallback | None = None) -> list[dict[str, Any]]:
    base = str(info["ResourceCatalog"]["RawBaseURL"]).rstrip("/")
    results: list[dict[str, Any]] = []
    items = list(info.get("Resources", {}).items())
    total = max(1, len(items))
    for index, (resource_id, spec) in enumerate(items):
        if not isinstance(spec, dict):
            continue
        destination = EMULATOR_DIR / str(spec["Destination"])
        destination.parent.mkdir(parents=True, exist_ok=True)
        expected_size = int(spec["Size"])
        expected_sha = str(spec["SHA256"]).lower()
        expected_md5 = str(spec["MD5"]).lower()

        item_start = 87 + round(index * (92 - 87) / total)
        item_end = 87 + round((index + 1) * (92 - 87) / total)
        emit_progress(progress, item_start, "Validating Resources", destination.name)

        if destination.is_file():
            try:
                if (
                    destination.stat().st_size == expected_size
                    and hash_file(destination).lower() == expected_sha
                    and hash_file(destination, "md5").lower() == expected_md5
                ):
                    results.append({
                        "resource": resource_id,
                        "state": "already_present",
                        "path": str(destination),
                    })
                    continue
            except OSError:
                pass

        relative = str(spec["CatalogPath"]).replace("\\", "/")
        encoded = "/".join(urllib.parse.quote(part) for part in relative.split("/"))
        url = f"{base}/{encoded}"
        temp = destination.with_suffix(destination.suffix + ".download")

        try:
            emit_progress(progress, item_start, "Downloading Resources", destination.name)
            request = urllib.request.Request(
                url,
                headers={"User-Agent": "EmuKit-MesenCE/1.0.0", "Accept": "*/*"},
            )
            with urllib.request.urlopen(request, timeout=60) as response, temp.open("wb") as output:
                shutil.copyfileobj(response, output)
            emit_progress(progress, item_end, "Validating Resources", destination.name)
            valid = (
                temp.stat().st_size == expected_size
                and hash_file(temp).lower() == expected_sha
                and hash_file(temp, "md5").lower() == expected_md5
            )
            if not valid:
                results.append({
                    "resource": resource_id,
                    "state": "invalid",
                    "url": url,
                })
                temp.unlink(missing_ok=True)
                continue
            emit_progress(progress, item_end, "Installing Resources", destination.name)
            shutil.move(str(temp), str(destination))
            results.append({
                "resource": resource_id,
                "state": "installed",
                "path": str(destination),
            })
        except Exception as exc:
            temp.unlink(missing_ok=True)
            results.append({
                "resource": resource_id,
                "state": "unavailable",
                "url": url,
                "error": str(exc),
            })
    return results


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Checking Host', "Windows x86_64")
    supported, reason = is_supported_host()
    if not supported:
        return result(
            False,
            "unsupported",
            reason or "MesenCE is not supported on this host.",
            "unsupported_host",
        )

    info = load_info()
    source = info["Source"]

    if EMULATOR_DIR.exists():
        return result(
            False,
            "install_failed",
            "The MesenCE managed emulator directory already exists. Use Repair for a clean reinstall.",
            "emulator_directory_already_exists",
            {"path": str(EMULATOR_DIR)},
        )

    emit_progress(progress, 7, 'Preparing Install', "Mesen_2.2.1_Windows.zip")
    EMULATOR_DIR.mkdir(parents=True, exist_ok=False)
    temp_dir = EMULATOR_DIR / ".install"
    extract_dir = temp_dir / "extracted"
    archive_path = temp_dir / source["Asset"]
    temp_dir.mkdir(parents=True, exist_ok=True)
    extract_dir.mkdir(parents=True, exist_ok=True)
    install_complete = False

    try:
        def download_progress(
            percent: int | None = None,
            stage: str | None = None,
            message: str | None = None,
        ) -> None:
            mapped = None if percent is None else 10 + round(
                max(0, min(100, int(percent))) * 48 / 100
            )
            emit_progress(progress, mapped, stage, message)

        download_error = download(
            source["DownloadURL"],
            archive_path,
            10_000_000,
            download_progress,
        )
        if download_error is not None:
            return download_error

        emit_progress(progress, 61, 'Validating Emulator', "Mesen_2.2.1_Windows.zip")
        archive_sha256 = hash_file(archive_path).lower()
        expected_sha256 = str(source["SHA256"]).lower()
        if archive_sha256 != expected_sha256:
            return result(
                False,
                "invalid_download",
                "The downloaded MesenCE archive failed SHA-256 validation.",
                "archive_hash_mismatch",
                {
                    "expected_sha256": expected_sha256,
                    "actual_sha256": archive_sha256,
                    "path": str(archive_path),
                },
            )

        try:
            with zipfile.ZipFile(archive_path, "r") as archive:
                bad_member = archive.testzip()
                if bad_member is not None:
                    return result(
                        False,
                        "extract_failed",
                        f'The official MesenCE ZIP failed its internal CRC check at "{bad_member}".',
                        "archive_crc_failed",
                        {"member": bad_member},
                    )
                emit_progress(progress, 68, 'Extracting Emulator', "Mesen_2.2.1_Windows.zip")
                safe_extract(archive, extract_dir)
        except (zipfile.BadZipFile, ValueError) as exc:
            return result(
                False,
                "extract_failed",
                "The downloaded MesenCE archive could not be safely extracted.",
                "invalid_archive",
                str(exc),
            )

        extracted_executable = next(
            (
                path
                for path in extract_dir.rglob("*")
                if path.is_file() and path.name.casefold() == "mesen.exe"
            ),
            None,
        )
        if extracted_executable is None:
            return result(
                False,
                "install_failed",
                "The MesenCE archive extracted successfully, but Mesen.exe was not found.",
                "executable_validation_failed",
                {"archive": str(archive_path)},
            )

        emit_progress(progress, 76, 'Installing Emulator', "Mesen.exe")
        extracted_root = extracted_executable.parent
        for item in extracted_root.iterdir():
            destination = EMULATOR_DIR / item.name
            if destination.exists():
                if destination.is_dir():
                    shutil.rmtree(destination)
                else:
                    destination.unlink()
            if item.is_dir():
                shutil.copytree(item, destination)
            else:
                shutil.copy2(item, destination)

        if not EXECUTABLE_PATH.is_file():
            return result(
                False,
                "install_failed",
                "MesenCE extraction completed but Mesen.exe is missing.",
                "post_install_validation_failed",
                {"expected": str(EXECUTABLE_PATH)},
            )

        emit_progress(progress, 83, 'Configuring Emulator', "settings.json")
        if not SETTINGS_PATH.exists():
            SETTINGS_PATH.write_text("{}\n", encoding="utf-8")
        if not SETTINGS_PATH.is_file():
            return result(
                False,
                "install_failed",
                "MesenCE portable settings marker could not be created.",
                "portable_mode_failed",
                {"path": str(SETTINGS_PATH)},
            )

        resource_results = install_resources(info, progress)
        firmware = resource_status()

        emit_progress(progress, 93, 'Verifying Installation', "Mesen.exe")
        if EXECUTABLE_PATH.stat().st_size < 100_000:
            return result(
                False,
                "install_failed",
                "The installed MesenCE executable is unexpectedly small.",
                "executable_validation_failed",
                {
                    "path": str(EXECUTABLE_PATH),
                    "size": EXECUTABLE_PATH.stat().st_size,
                },
            )
        executable_sha256 = hash_file(EXECUTABLE_PATH).lower()

        emit_progress(progress, 97, 'Writing Receipt', ".emukit_install.json")
        write_receipt({
            "EmuKitModule": "mesence",
            "Name": info["Name"],
            "ModuleVersion": module_version(info),
            "EmulatorVersion": emulator_version(info),
            "ReleaseTag": source["ReleaseTag"],
            "ReleaseCommit": source["ReleaseCommit"],
            "Asset": source["Asset"],
            "DownloadURL": source["DownloadURL"],
            "ArchiveSHA256": archive_sha256,
            "ExecutableSHA256": executable_sha256,
            "PortableMode": True,
            "SourceRepository": source["Repository"],
            "InstalledAtUTC": datetime.now(timezone.utc).isoformat(),
        })

        unavailable: list[str] = []
        for system_id, system in info["Systems"].items():
            required = list(system.get("FirmwareResources", []))
            if required and not all(firmware.get(resource_id, {}).get("ready") for resource_id in required):
                unavailable.append(system_id)

        emit_progress(progress, 100, 'Install Complete', "Version 2.2.1")
        install_complete = True
        return result(
            True,
            "installed",
            f'MesenCE Version {emulator_version(info)} installed successfully.',
            details={
                "module_version": module_version(info),
                "version": emulator_version(info),
                "path": str(EXECUTABLE_PATH),
                "systems": list(info["Systems"].keys()),
                "systems_registered": len(info["Systems"]),
                "systems_unavailable_without_firmware": unavailable,
                "resource_results": resource_results,
                "firmware": firmware,
                "portable_settings": str(SETTINGS_PATH),
                "source": source["OfficialWebsite"],
            },
        )
    except PermissionError as exc:
        return result(
            False,
            "install_failed",
            "MesenCE installation could not write one or more required files.",
            "permission_denied",
            str(exc),
        )
    except Exception as exc:
        return result(
            False,
            "install_failed",
            "MesenCE installation failed unexpectedly.",
            "install_exception",
            str(exc),
        )
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        if not install_complete:
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
