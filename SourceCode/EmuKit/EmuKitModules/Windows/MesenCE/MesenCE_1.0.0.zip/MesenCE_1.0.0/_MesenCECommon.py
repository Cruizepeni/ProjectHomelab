from __future__ import annotations

import hashlib
import json
import platform
import sys
from pathlib import Path
from typing import Any, Callable

MODULE_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
INFO_PATH = MODULE_DIR / "EmuKitMesenCEInfo.json"
ROOT_MARKER = ".AppRoot"
ProgressCallback = Callable[[int | None, str | None, str | None], None]


def resolve_root() -> Path:
    current = MODULE_DIR.resolve()
    for candidate in (current, *current.parents):
        if (candidate / ROOT_MARKER).is_file():
            return candidate
    if MODULE_DIR.parent.name.casefold() == "emukitmodules":
        return MODULE_DIR.parent.parent
    return MODULE_DIR.parent


ROOT = resolve_root()
EMULATOR_DIR = ROOT / "Emulators" / "MesenCE"
EXECUTABLE_PATH = EMULATOR_DIR / "Mesen.exe"
SETTINGS_PATH = EMULATOR_DIR / "settings.json"
FIRMWARE_DIR = EMULATOR_DIR / "Firmware"
RECEIPT_PATH = EMULATOR_DIR / ".emukit_install.json"
RECOVERY_PARENT = ROOT / "Appdata" / "Cache" / "EmuKit" / "MesenCE"
PERSISTENT_ENTRIES = (
    "settings.json",
    "RecentGames",
    "Screenshots",
    "Avi",
    "Wave",
    "Movies",
    "HdPacks",
    "Saves",
    "SaveStates",
    "Cheats",
    "GameConfig",
    "Firmware",
    "Debugger",
    "Backups",
    "Tests",
    "Dumps",
    "Satellaview",
)


def load_info() -> dict[str, Any]:
    return json.loads(INFO_PATH.read_text(encoding="utf-8"))


def module_version(info: dict[str, Any] | None = None) -> str:
    source = info if isinstance(info, dict) else load_info()
    return str(source["ModuleVersion"])


def emulator_version(info: dict[str, Any] | None = None) -> str:
    source = info if isinstance(info, dict) else load_info()
    return str(source["EmulatorVersion"])


def emit_progress(
    progress: ProgressCallback | None,
    percent: int | None,
    stage: str | None,
    message: str | None = None,
) -> None:
    if progress is not None:
        progress(percent, stage, message)


def scaled_progress(
    progress: ProgressCallback | None,
    start: int,
    end: int,
) -> ProgressCallback | None:
    if progress is None:
        return None

    def callback(
        percent: int | None = None,
        stage: str | None = None,
        message: str | None = None,
    ) -> None:
        if percent is None:
            mapped = None
        else:
            bounded = max(0, min(100, int(percent)))
            mapped = start + round((end - start) * bounded / 100)
        progress(mapped, stage, message)

    return callback


def is_supported_host() -> tuple[bool, str | None]:
    if platform.system().casefold() != "windows":
        return False, "MesenCE 1.0.0 currently supports Windows only."
    if platform.machine().casefold() not in {"amd64", "x86_64"}:
        return False, f'MesenCE 1.0.0 requires Windows x86_64. Current architecture: "{platform.machine()}".'
    return True, None


def hash_file(path: Path, algorithm: str = "sha256") -> str:
    digest = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_receipt() -> dict[str, Any] | None:
    try:
        value = json.loads(RECEIPT_PATH.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def write_receipt(value: dict[str, Any]) -> None:
    RECEIPT_PATH.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def resource_status() -> dict[str, Any]:
    info = load_info()
    values: dict[str, Any] = {}
    for resource_id, spec in info.get("Resources", {}).items():
        destination = EMULATOR_DIR / str(spec["Destination"])
        entry: dict[str, Any] = {
            "path": str(destination),
            "ready": False,
            "required_for_systems": list(spec.get("RequiredForSystems", [])),
        }
        if destination.is_file():
            try:
                size = destination.stat().st_size
                sha256 = hash_file(destination).lower()
                md5 = hash_file(destination, "md5").lower()
                entry.update({
                    "present": True,
                    "size": size,
                    "sha256": sha256,
                    "md5": md5,
                    "ready": (
                        size == int(spec["Size"])
                        and sha256 == str(spec["SHA256"]).lower()
                        and md5 == str(spec["MD5"]).lower()
                    ),
                })
            except OSError as exc:
                entry.update({"present": True, "error": str(exc)})
        else:
            entry["present"] = False
        values[resource_id] = entry
    return values
