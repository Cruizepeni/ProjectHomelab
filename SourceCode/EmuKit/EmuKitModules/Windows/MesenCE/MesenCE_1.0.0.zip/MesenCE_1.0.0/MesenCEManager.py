from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

MODULE_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
if str(MODULE_DIR) not in sys.path:
    sys.path.insert(0, str(MODULE_DIR))

import MesenCEInstaller
import MesenCERepair
import MesenCEUninstall
from _MesenCECommon import (
    EMULATOR_DIR,
    EXECUTABLE_PATH,
    RECEIPT_PATH,
    SETTINGS_PATH,
    ProgressCallback,
    emit_progress,
    emulator_version,
    hash_file,
    is_supported_host,
    load_info,
    module_version,
    read_receipt,
    resource_status,
    scaled_progress,
)

MODULE_ID = "mesence"
MODULE_NAME = "MesenCE"


def base(
    success: bool,
    operation: str,
    state: str,
    message: str,
    error: str | None = None,
    details: Any = None,
) -> dict[str, Any]:
    value = {
        "success": success,
        "module": MODULE_ID,
        "operation": operation,
        "state": state,
        "message": message,
        "details": details,
    }
    if error:
        value["error"] = error
    return value


def check(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 5, 'Checking Host', "Windows x86_64")
    supported, reason = is_supported_host()
    if not supported:
        return base(
            False,
            "check",
            "unsupported",
            reason or "MesenCE is not supported on this host.",
            "unsupported_host",
        )

    info = load_info()
    source = info["Source"]
    version = emulator_version(info)

    if not EMULATOR_DIR.exists():
        return base(
            True,
            "check",
            "missing",
            "MesenCE is not installed.",
            details={"expected_path": str(EMULATOR_DIR)},
        )

    emit_progress(progress, 20, 'Checking Emulator', "Mesen.exe")
    if not EXECUTABLE_PATH.is_file():
        return base(
            True,
            "check",
            "broken",
            "The MesenCE managed emulator directory exists but Mesen.exe is missing.",
            details={"expected_executable": str(EXECUTABLE_PATH)},
        )

    emit_progress(progress, 32, 'Checking Configuration', "settings.json")
    if not SETTINGS_PATH.is_file():
        return base(
            True,
            "check",
            "broken",
            "MesenCE is installed but its portable settings marker is missing.",
            details={"expected_settings": str(SETTINGS_PATH)},
        )

    emit_progress(progress, 45, 'Checking Receipt', ".emukit_install.json")
    receipt = read_receipt()
    if receipt is None:
        return base(
            True,
            "check",
            "broken",
            "MesenCE is present but its EmuKit installation receipt is missing or invalid.",
            details={"receipt": str(RECEIPT_PATH)},
        )

    if str(receipt.get("EmulatorVersion", "")) != version:
        return base(
            True,
            "check",
            "broken",
            "The installed MesenCE build does not match the emulator version pinned by this module.",
            details={
                "installed_version": receipt.get("EmulatorVersion"),
                "pinned_version": version,
            },
        )

    for key, label in (
        ("ReleaseTag", "release tag"),
        ("ReleaseCommit", "release commit"),
        ("Asset", "Windows asset"),
    ):
        pinned = str(source.get(key, "") or "")
        installed = str(receipt.get(key, "") or "")
        if pinned and installed.casefold() != pinned.casefold():
            return base(
                True,
                "check",
                "broken",
                f"The MesenCE installation receipt does not match the module-pinned {label}.",
                details={
                    f"installed_{key.casefold()}": installed or None,
                    f"pinned_{key.casefold()}": pinned,
                },
            )

    expected_archive_sha256 = str(source["SHA256"]).lower()
    if str(receipt.get("ArchiveSHA256", "")).lower() != expected_archive_sha256:
        return base(
            True,
            "check",
            "broken",
            "The MesenCE installation receipt does not match the pinned official archive checksum.",
            details={
                "installed_archive_sha256": receipt.get("ArchiveSHA256"),
                "pinned_archive_sha256": expected_archive_sha256,
            },
        )

    emit_progress(progress, 68, 'Checking Integrity', "Mesen.exe")
    expected_executable_sha256 = str(receipt.get("ExecutableSHA256", "")).lower()
    if not expected_executable_sha256:
        return base(
            True,
            "check",
            "broken",
            "The MesenCE EmuKit receipt does not contain its installed executable checksum.",
        )

    try:
        actual_executable_sha256 = hash_file(EXECUTABLE_PATH).lower()
    except OSError as exc:
        return base(
            True,
            "check",
            "broken",
            "Mesen.exe could not be read for integrity validation.",
            details=str(exc),
        )

    if actual_executable_sha256 != expected_executable_sha256:
        return base(
            True,
            "check",
            "broken",
            "Mesen.exe no longer matches the EmuKit-managed installation.",
            details={
                "expected_sha256": expected_executable_sha256,
                "actual_sha256": actual_executable_sha256,
            },
        )

    emit_progress(progress, 82, 'Checking Resources', "Firmware/")
    firmware = resource_status()
    unavailable: list[str] = []
    for system_id, system in info["Systems"].items():
        required = list(system.get("FirmwareResources", []))
        if required and not all(firmware.get(resource_id, {}).get("ready") for resource_id in required):
            unavailable.append(system_id)

    emit_progress(progress, 100, 'Check Complete', "Version 2.2.1")
    message = f'MesenCE Version {version} is installed and valid.'
    if unavailable:
        message += " Some firmware-dependent systems do not currently have validated firmware."

    return base(
        True,
        "check",
        "installed",
        message,
        details={
            "module_version": module_version(info),
            "version": version,
            "path": str(EXECUTABLE_PATH),
            "portable": True,
            "systems": list(info["Systems"].keys()),
            "systems_registered": len(info["Systems"]),
            "systems_unavailable_without_firmware": unavailable,
            "firmware": firmware,
            "source": source["OfficialWebsite"],
        },
    )


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return MesenCEInstaller.install(progress=progress)


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return MesenCEUninstall.uninstall(progress=progress)


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return MesenCERepair.repair(progress=progress)


def update(progress: ProgressCallback | None = None) -> dict[str, Any]:
    current = check(progress=scaled_progress(progress, 0, 20))
    if not current.get("success") and current.get("state") == "unsupported":
        current["operation"] = "update"
        return current

    if current.get("state") == "installed":
        return base(
            True,
            "update",
            "already_current",
            f'MesenCE Version {emulator_version()} is already current.',
            details=current.get("details"),
        )

    repaired = MesenCERepair.repair(progress=scaled_progress(progress, 20, 100))
    repaired["operation"] = "update"
    repaired["state"] = "updated" if repaired.get("success") else "update_failed"
    if repaired.get("success"):
        repaired["message"] = f'MesenCE Version {emulator_version()} updated successfully.'
    return repaired


def write_record(record: dict[str, Any]) -> None:
    print(
        json.dumps(
            record,
            ensure_ascii=False,
            default=str,
            separators=(",", ":"),
        ),
        flush=True,
    )


def stream_progress(
    percent: int | None = None,
    stage: str | None = None,
    message: str | None = None,
) -> None:
    write_record({
        "type": "progress",
        "percent": percent,
        "stage": stage,
        "message": message,
    })


def run_cli() -> int:
    raw_args = sys.argv[1:]
    json_flags = [arg for arg in raw_args if arg.casefold() == "--json"]
    args = [arg for arg in raw_args if arg.casefold() != "--json"]
    operation = args[0].casefold() if len(args) == 1 else ""
    handlers = {
        "check": check,
        "install": install,
        "uninstall": uninstall,
        "repair": repair,
        "update": update,
    }
    handler = handlers.get(operation)

    if len(json_flags) != 1 or handler is None:
        result = base(
            False,
            operation or "manager",
            "invalid_operation",
            "MesenCEManager requires one lifecycle operation: check, install, uninstall, repair, or update.",
            "invalid_operation",
        )
    else:
        try:
            result = handler(progress=stream_progress)
        except Exception as exc:
            result = base(
                False,
                operation,
                f"{operation}_failed",
                f"MesenCEManager failed during {operation}.",
                "manager_exception",
                str(exc),
            )

    write_record({"type": "result", "result": result})
    return 0 if result.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(run_cli())
