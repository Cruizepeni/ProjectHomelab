from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

import MesenCEInstaller
import MesenCEUninstall
from _MesenCECommon import (
    EMULATOR_DIR,
    PERSISTENT_ENTRIES,
    RECOVERY_PARENT,
    ProgressCallback,
    emit_progress,
    emulator_version,
    load_info,
    scaled_progress,
)


def merge_restore(source: Path, destination: Path) -> None:
    if source.is_dir():
        destination.mkdir(parents=True, exist_ok=True)
        for child in list(source.iterdir()):
            merge_restore(child, destination / child.name)
        source.rmdir()
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        if destination.is_dir():
            shutil.rmtree(destination)
        else:
            destination.unlink()
    shutil.move(str(source), str(destination))


def managed_firmware_destinations() -> set[str]:
    info = load_info()
    values: set[str] = set()
    for spec in info.get("Resources", {}).values():
        if not isinstance(spec, dict):
            continue
        destination = Path(str(spec["Destination"]))
        try:
            relative = destination.relative_to("Firmware")
        except ValueError:
            continue
        values.add(str(relative).replace("\\", "/"))
    return values


def preserve_state(state_dir: Path) -> list[str]:
    state_dir.mkdir(parents=True, exist_ok=False)
    preserved: list[str] = []
    for name in PERSISTENT_ENTRIES:
        source = EMULATOR_DIR / name
        if source.exists():
            shutil.move(str(source), str(state_dir / name))
            preserved.append(name)

    firmware_dir = state_dir / "Firmware"
    if firmware_dir.is_dir():
        for relative in managed_firmware_destinations():
            path = firmware_dir / Path(relative)
            if path.is_file():
                path.unlink()
        for directory in sorted(
            (item for item in firmware_dir.rglob("*") if item.is_dir()),
            key=lambda item: len(item.parts),
            reverse=True,
        ):
            try:
                directory.rmdir()
            except OSError:
                pass
        try:
            firmware_dir.rmdir()
            if "Firmware" in preserved:
                preserved.remove("Firmware")
        except OSError:
            pass
    return preserved


def restore_state(state_dir: Path) -> list[str]:
    restored: list[str] = []
    if not state_dir.exists():
        return restored
    for item in list(state_dir.iterdir()):
        restored.append(item.name)
        merge_restore(item, EMULATOR_DIR / item.name)
    state_dir.rmdir()
    return restored


def repair(progress: ProgressCallback | None = None) -> dict:
    emit_progress(progress, 3, 'Preparing Repair', "Emulators/MesenCE")
    RECOVERY_PARENT.mkdir(parents=True, exist_ok=True)
    recovery_root = Path(
        tempfile.mkdtemp(prefix="MesenCE-Repair-", dir=str(RECOVERY_PARENT))
    )
    state_dir = recovery_root / "state"
    preserved: list[str] = []

    try:
        emit_progress(progress, 3, 'Preserving User Data', "settings.json + RecentGames/ + Screenshots/ + Avi/ + Wave/ + Movies/ + HdPacks/ + Saves/ + SaveStates/ + Cheats/ + GameConfig/ + Firmware/ + Debugger/ + Backups/ + Tests/ + Dumps/ + Satellaview/")
        if EMULATOR_DIR.exists():
            preserved = preserve_state(state_dir)

        uninstall_result = MesenCEUninstall.uninstall(
            progress=scaled_progress(progress, 5, 18)
        )
        if not uninstall_result.get("success"):
            try:
                EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
                restored = restore_state(state_dir) if state_dir.exists() else []
            except Exception as restore_exc:
                return {
                    "success": False,
                    "module": "mesence",
                    "operation": "repair",
                    "state": "repair_failed",
                    "error": "uninstall_and_restore_failed",
                    "message": "MesenCE repair could not remove the existing emulator and portable-state recovery also failed.",
                    "details": {
                        "uninstall": uninstall_result,
                        "restore_exception": str(restore_exc),
                        "recovery_path": str(recovery_root),
                    },
                }
            return {
                "success": False,
                "module": "mesence",
                "operation": "repair",
                "state": "repair_failed",
                "error": uninstall_result.get("error", "uninstall_failed"),
                "message": "MesenCE repair could not continue because the existing emulator could not be removed. Portable state was restored.",
                "details": {"uninstall": uninstall_result, "restored": restored},
            }

        install_result = MesenCEInstaller.install(
            progress=scaled_progress(progress, 18, 91)
        )
        if not install_result.get("success"):
            try:
                EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
                restored = restore_state(state_dir) if state_dir.exists() else []
            except Exception as restore_exc:
                return {
                    "success": False,
                    "module": "mesence",
                    "operation": "repair",
                    "state": "repair_failed",
                    "error": "install_and_restore_failed",
                    "message": "MesenCE reinstall failed and portable-state recovery could not be completed automatically.",
                    "details": {
                        "install": install_result,
                        "restore_exception": str(restore_exc),
                        "recovery_path": str(recovery_root),
                    },
                }
            return {
                "success": False,
                "module": "mesence",
                "operation": "repair",
                "state": "repair_failed",
                "error": install_result.get("error", "install_failed"),
                "message": (
                    "MesenCE was removed successfully, but the clean reinstall failed. "
                    "Portable state was restored. "
                    + str(install_result.get("message", ""))
                ).strip(),
                "details": {"install": install_result, "restored": restored},
            }

        emit_progress(progress, 93, 'Restoring User Data', "settings.json + RecentGames/ + Screenshots/ + Avi/ + Wave/ + Movies/ + HdPacks/ + Saves/ + SaveStates/ + Cheats/ + GameConfig/ + Firmware/ + Debugger/ + Backups/ + Tests/ + Dumps/ + Satellaview/")
        try:
            restored = restore_state(state_dir) if state_dir.exists() else []
        except Exception as exc:
            return {
                "success": False,
                "module": "mesence",
                "operation": "repair",
                "state": "repair_failed",
                "error": "state_restore_failed",
                "message": "MesenCE was reinstalled, but its preserved portable state could not be restored automatically.",
                "details": {
                    "install": install_result,
                    "exception": str(exc),
                    "recovery_path": str(recovery_root),
                },
            }

        emit_progress(progress, 100, 'Repair Complete', "Version 2.2.1")
        return {
            "success": True,
            "module": "mesence",
            "operation": "repair",
            "state": "repaired",
            "message": 'MesenCE repaired successfully.',
            "details": {
                "install": install_result.get("details"),
                "preserved": preserved,
                "restored": restored,
            },
        }
    finally:
        try:
            if recovery_root.exists() and not any(recovery_root.iterdir()):
                recovery_root.rmdir()
        except OSError:
            pass
