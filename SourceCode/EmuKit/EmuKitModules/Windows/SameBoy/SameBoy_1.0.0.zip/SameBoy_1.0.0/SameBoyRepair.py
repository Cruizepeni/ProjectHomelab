from __future__ import annotations

from typing import Any

from _SameBoyCommon import ProgressCallback, emulator_version, scaled_progress
import SameBoyInstaller
import SameBoyUninstall


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Preparing Repair', "Emulators/SameBoy")
    uninstall_result = SameBoyUninstall.uninstall(
        progress=scaled_progress(progress, 0, 15)
    )
    if not uninstall_result.get("success"):
        return {
            "success": False,
            "module": "sameboy",
            "operation": "repair",
            "state": "repair_failed",
            "error": uninstall_result.get("error", "uninstall_failed"),
            "message": "SameBoy repair could not continue because the existing managed emulator could not be removed.",
            "details": uninstall_result,
        }

    install_result = SameBoyInstaller.install(
        progress=scaled_progress(progress, 15, 100)
    )
    if not install_result.get("success"):
        return {
            "success": False,
            "module": "sameboy",
            "operation": "repair",
            "state": "repair_failed",
            "error": install_result.get("error", "install_failed"),
            "message": (
                "SameBoy was removed successfully, but the clean reinstall failed. "
                + str(install_result.get("message", ""))
            ).strip(),
            "details": install_result,
        }

    emit_progress(progress, 100, 'Repair Complete', "Version 1.0.3")
    return {
        "success": True,
        "module": "sameboy",
        "operation": "repair",
        "state": "repaired",
        "message": 'SameBoy repaired successfully.',
        "details": install_result.get("details"),
    }
