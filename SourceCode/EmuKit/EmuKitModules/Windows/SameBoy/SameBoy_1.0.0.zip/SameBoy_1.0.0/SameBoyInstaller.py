from __future__ import annotations

import shutil
import urllib.error
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

from _SameBoyCommon import (
    EMULATOR_DIR,
    EXECUTABLE_PATH,
    ProgressCallback,
    emit_progress,
    emulator_version,
    hash_file,
    is_supported_host,
    load_info,
    module_version,
    write_receipt,
)


def result(
    success: bool,
    state: str,
    message: str,
    error: str | None = None,
    details: Any = None,
) -> dict[str, Any]:
    value = {
        "success": success,
        "module": "sameboy",
        "operation": "install",
        "state": state,
        "message": message,
        "details": details,
    }
    if error:
        value["error"] = error
    return value


def _download(
    url: str,
    destination: Path,
    progress: ProgressCallback | None = None,
) -> dict[str, Any] | None:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "EmuKit-SameBoy/1.0.0", "Accept": "*/*"},
    )
    try:
        with urllib.request.urlopen(request, timeout=180) as response, destination.open("wb") as output:
            content_type = str(response.headers.get("Content-Type", "")).lower()
            raw_total = response.headers.get("Content-Length")
            total = int(raw_total) if raw_total and raw_total.isdigit() else None
            received = 0
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                output.write(block)
                received += len(block)
                if total and total > 0:
                    emit_progress(progress, min(100, round(received * 100 / total)), 'Downloading Emulator', "sameboy_winsdl_v1.0.3.zip")
        if not destination.is_file():
            return result(
                False,
                "download_failed",
                "The official SameBoy Windows archive was not created.",
                "download_missing",
                {"url": url},
            )
        size = destination.stat().st_size
        if size < 1_000_000:
            return result(
                False,
                "download_failed",
                "The downloaded SameBoy archive is unexpectedly small.",
                "download_validation_failed",
                {"url": url, "size": size, "content_type": content_type},
            )
        emit_progress(progress, 100, 'Downloading Emulator', "sameboy_winsdl_v1.0.3.zip")
        return None
    except urllib.error.HTTPError as exc:
        return result(
            False,
            "download_failed",
            "The official SameBoy Windows archive could not be downloaded.",
            "download_http_error",
            {"http_status": exc.code, "url": url},
        )
    except Exception as exc:
        return result(
            False,
            "download_failed",
            "The official SameBoy Windows archive could not be downloaded.",
            "download_failed",
            str(exc),
        )


def _safe_extract(archive: zipfile.ZipFile, destination: Path) -> None:
    root = destination.resolve()
    for member in archive.infolist():
        path = PurePosixPath(member.filename.replace("\\", "/"))
        if path.is_absolute() or ".." in path.parts:
            raise ValueError(f'Unsafe archive member: "{member.filename}"')
        target = (destination / Path(*path.parts)).resolve()
        if target != root and root not in target.parents:
            raise ValueError(f'Unsafe archive member: "{member.filename}"')
    archive.extractall(destination)


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Checking Host', "Windows x86_64")
    supported, reason = is_supported_host()
    if not supported:
        return result(
            False,
            "unsupported",
            reason or "SameBoy is not supported on this host.",
            "unsupported_host",
        )

    info = load_info()
    version = emulator_version(info)
    source = info["Source"]

    if EMULATOR_DIR.exists():
        return result(
            False,
            "install_failed",
            "The SameBoy managed emulator directory already exists. Use Repair for a clean reinstall.",
            "emulator_directory_already_exists",
            {"path": str(EMULATOR_DIR)},
        )

    emit_progress(progress, 7, 'Preparing Install', "sameboy_winsdl_v1.0.3.zip")
    EMULATOR_DIR.mkdir(parents=True, exist_ok=False)
    temp_dir = EMULATOR_DIR / ".install"
    extract_dir = temp_dir / "extracted"
    archive_path = temp_dir / source["Asset"]
    temp_dir.mkdir(parents=True, exist_ok=True)
    extract_dir.mkdir(parents=True, exist_ok=True)
    install_complete = False

    try:
        def download_progress(
            percent: int | None = None,
            stage: str | None = None,
            message: str | None = None,
        ) -> None:
            mapped = None if percent is None else 10 + round(
                max(0, min(100, int(percent))) * 52 / 100
            )
            emit_progress(progress, mapped, stage, message)

        download_error = _download(
            source["DownloadURL"],
            archive_path,
            download_progress,
        )
        if download_error is not None:
            return download_error

        emit_progress(progress, 65, 'Validating Emulator', "sameboy_winsdl_v1.0.3.zip")
        archive_sha256 = hash_file(archive_path).lower()
        expected_sha256 = str(source.get("SHA256", "")).strip().lower()
        if expected_sha256 and archive_sha256 != expected_sha256:
            return result(
                False,
                "invalid_download",
                "The downloaded SameBoy archive failed SHA-256 validation.",
                "archive_hash_mismatch",
                {
                    "expected_sha256": expected_sha256,
                    "actual_sha256": archive_sha256,
                    "path": str(archive_path),
                },
            )

        try:
            with zipfile.ZipFile(archive_path, "r") as archive:
                bad_member = archive.testzip()
                if bad_member is not None:
                    return result(
                        False,
                        "extract_failed",
                        f'The official SameBoy ZIP failed its internal CRC check at "{bad_member}".',
                        "archive_crc_failed",
                        {"member": bad_member},
                    )
                emit_progress(progress, 72, 'Extracting Emulator', "sameboy_winsdl_v1.0.3.zip")
                _safe_extract(archive, extract_dir)
        except (zipfile.BadZipFile, ValueError) as exc:
            return result(
                False,
                "extract_failed",
                "The downloaded SameBoy archive could not be safely extracted.",
                "invalid_archive",
                str(exc),
            )

        extracted_executable = next(
            (
                path
                for path in extract_dir.rglob("*")
                if path.is_file() and path.name.casefold() == "sameboy.exe"
            ),
            None,
        )
        if extracted_executable is None:
            return result(
                False,
                "install_failed",
                "The SameBoy archive extracted successfully, but sameboy.exe was not found.",
                "executable_validation_failed",
                {"archive": str(archive_path)},
            )

        emit_progress(progress, 80, 'Installing Emulator', "sameboy.exe")
        extracted_root = extracted_executable.parent
        for item in extracted_root.iterdir():
            destination = EMULATOR_DIR / item.name
            if destination.exists():
                if destination.is_dir():
                    shutil.rmtree(destination)
                else:
                    destination.unlink()
            if item.is_dir():
                shutil.copytree(item, destination)
            else:
                shutil.copy2(item, destination)

        if not EXECUTABLE_PATH.is_file():
            return result(
                False,
                "install_failed",
                "SameBoy extraction completed but sameboy.exe is missing.",
                "post_install_validation_failed",
                {"expected": str(EXECUTABLE_PATH)},
            )

        emit_progress(progress, 90, 'Verifying Installation', "sameboy.exe")
        executable_sha256 = hash_file(EXECUTABLE_PATH).lower()
        if EXECUTABLE_PATH.stat().st_size < 100_000:
            return result(
                False,
                "install_failed",
                "The installed SameBoy executable is unexpectedly small.",
                "executable_validation_failed",
                {
                    "path": str(EXECUTABLE_PATH),
                    "size": EXECUTABLE_PATH.stat().st_size,
                },
            )

        emit_progress(progress, 96, 'Writing Receipt', ".emukit_install.json")
        write_receipt(
            {
                "EmuKitModule": "sameboy",
                "Name": info["Name"],
                "ModuleVersion": module_version(info),
                "EmulatorVersion": version,
                "ReleaseTag": source["ReleaseTag"],
                "ReleaseCommit": source.get("ReleaseCommit"),
                "Asset": source["Asset"],
                "DownloadURL": source["DownloadURL"],
                "ArchiveSHA256": archive_sha256,
                "ExecutableSHA256": executable_sha256,
                "SourceRepository": source["Repository"],
                "InstalledAtUTC": datetime.now(timezone.utc).isoformat(),
            }
        )

        emit_progress(progress, 100, 'Install Complete', "Version 1.0.3")
        install_complete = True
        return result(
            True,
            "installed",
            f'SameBoy Version {emulator_version(info)} installed successfully.',
            details={
                "module_version": module_version(info),
                "version": version,
                "path": str(EXECUTABLE_PATH),
                "systems": ["nintendo.gameboy", "nintendo.gameboycolor"],
                "archive_sha256": archive_sha256,
                "executable_sha256": executable_sha256,
                "source": source["OfficialWebsite"],
                "bios_required": False,
            },
        )
    except PermissionError as exc:
        return result(
            False,
            "install_failed",
            "SameBoy installation could not write one or more required files.",
            "permission_denied",
            str(exc),
        )
    except Exception as exc:
        return result(
            False,
            "install_failed",
            "SameBoy installation failed unexpectedly.",
            "install_exception",
            str(exc),
        )
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        if not install_complete:
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
