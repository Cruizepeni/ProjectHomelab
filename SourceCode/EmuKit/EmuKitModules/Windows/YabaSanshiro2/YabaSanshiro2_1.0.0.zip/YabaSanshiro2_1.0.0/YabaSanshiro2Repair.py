from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from typing import Any

import YabaSanshiro2Installer
import YabaSanshiro2Uninstall
from _YabaSanshiro2Common import (
    BIOS_DIR,
    EMULATOR_DIR,
    INI_PATH,
    RECOVERY_PARENT,
    ProgressCallback,
    emit_progress,
    emulator_version,
    scaled_progress,
)


def move_state_out(state_dir: Path) -> list[str]:
    preserved: list[str] = []
    if INI_PATH.exists():
        shutil.move(str(INI_PATH), str(state_dir / "yabause.ini"))
        preserved.append("yabause.ini")
    if BIOS_DIR.exists():
        shutil.move(str(BIOS_DIR), str(state_dir / "BIOS"))
        preserved.append("BIOS")
    return preserved


def restore_state(state_dir: Path) -> list[str]:
    restored: list[str] = []
    ini = state_dir / "yabause.ini"
    if ini.exists():
        if INI_PATH.exists():
            INI_PATH.unlink()
        shutil.move(str(ini), str(INI_PATH))
        restored.append("yabause.ini")
    bios = state_dir / "BIOS"
    if bios.exists():
        if BIOS_DIR.exists():
            shutil.rmtree(BIOS_DIR)
        shutil.move(str(bios), str(BIOS_DIR))
        restored.append("BIOS")
    return restored


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Preparing Repair', "Emulators/YabaSanshiro2")
    RECOVERY_PARENT.mkdir(parents=True, exist_ok=True)
    recovery_root = Path(tempfile.mkdtemp(prefix="YabaSanshiro2-Repair-", dir=str(RECOVERY_PARENT)))
    state_dir = recovery_root / "state"
    state_dir.mkdir(parents=True, exist_ok=True)
    preserved: list[str] = []

    try:
        emit_progress(progress, 3, 'Preserving User Data', "yabause.ini + BIOS/")
        if EMULATOR_DIR.exists():
            preserved = move_state_out(state_dir)

        uninstall_result = YabaSanshiro2Uninstall.uninstall(progress=scaled_progress(progress, 5, 18))
        if not uninstall_result.get("success"):
            try:
                EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
                restore_state(state_dir)
            except Exception as restore_exc:
                return {
                    "success": False,
                    "module": "yabasanshiro2",
                    "operation": "repair",
                    "state": "repair_failed",
                    "error": "uninstall_and_restore_failed",
                    "message": "Yaba Sanshiro 2 repair could not remove the existing emulator and portable state recovery also failed.",
                    "details": {"uninstall": uninstall_result, "restore_exception": str(restore_exc), "recovery_path": str(recovery_root)},
                }
            return {
                "success": False,
                "module": "yabasanshiro2",
                "operation": "repair",
                "state": "repair_failed",
                "error": uninstall_result.get("error", "uninstall_failed"),
                "message": "Yaba Sanshiro 2 repair could not continue because the existing emulator could not be removed. Portable state was restored.",
                "details": uninstall_result,
            }

        install_result = YabaSanshiro2Installer.install(progress=scaled_progress(progress, 18, 91))
        if not install_result.get("success"):
            try:
                EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
                restore_state(state_dir)
            except Exception as restore_exc:
                return {
                    "success": False,
                    "module": "yabasanshiro2",
                    "operation": "repair",
                    "state": "repair_failed",
                    "error": "install_and_restore_failed",
                    "message": "Yaba Sanshiro 2 reinstall failed and portable state recovery could not be completed automatically.",
                    "details": {"install": install_result, "restore_exception": str(restore_exc), "recovery_path": str(recovery_root)},
                }
            return {
                "success": False,
                "module": "yabasanshiro2",
                "operation": "repair",
                "state": "repair_failed",
                "error": install_result.get("error", "install_failed"),
                "message": ("Yaba Sanshiro 2 was removed successfully, but the clean reinstall failed. Portable state was restored. " + str(install_result.get("message", ""))).strip(),
                "details": install_result,
            }

        emit_progress(progress, 93, 'Restoring User Data', "yabause.ini + BIOS/")
        try:
            restored = restore_state(state_dir)
        except Exception as exc:
            return {
                "success": False,
                "module": "yabasanshiro2",
                "operation": "repair",
                "state": "repair_failed",
                "error": "state_restore_failed",
                "message": "Yaba Sanshiro 2 was reinstalled, but its preserved portable state could not be restored automatically.",
                "details": {"install": install_result, "exception": str(exc), "recovery_path": str(recovery_root)},
            }

        emit_progress(progress, 100, 'Repair Complete', "Version 1.20.37")
        return {
            "success": True,
            "module": "yabasanshiro2",
            "operation": "repair",
            "state": "repaired",
            "message": 'Yaba Sanshiro 2 repaired successfully.',
            "details": {"install": install_result.get("details"), "preserved": preserved, "restored": restored},
        }
    finally:
        try:
            if state_dir.exists() and not any(state_dir.iterdir()):
                shutil.rmtree(recovery_root, ignore_errors=True)
            elif not state_dir.exists():
                shutil.rmtree(recovery_root, ignore_errors=True)
        except OSError:
            pass
