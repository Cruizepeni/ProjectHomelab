from __future__ import annotations

import json
import shutil
import subprocess
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from _RPCS3Common import EMULATOR_DIR, EXECUTABLE_PATH, GUI_CONFIG_DIR, GUI_CONFIG_PATH, RECEIPT_PATH, ProgressCallback, emit_progress, emulator_version, firmware_health, hash_file, is_supported_host, load_info, module_version, run_external_process, scaled_progress, seven_zip_executable


def result(success: bool, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "rpcs3", "operation": "install", "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def download(url: str, destination: Path, minimum_size: int, label: str, progress: ProgressCallback | None = None) -> dict[str, Any] | None:
    request = urllib.request.Request(url, headers={"User-Agent": "EmuKit-RPCS3/1.0.0", "Accept": "*/*"})
    try:
        with urllib.request.urlopen(request, timeout=300) as response:
            total_raw = response.headers.get("Content-Length")
            total = int(total_raw) if total_raw and total_raw.isdigit() else None
            downloaded = 0
            with destination.open("wb") as output:
                while True:
                    chunk = response.read(1024 * 1024)
                    if not chunk:
                        break
                    output.write(chunk)
                    downloaded += len(chunk)
                    percent = round(downloaded * 100 / total) if total else None
                    emit_progress(progress, percent, "Downloading Firmware" if label == "PS3 firmware" else "Downloading Emulator", destination.name)
        if not destination.is_file():
            return result(False, "download_failed", f"The {label} download did not create a file.", "download_missing", {"url": url})
        size = destination.stat().st_size
        if size < minimum_size:
            return result(False, "download_failed", f"The downloaded {label} file is unexpectedly small.", "download_validation_failed", {"url": url, "size": size, "minimum_size": minimum_size})
        return None
    except urllib.error.HTTPError as exc:
        return result(False, "download_failed", f"The official {label} file could not be downloaded.", "download_http_error", {"http_status": exc.code, "url": url})
    except Exception as exc:
        return result(False, "download_failed", f"The official {label} file could not be downloaded.", "download_failed", str(exc))


def validate_archive(path: Path, info: dict[str, Any]) -> dict[str, Any] | None:
    expected = str(info["Source"]["SHA256"]).lower()
    actual = hash_file(path).lower()
    if actual != expected:
        return result(False, "invalid_download", "The downloaded RPCS3 archive failed SHA-256 validation.", "archive_hash_mismatch", {"expected_sha256": expected, "actual_sha256": actual, "path": str(path)})
    return None


def validate_firmware(path: Path, info: dict[str, Any]) -> dict[str, Any] | None:
    firmware = info["Firmware"]
    expected_size = int(firmware["SizeBytes"])
    actual_size = path.stat().st_size
    if actual_size != expected_size:
        return result(False, "invalid_firmware", "Sony's downloaded PS3 firmware has an unexpected file size.", "firmware_size_mismatch", {"expected_size": expected_size, "actual_size": actual_size})
    checks = (("sha256", "SHA256"), ("sha1", "SHA1"), ("md5", "MD5"))
    for algorithm, field in checks:
        expected = str(firmware[field]).lower()
        actual = hash_file(path, algorithm).lower()
        if actual != expected:
            return result(False, "invalid_firmware", f"Sony's downloaded PS3 firmware failed {field} validation.", f"firmware_{algorithm}_mismatch", {"expected": expected, "actual": actual})
    return None


def write_managed_gui_config() -> None:
    GUI_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    GUI_CONFIG_PATH.write_text("[Meta]\ncheckUpdateStart=false\n\n[main_window]\ninfoBoxEnabledWelcome=false\n", encoding="utf-8")


def read_log_tail(path: Path, limit: int = 8000) -> str | None:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    return text[-limit:] if text else None


def install_firmware(path: Path, info: dict[str, Any]) -> dict[str, Any] | None:
    arguments = [str(path) if value == "{firmware}" else str(value) for value in info["Firmware"]["InstallArguments"]]
    stdout_path = path.parent / "rpcs3-firmware-stdout.log"
    stderr_path = path.parent / "rpcs3-firmware-stderr.log"
    try:
        with stdout_path.open("wb") as stdout_handle, stderr_path.open("wb") as stderr_handle:
            completed = run_external_process(
                [str(EXECUTABLE_PATH), *arguments],
                isolate_console=True,
                cwd=str(EMULATOR_DIR),
                stdin=subprocess.DEVNULL,
                stdout=stdout_handle,
                stderr=stderr_handle,
                check=False,
                timeout=900,
            )
    except subprocess.TimeoutExpired:
        return result(False, "firmware_install_failed", "RPCS3 did not finish installing the PS3 firmware within the allowed time.", "firmware_install_timeout", {"timeout_seconds": 900, "stdout": read_log_tail(stdout_path), "stderr": read_log_tail(stderr_path)})
    except Exception as exc:
        return result(False, "firmware_install_failed", "RPCS3 could not be started to install the PS3 firmware.", "firmware_install_exception", {"exception": str(exc), "stdout": read_log_tail(stdout_path), "stderr": read_log_tail(stderr_path)})
    health = firmware_health(info)
    if not health.get("valid"):
        return result(False, "firmware_install_failed", "RPCS3 finished the firmware installation command, but the required PS3 firmware was not installed correctly.", "firmware_post_validation_failed", {"exit_code": completed.returncode, "firmware_health": health, "stdout": read_log_tail(stdout_path), "stderr": read_log_tail(stderr_path)})
    return None


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Checking Host', "Windows x86_64")
    supported, reason = is_supported_host()
    if not supported:
        return result(False, "unsupported", reason or "Unsupported host.", "unsupported_host")

    seven_zip = seven_zip_executable()
    if seven_zip is None:
        return result(False, "dependency_missing", "RPCS3 requires the EmuKit 7-Zip core dependency.", "seven_zip_missing")

    info = load_info()
    version = emulator_version(info)
    if EMULATOR_DIR.exists():
        return result(False, "install_failed", "The RPCS3 emulator directory already exists. Use repair for a clean reinstall.", "emulator_directory_exists", {"path": str(EMULATOR_DIR)})

    emit_progress(progress, 8, 'Preparing Install', "rpcs3-v0.0.42-20019-92721aed_win64_msvc.7z")
    EMULATOR_DIR.mkdir(parents=True, exist_ok=False)
    temp_dir = EMULATOR_DIR / ".install"
    extract_dir = temp_dir / "extracted"
    temp_dir.mkdir(parents=True, exist_ok=True)
    extract_dir.mkdir(parents=True, exist_ok=True)
    archive_path = temp_dir / info["Source"]["Asset"]
    firmware_path = temp_dir / info["Firmware"]["FileName"]
    complete = False

    try:
        error = download(info["Source"]["DownloadURL"], archive_path, 10000000, "RPCS3", scaled_progress(progress, 10, 42))
        if error is not None:
            return error

        emit_progress(progress, 44, 'Validating Emulator', archive_path.name)
        error = validate_archive(archive_path, info)
        if error is not None:
            return error

        emit_progress(progress, 48, 'Extracting Emulator', archive_path.name)
        completed = run_external_process(
            [str(seven_zip), "x", str(archive_path), f"-o{extract_dir}", "-y"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
        )
        if completed.returncode != 0:
            return result(False, "extract_failed", "The RPCS3 archive downloaded correctly but 7-Zip could not extract it.", "archive_extract_failed", {"exit_code": completed.returncode, "stdout": completed.stdout[-4000:], "stderr": completed.stderr[-4000:]})

        extracted_executable = next(extract_dir.rglob("rpcs3.exe"), None)
        if extracted_executable is None or not extracted_executable.is_file():
            return result(False, "install_failed", "The RPCS3 archive was extracted but rpcs3.exe was not found.", "executable_validation_failed")

        emit_progress(progress, 58, 'Installing Emulator', extracted_executable.name)
        extracted_root = extracted_executable.parent
        for item in extracted_root.iterdir():
            destination = EMULATOR_DIR / item.name
            if destination.exists():
                if destination.is_dir():
                    shutil.rmtree(destination)
                else:
                    destination.unlink()
            if item.is_dir():
                shutil.copytree(item, destination)
            else:
                shutil.copy2(item, destination)

        if not EXECUTABLE_PATH.is_file():
            return result(False, "install_failed", "RPCS3 extraction completed but rpcs3.exe is missing.", "post_install_validation_failed", {"expected": str(EXECUTABLE_PATH)})

        emit_progress(progress, 64, 'Configuring Emulator', "GuiConfigs/CurrentSettings.ini")
        write_managed_gui_config()

        error = download(info["Firmware"]["DownloadURL"], firmware_path, 200000000, "PS3 firmware", scaled_progress(progress, 66, 82))
        if error is not None:
            return error

        emit_progress(progress, 84, 'Validating Firmware', firmware_path.name)
        error = validate_firmware(firmware_path, info)
        if error is not None:
            return error

        emit_progress(progress, 88, 'Installing Firmware', firmware_path.name)
        error = install_firmware(firmware_path, info)
        if error is not None:
            return error

        emit_progress(progress, 94, 'Verifying Installation', "rpcs3.exe")
        executable_sha256 = hash_file(EXECUTABLE_PATH)
        firmware_state = firmware_health(info)

        receipt = {
            "EmuKitModule": "rpcs3",
            "ModuleVersion": module_version(info),
            "Name": info["Name"],
            "EmulatorVersion": version,
            "BuildNumber": info["Source"]["BuildNumber"],
            "BuildCommit": info["Source"]["BuildCommit"],
            "Asset": info["Source"]["Asset"],
            "ArchiveSHA256": info["Source"]["SHA256"],
            "ExecutableSHA256": executable_sha256,
            "SourceRepository": info["Source"]["SourceRepository"],
            "BinaryRepository": info["Source"]["Repository"],
            "Firmware": {
                "Version": info["Firmware"]["Version"],
                "FileName": info["Firmware"]["FileName"],
                "SizeBytes": info["Firmware"]["SizeBytes"],
                "MD5": info["Firmware"]["MD5"],
                "SHA1": info["Firmware"]["SHA1"],
                "SHA256": info["Firmware"]["SHA256"],
                "Provider": info["Firmware"]["Provider"],
                "InstalledVersion": firmware_state.get("version"),
            },
            "InstalledAtUTC": datetime.now(timezone.utc).isoformat(),
        }

        emit_progress(progress, 97, 'Writing Receipt', ".emukit_install.json")
        RECEIPT_PATH.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        complete = True
        emit_progress(progress, 100, 'Install Complete', "Version 0.0.42-20019-92721aed")
        return result(True, "installed", f'RPCS3 Version {emulator_version(info)} installed successfully.', details={"module_version": module_version(info), "version": version, "build_number": info["Source"]["BuildNumber"], "build_commit": info["Source"]["ShortCommit"], "path": str(EXECUTABLE_PATH), "portable": True, "firmware_version": info["Firmware"]["Version"], "firmware_source": info["Firmware"]["Provider"], "auto_update_disabled": True, "source": info["Source"]["OfficialRepository"]})
    except PermissionError as exc:
        return result(False, "install_failed", "RPCS3 installation could not write one or more required files.", "permission_denied", str(exc))
    except Exception as exc:
        return result(False, "install_failed", "RPCS3 installation failed unexpectedly.", "install_exception", str(exc))
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        if not complete:
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
