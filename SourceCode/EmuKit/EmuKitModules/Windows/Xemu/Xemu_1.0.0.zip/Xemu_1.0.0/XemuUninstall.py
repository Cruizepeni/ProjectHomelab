from __future__ import annotations

import shutil

from _XemuCommon import EMULATOR_DIR, ProgressCallback, emit_progress


def uninstall(progress: ProgressCallback | None = None) -> dict:
    emit_progress(progress, 3, 'Preparing Uninstall', "Emulators/Xemu")
    try:
        if not EMULATOR_DIR.exists():
            emit_progress(progress, 100, 'Uninstall Complete', "Emulators/Xemu")
            return {"success": True, "module": "xemu", "operation": "uninstall", "state": "uninstalled", "message": "Xemu is already uninstalled.", "details": None}

        emit_progress(progress, 25, 'Removing Emulator', "Emulators/Xemu")
        shutil.rmtree(EMULATOR_DIR)
        emit_progress(progress, 95, 'Verifying Uninstall', "Emulators/Xemu")
        emit_progress(progress, 100, 'Uninstall Complete', "Emulators/Xemu")
        return {"success": True, "module": "xemu", "operation": "uninstall", "state": "uninstalled", "message": "Xemu uninstalled successfully.", "details": {"removed_path": str(EMULATOR_DIR)}}
    except PermissionError as exc:
        return {"success": False, "module": "xemu", "operation": "uninstall", "state": "uninstall_failed", "error": "permission_denied", "message": "Xemu could not be uninstalled because files are in use or permission was denied.", "details": str(exc)}
    except Exception as exc:
        return {"success": False, "module": "xemu", "operation": "uninstall", "state": "uninstall_failed", "error": "uninstall_exception", "message": "Xemu could not be uninstalled.", "details": str(exc)}
