from __future__ import annotations

import shutil

from _XemuCommon import EMULATOR_DIR, ProgressCallback, emit_progress


def uninstall(progress: ProgressCallback | None = None) -> dict:
    try:
        if not EMULATOR_DIR.exists():
            return {"success": True, "module": "xemu", "operation": "uninstall", "state": "uninstalled", "message": "Xemu is already uninstalled.", "details": None}

        emit_progress(progress, 25, "Removing")
        shutil.rmtree(EMULATOR_DIR)
        emit_progress(progress, 95, "Verifying")
        return {"success": True, "module": "xemu", "operation": "uninstall", "state": "uninstalled", "message": "Xemu was uninstalled successfully.", "details": {"removed_path": str(EMULATOR_DIR)}}
    except PermissionError as exc:
        return {"success": False, "module": "xemu", "operation": "uninstall", "state": "uninstall_failed", "error": "permission_denied", "message": "Xemu could not be uninstalled because files are in use or permission was denied.", "details": str(exc)}
    except Exception as exc:
        return {"success": False, "module": "xemu", "operation": "uninstall", "state": "uninstall_failed", "error": "uninstall_exception", "message": "Xemu could not be uninstalled.", "details": str(exc)}
