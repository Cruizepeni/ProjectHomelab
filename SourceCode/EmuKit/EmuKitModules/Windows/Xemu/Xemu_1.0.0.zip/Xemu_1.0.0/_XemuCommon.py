from __future__ import annotations

import hashlib
import json
import os
import platform
import sys
import tomllib
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Callable

MODULE_DIR = (
    Path(sys.executable).resolve().parent
    if getattr(sys, "frozen", False)
    else Path(__file__).resolve().parent
)
INFO_PATH = MODULE_DIR / "EmuKitXemuInfo.json"
ROOT_MARKER = ".AppRoot"
ProgressCallback = Callable[[int | None, str | None, str | None], None]


def resolve_root() -> Path:
    current = MODULE_DIR.resolve()
    for candidate in (current, *current.parents):
        if (candidate / ROOT_MARKER).is_file():
            return candidate
    if MODULE_DIR.parent.name.casefold() == "emukitmodules":
        return MODULE_DIR.parent.parent
    return MODULE_DIR


ROOT = resolve_root()
EMULATOR_DIR = ROOT / "Emulators" / "Xemu"
EXECUTABLE_PATH = EMULATOR_DIR / "xemu.exe"
CONFIG_PATH = EMULATOR_DIR / "xemu.toml"
RECEIPT_PATH = EMULATOR_DIR / ".emukit_install.json"
INSTALLED_RESOURCE_ROOT = EMULATOR_DIR / "Resources"
INSTALLED_BIOS_DIR = INSTALLED_RESOURCE_ROOT / "BIOS"
INSTALLED_BOOT_ROM = INSTALLED_RESOURCE_ROOT / "Boot ROM Image" / "mcpx_1.0.bin"
INSTALLED_HDD = INSTALLED_RESOURCE_ROOT / "Xbox Hard Disk Image" / "xbox_hdd.qcow2"
INSTALLED_EEPROM = INSTALLED_RESOURCE_ROOT / "eeprom.bin"


def load_info() -> dict[str, Any]:
    return json.loads(INFO_PATH.read_text(encoding="utf-8"))


def module_version(info: dict[str, Any] | None = None) -> str:
    source = info if isinstance(info, dict) else load_info()
    return str(source["ModuleVersion"])


def emulator_version(info: dict[str, Any] | None = None) -> str:
    source = info if isinstance(info, dict) else load_info()
    return str(source["EmulatorVersion"])


def emit_progress(progress: ProgressCallback | None, percent: int | None, stage: str | None, message: str | None = None) -> None:
    if progress is not None:
        progress(percent, stage, message)


def scaled_progress(progress: ProgressCallback | None, start: int, end: int) -> ProgressCallback | None:
    if progress is None:
        return None

    def callback(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
        if percent is None:
            mapped = None
        else:
            bounded = max(0, min(100, int(percent)))
            mapped = start + round((end - start) * bounded / 100)
        progress(mapped, stage, message)

    return callback


def is_supported_host() -> tuple[bool, str | None]:
    if platform.system().lower() != "windows":
        return False, "Xemu module 1.0.0 currently supports Windows only."
    if platform.machine().lower() not in {"amd64", "x86_64"}:
        return False, f'Xemu module 1.0.0 requires Windows x86_64. Current architecture: "{platform.machine()}".'
    return True, None


def hash_file(path: Path, algorithm: str) -> str:
    digest = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_receipt() -> dict[str, Any] | None:
    try:
        value = json.loads(RECEIPT_PATH.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def toml_literal(path: Path) -> str:
    return "'" + str(path.resolve()).replace("'", "''") + "'"


def request_json(url: str, timeout: int = 30) -> dict[str, Any]:
    request = urllib.request.Request(url, headers={"User-Agent": "ProjectHomelab-EmuKit-Xemu/1.0.0"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        value = json.loads(response.read().decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Remote JSON root is not an object.")
    return value


def load_resource_catalog(info: dict[str, Any]) -> dict[str, dict[str, Any]]:
    manifest = request_json(str(info["ResourceCatalog"]["ManifestURL"]))
    resources = manifest.get("resources")
    if not isinstance(resources, list):
        raise ValueError("EmuKit resource manifest does not contain a resources list.")
    mapping: dict[str, dict[str, Any]] = {}
    for entry in resources:
        if isinstance(entry, dict) and isinstance(entry.get("path"), str):
            mapping[entry["path"]] = entry
    return mapping


def validate_catalog_entry(catalog: dict[str, dict[str, Any]], specification: dict[str, Any]) -> dict[str, Any]:
    path = str(specification["Path"])
    entry = catalog.get(path)
    if not isinstance(entry, dict):
        raise ValueError(f'Required EmuKit resource is not registered: "{path}".')
    if int(entry.get("size", -1)) != int(specification["Size"]):
        raise ValueError(f'Resource size changed for "{path}".')
    if str(entry.get("sha256", "")).lower() != str(specification["SHA256"]).lower():
        raise ValueError(f'Resource SHA-256 changed for "{path}".')
    if str(entry.get("md5", "")).lower() != str(specification["MD5"]).lower():
        raise ValueError(f'Resource MD5 changed for "{path}".')
    return entry


def resource_url(info: dict[str, Any], relative_path: str) -> str:
    base = str(info["ResourceCatalog"]["RawBaseURL"]).rstrip("/")
    return base + "/" + urllib.parse.quote(relative_path, safe="/")

def expected_config_paths(selected_bios: str) -> dict[str, Path]:
    return {
        "bootrom_path": INSTALLED_BOOT_ROM,
        "flashrom_path": INSTALLED_BIOS_DIR / selected_bios,
        "eeprom_path": INSTALLED_EEPROM,
        "hdd_path": INSTALLED_HDD,
    }


def normalized_path(value: str | Path) -> str:
    path = Path(value).expanduser()
    try:
        path = path.resolve(strict=False)
    except Exception:
        path = Path(os.path.abspath(str(path)))
    return os.path.normcase(os.path.normpath(str(path)))


def validate_config_paths(selected_bios: str) -> tuple[bool, dict[str, Any]]:
    expected = expected_config_paths(selected_bios)
    if not CONFIG_PATH.is_file():
        return False, {"error": "config_missing", "expected": str(CONFIG_PATH)}
    try:
        document = tomllib.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception as exc:
        return False, {"error": "config_invalid", "details": str(exc)}
    sys_section = document.get("sys")
    files_section = sys_section.get("files") if isinstance(sys_section, dict) else None
    if not isinstance(files_section, dict):
        return False, {"error": "sys_files_missing"}
    mismatches: dict[str, Any] = {}
    for key, expected_path in expected.items():
        actual = files_section.get(key)
        if not isinstance(actual, str) or normalized_path(actual) != normalized_path(expected_path):
            mismatches[key] = {
                "expected": str(expected_path.resolve()),
                "actual": actual,
            }
    if mismatches:
        return False, {"error": "config_path_mismatch", "mismatches": mismatches}
    return True, {"paths": {key: str(path.resolve()) for key, path in expected.items()}}

