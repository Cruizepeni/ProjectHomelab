from __future__ import annotations

from _XemuCommon import *
import XemuInstaller
import XemuUninstall


def _can_repair_config_only() -> tuple[bool, str | None]:
    supported, _ = is_supported_host()
    if not supported:
        return False, None
    if not EXECUTABLE_PATH.is_file() or not INSTALLED_BOOT_ROM.is_file() or not INSTALLED_HDD.is_file():
        return False, None
    info = load_info()
    receipt = read_receipt()
    if not isinstance(receipt, dict) or receipt.get("EmulatorVersion") != emulator_version(info):
        return False, None
    selected = receipt.get("SelectedBIOS")
    if not isinstance(selected, str):
        return False, None
    accepted = {
        str(entry["Name"]): entry
        for entry in info["Resources"]["BIOS"]["Accepted"]
        if isinstance(entry, dict) and isinstance(entry.get("Name"), str)
    }
    bios_spec = accepted.get(selected)
    bios_path = INSTALLED_BIOS_DIR / selected
    if bios_spec is None or not bios_path.is_file():
        return False, None
    if hash_file(INSTALLED_BOOT_ROM, "md5").lower() != str(info["Resources"]["BootROM"]["MD5"]).lower():
        return False, None
    if hash_file(bios_path, "sha256").lower() != str(bios_spec["SHA256"]).lower():
        return False, None
    return True, selected


def repair(progress: ProgressCallback | None = None) -> dict:
    emit_progress(progress, 3, 'Preparing Repair', "Emulators/Xemu")
    emit_progress(progress, 5, 'Checking Installation', "xemu.exe")
    config_only, selected = _can_repair_config_only()
    if config_only and isinstance(selected, str):
        emit_progress(progress, 45, 'Repairing Configuration', "xemu.toml")
        try:
            XemuInstaller.write_config(selected)
            valid, details = validate_config_paths(selected)
            if valid:
                emit_progress(progress, 100, 'Repair Complete', "Version 0.8.136")
                return {
                    "success": True,
                    "module": "xemu",
                    "operation": "repair",
                    "state": "repaired",
                    "message": 'Xemu repaired successfully.',
                    "details": details,
                }
        except Exception:
            pass

    removed = XemuUninstall.uninstall(progress=scaled_progress(progress, 10, 25))
    if not removed.get("success"):
        return {"success": False, "module": "xemu", "operation": "repair", "state": "repair_failed", "error": removed.get("error", "uninstall_failed"), "message": "Xemu repair could not continue because the existing emulator installation could not be removed.", "details": removed}

    installed = XemuInstaller.install(progress=scaled_progress(progress, 25, 98))
    if not installed.get("success"):
        return {"success": False, "module": "xemu", "operation": "repair", "state": "repair_failed", "error": installed.get("error", "install_failed"), "message": "Xemu was removed successfully, but the clean reinstall failed. " + str(installed.get("message", "")), "details": installed}

    emit_progress(progress, 100, 'Repair Complete', "Version 0.8.136")
    return {"success": True, "module": "xemu", "operation": "repair", "state": "repaired", "message": 'Xemu repaired successfully.', "details": installed.get("details")}
