from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

MODULE_DIR = (
    Path(sys.executable).resolve().parent
    if getattr(sys, "frozen", False)
    else Path(__file__).resolve().parent
)
if str(MODULE_DIR) not in sys.path:
    sys.path.insert(0, str(MODULE_DIR))

from _XemuCommon import *
import XemuInstaller
import XemuRepair
import XemuUninstall


def base(success: bool, operation: str, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "xemu", "operation": operation, "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def check(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 20, "Checking")
    supported, reason = is_supported_host()
    if not supported:
        return base(False, "check", "unsupported", reason or "Xemu is not supported on this host.", "unsupported_host")

    info = load_info()
    version = emulator_version(info)

    if not EMULATOR_DIR.exists():
        return base(True, "check", "missing", "Xemu is not installed.", details={"expected_path": str(EMULATOR_DIR)})
    if not EXECUTABLE_PATH.is_file():
        return base(True, "check", "broken", "The Xemu emulator directory exists but xemu.exe is missing.", details={"expected": str(EXECUTABLE_PATH)})
    if not CONFIG_PATH.is_file():
        return base(True, "check", "broken", "Xemu is installed but xemu.toml is missing.", details={"expected": str(CONFIG_PATH)})

    emit_progress(progress, 45, "Validating resources")
    if not INSTALLED_BOOT_ROM.is_file():
        return base(True, "check", "broken", "Xemu is installed but its MCPX Boot ROM is missing.", details={"expected": str(INSTALLED_BOOT_ROM)})
    actual_boot = hash_file(INSTALLED_BOOT_ROM, "md5").lower()
    expected_boot = str(info["Resources"]["BootROM"]["MD5"]).lower()
    if actual_boot != expected_boot:
        return base(True, "check", "broken", "Xemu is installed but its MCPX Boot ROM failed validation.", details={"md5": actual_boot, "expected_md5": expected_boot})
    if not INSTALLED_HDD.is_file():
        return base(True, "check", "broken", "Xemu is installed but its Xbox hard disk image is missing.", details={"expected": str(INSTALLED_HDD)})

    receipt = read_receipt()
    if receipt is None:
        return base(True, "check", "broken", "Xemu is present but its EmuKit installation receipt is missing or invalid.", details={"receipt": str(RECEIPT_PATH)})
    if receipt.get("EmulatorVersion") != version:
        return base(True, "check", "broken", "The installed Xemu build does not match the module-pinned emulator version.", details={"installed_version": receipt.get("EmulatorVersion"), "pinned_version": version})

    bios = receipt.get("SelectedBIOS")
    if not isinstance(bios, str) or not (INSTALLED_BIOS_DIR / bios).is_file():
        return base(True, "check", "broken", "Xemu is installed but its selected Xbox BIOS is missing.", details={"selected_bios": bios})

    accepted = {
        str(entry["Name"]): entry
        for entry in info["Resources"]["BIOS"]["Accepted"]
        if isinstance(entry, dict) and isinstance(entry.get("Name"), str)
    }
    bios_spec = accepted.get(bios)
    if bios_spec is None:
        return base(True, "check", "broken", "Xemu is installed with a BIOS that is no longer accepted by this module.", details={"selected_bios": bios})
    actual_bios = hash_file(INSTALLED_BIOS_DIR / bios, "sha256").lower()
    if actual_bios != str(bios_spec["SHA256"]).lower():
        return base(True, "check", "broken", "Xemu is installed but its selected Xbox BIOS failed validation.", details={"selected_bios": bios, "sha256": actual_bios, "expected_sha256": bios_spec["SHA256"]})

    emit_progress(progress, 80, "Validating configuration")
    config_valid, config_details = validate_config_paths(bios)
    if not config_valid:
        return base(True, "check", "broken", "Xemu is installed but xemu.toml does not point to the module-managed Xbox resources.", details=config_details)

    emit_progress(progress, 95, "Ready")
    return base(
        True,
        "check",
        "installed",
        f'Xemu "{version}" is installed and valid.',
        details={
            "module_version": module_version(info),
            "version": version,
            "path": str(EXECUTABLE_PATH),
            "config": str(CONFIG_PATH),
            "selected_bios": bios,
            "boot_rom": str(INSTALLED_BOOT_ROM),
            "hard_disk": str(INSTALLED_HDD),
            "source": info["Source"]["OfficialRepository"]
        },
    )


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return XemuInstaller.install(progress=progress)


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return XemuUninstall.uninstall(progress=progress)


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return XemuRepair.repair(progress=progress)


def update(progress: ProgressCallback | None = None) -> dict[str, Any]:
    current = check(progress=scaled_progress(progress, 0, 20))
    if not current.get("success") and current.get("state") == "unsupported":
        current["operation"] = "update"
        return current
    if current.get("state") == "installed":
        return base(True, "update", "already_current", f'Xemu "{emulator_version()}" is already the module-pinned version.', details=current.get("details"))
    repaired = XemuRepair.repair(progress=scaled_progress(progress, 20, 98))
    repaired["operation"] = "update"
    repaired["state"] = "updated" if repaired.get("success") else "update_failed"
    if repaired.get("success"):
        repaired["message"] = f'Xemu was updated to pinned version "{emulator_version()}".'
    return repaired

def _write_record(record: dict[str, Any]) -> None:
    print(json.dumps(record, ensure_ascii=False, default=str, separators=(",", ":")), flush=True)


def _stream_progress(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
    _write_record({"type": "progress", "percent": percent, "stage": stage, "message": message})


def _run_cli() -> int:
    raw_args = sys.argv[1:]
    json_flags = [arg for arg in raw_args if arg.casefold() == "--json"]
    args = [arg for arg in raw_args if arg.casefold() != "--json"]
    operation = args[0].casefold() if len(args) == 1 else ""
    handlers = {
        "check": check,
        "install": install,
        "uninstall": uninstall,
        "repair": repair,
        "update": update,
    }
    handler = handlers.get(operation)
    if len(json_flags) != 1 or handler is None:
        result = base(
            False,
            operation or "manager",
            "invalid_operation",
            "XemuManager requires one lifecycle operation: check, install, uninstall, repair, or update.",
            "invalid_operation",
        )
    else:
        try:
            result = handler(progress=_stream_progress)
        except Exception as exc:
            result = base(
                False,
                operation,
                f"{operation}_failed",
                f"XemuManager failed during {operation}.",
                "manager_exception",
                str(exc),
            )
    _write_record({"type": "result", "result": result})
    return 0 if result.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(_run_cli())
