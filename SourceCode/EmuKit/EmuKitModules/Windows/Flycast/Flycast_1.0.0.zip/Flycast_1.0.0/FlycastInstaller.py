from __future__ import annotations

import shutil
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

from _FlycastCommon import (
    CONFIG_PATH,
    DATA_DIR,
    EMULATOR_DIR,
    EXECUTABLE_PATH,
    MAPPINGS_DIR,
    ProgressCallback,
    emit_progress,
    emulator_version,
    hash_file,
    is_supported_host,
    load_info,
    module_version,
    resource_status,
    write_receipt,
)


def result(
    success: bool,
    state: str,
    message: str,
    error: str | None = None,
    details: Any = None,
) -> dict[str, Any]:
    value = {
        "success": success,
        "module": "flycast",
        "operation": "install",
        "state": state,
        "message": message,
        "details": details,
    }
    if error:
        value["error"] = error
    return value


def download(
    url: str,
    destination: Path,
    expected_size: int,
    progress: ProgressCallback | None = None,
) -> dict[str, Any] | None:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "EmuKit-Flycast/1.0.0", "Accept": "*/*"},
    )
    try:
        with urllib.request.urlopen(request, timeout=180) as response, destination.open("wb") as output:
            raw_total = response.headers.get("Content-Length")
            total = int(raw_total) if raw_total and raw_total.isdigit() else None
            received = 0
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                output.write(block)
                received += len(block)
                if total and total > 0:
                    emit_progress(progress, min(100, round(received * 100 / total)), 'Downloading Emulator', "flycast-win64-2.7.zip")

        if not destination.is_file():
            return result(
                False,
                "download_failed",
                "The official Flycast Windows archive was not created.",
                "download_missing",
                {"url": url},
            )

        size = destination.stat().st_size
        if size != expected_size:
            return result(
                False,
                "download_failed",
                "The downloaded Flycast archive has an unexpected size.",
                "download_size_mismatch",
                {
                    "url": url,
                    "expected_size": expected_size,
                    "actual_size": size,
                },
            )

        emit_progress(progress, 100, 'Downloading Emulator', "flycast-win64-2.7.zip")
        return None
    except urllib.error.HTTPError as exc:
        return result(
            False,
            "download_failed",
            "The official Flycast Windows archive could not be downloaded.",
            "download_http_error",
            {"http_status": exc.code, "url": url},
        )
    except Exception as exc:
        return result(
            False,
            "download_failed",
            "The official Flycast Windows archive could not be downloaded.",
            "download_failed",
            str(exc),
        )


def safe_extract(archive: zipfile.ZipFile, destination: Path) -> None:
    root = destination.resolve()
    for member in archive.infolist():
        relative = PurePosixPath(member.filename.replace("\\", "/"))
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f'Unsafe archive member: "{member.filename}"')
        target = (destination / Path(*relative.parts)).resolve()
        if target != root and root not in target.parents:
            raise ValueError(f'Unsafe archive member: "{member.filename}"')
    archive.extractall(destination)


def install_resources(info: dict[str, Any], progress: ProgressCallback | None = None) -> tuple[bool, list[dict[str, Any]]]:
    base = str(info["ResourceCatalog"]["RawBaseURL"]).rstrip("/")
    results: list[dict[str, Any]] = []
    all_valid = True

    items = list(info["Resources"].items())
    total = max(1, len(items))
    for index, (resource_id, spec) in enumerate(items):
        destination = EMULATOR_DIR / str(spec["Destination"])
        destination.parent.mkdir(parents=True, exist_ok=True)
        expected_size = int(spec["Size"])
        expected_sha = str(spec["SHA256"]).lower()
        expected_md5 = str(spec["MD5"]).lower()

        item_start = 84 + round(index * (91 - 84) / total)
        item_end = 84 + round((index + 1) * (91 - 84) / total)
        emit_progress(progress, item_start, "Validating Resources", destination.name)

        if destination.is_file():
            try:
                if (
                    destination.stat().st_size == expected_size
                    and hash_file(destination).lower() == expected_sha
                    and hash_file(destination, "md5").lower() == expected_md5
                ):
                    results.append({
                        "resource": resource_id,
                        "state": "already_present",
                        "path": str(destination),
                    })
                    continue
            except OSError:
                pass

        relative = str(spec["CatalogPath"]).replace("\\", "/")
        encoded = "/".join(urllib.parse.quote(part) for part in relative.split("/"))
        url = f"{base}/{encoded}"
        temp = destination.with_suffix(destination.suffix + ".download")

        try:
            emit_progress(progress, item_start, "Downloading Resources", destination.name)
            request = urllib.request.Request(
                url,
                headers={"User-Agent": "EmuKit-Flycast/1.0.0", "Accept": "*/*"},
            )
            with urllib.request.urlopen(request, timeout=60) as response, temp.open("wb") as output:
                shutil.copyfileobj(response, output)

            emit_progress(progress, item_end, "Validating Resources", destination.name)
            valid = (
                temp.stat().st_size == expected_size
                and hash_file(temp).lower() == expected_sha
                and hash_file(temp, "md5").lower() == expected_md5
            )

            if not valid:
                all_valid = False
                temp.unlink(missing_ok=True)
                results.append({
                    "resource": resource_id,
                    "state": "invalid",
                    "url": url,
                })
                continue

            emit_progress(progress, item_end, "Installing Resources", destination.name)
            shutil.move(str(temp), str(destination))
            results.append({
                "resource": resource_id,
                "state": "installed",
                "path": str(destination),
            })
        except Exception as exc:
            all_valid = False
            temp.unlink(missing_ok=True)
            results.append({
                "resource": resource_id,
                "state": "unavailable",
                "url": url,
                "error": str(exc),
            })

    return all_valid, results


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Checking Host', "Windows x86_64")
    supported, reason = is_supported_host()
    if not supported:
        return result(
            False,
            "unsupported",
            reason or "Flycast is not supported on this host.",
            "unsupported_host",
        )

    info = load_info()
    source = info["Source"]

    if EMULATOR_DIR.exists():
        return result(
            False,
            "install_failed",
            "The Flycast managed emulator directory already exists. Use Repair for a clean reinstall.",
            "emulator_directory_already_exists",
            {"path": str(EMULATOR_DIR)},
        )

    emit_progress(progress, 7, 'Preparing Install', "flycast-win64-2.7.zip")
    EMULATOR_DIR.mkdir(parents=True, exist_ok=False)
    temp_dir = EMULATOR_DIR / ".install"
    extract_dir = temp_dir / "extracted"
    archive_path = temp_dir / source["Asset"]
    temp_dir.mkdir(parents=True, exist_ok=True)
    extract_dir.mkdir(parents=True, exist_ok=True)
    install_complete = False

    try:
        def download_progress(
            percent: int | None = None,
            stage: str | None = None,
            message: str | None = None,
        ) -> None:
            mapped = None if percent is None else 10 + round(
                max(0, min(100, int(percent))) * 45 / 100
            )
            emit_progress(progress, mapped, stage, message)

        download_error = download(
            source["DownloadURL"],
            archive_path,
            int(source["Size"]),
            download_progress,
        )
        if download_error is not None:
            return download_error

        emit_progress(progress, 58, 'Validating Emulator', "flycast-win64-2.7.zip")
        archive_sha256 = hash_file(archive_path).lower()
        if archive_sha256 != str(source["SHA256"]).lower():
            return result(
                False,
                "invalid_download",
                "The downloaded Flycast archive failed SHA-256 validation.",
                "archive_hash_mismatch",
                {
                    "expected_sha256": source["SHA256"],
                    "actual_sha256": archive_sha256,
                },
            )

        try:
            with zipfile.ZipFile(archive_path, "r") as archive:
                bad_member = archive.testzip()
                if bad_member is not None:
                    return result(
                        False,
                        "extract_failed",
                        f'The official Flycast ZIP failed its internal CRC check at "{bad_member}".',
                        "archive_crc_failed",
                        {"member": bad_member},
                    )
                emit_progress(progress, 65, 'Extracting Emulator', "flycast-win64-2.7.zip")
                safe_extract(archive, extract_dir)
        except (zipfile.BadZipFile, ValueError) as exc:
            return result(
                False,
                "extract_failed",
                "The downloaded Flycast archive could not be safely extracted.",
                "invalid_archive",
                str(exc),
            )

        extracted_executable = next(
            (
                p for p in extract_dir.rglob("*")
                if p.is_file() and p.name.casefold() == "flycast.exe"
            ),
            None,
        )
        if extracted_executable is None:
            return result(
                False,
                "install_failed",
                "The Flycast archive extracted successfully, but flycast.exe was not found.",
                "executable_validation_failed",
            )

        emit_progress(progress, 73, 'Installing Emulator', "flycast.exe")
        extracted_root = extracted_executable.parent
        for item in extracted_root.iterdir():
            destination = EMULATOR_DIR / item.name
            if destination.exists():
                if destination.is_dir():
                    shutil.rmtree(destination)
                else:
                    destination.unlink()
            if item.is_dir():
                shutil.copytree(item, destination)
            else:
                shutil.copy2(item, destination)

        if not EXECUTABLE_PATH.is_file():
            return result(
                False,
                "install_failed",
                "Flycast extraction completed but flycast.exe is missing.",
                "post_install_validation_failed",
            )

        emit_progress(progress, 80, 'Configuring Emulator', "emu.cfg")
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        MAPPINGS_DIR.mkdir(parents=True, exist_ok=True)
        if not CONFIG_PATH.exists():
            CONFIG_PATH.touch()

        resources_ok, resource_results = install_resources(info, progress)
        if not resources_ok:
            return result(
                False,
                "install_failed",
                "Flycast was downloaded correctly, but one or more required BIOS resources could not be installed or validated.",
                "required_resources_unavailable",
                resource_results,
            )

        firmware = resource_status()
        unavailable: list[str] = []
        for system_id, system in info["Systems"].items():
            required = list(system.get("FirmwareResources", []))
            if required and not all(firmware.get(rid, {}).get("ready") for rid in required):
                unavailable.append(system_id)

        if unavailable:
            return result(
                False,
                "install_failed",
                "Flycast installation is missing validated BIOS resources required by one or more registered systems.",
                "firmware_validation_failed",
                {
                    "systems": unavailable,
                    "firmware": firmware,
                },
            )

        emit_progress(progress, 92, 'Verifying Installation', "flycast.exe")
        executable_sha256 = hash_file(EXECUTABLE_PATH).lower()

        emit_progress(progress, 97, 'Writing Receipt', ".emukit_install.json")
        write_receipt({
            "EmuKitModule": "flycast",
            "Name": info["Name"],
            "ModuleVersion": module_version(info),
            "EmulatorVersion": emulator_version(info),
            "ReleaseTag": source["ReleaseTag"],
            "ReleaseCommit": source["ReleaseCommit"],
            "Asset": source["Asset"],
            "DownloadURL": source["DownloadURL"],
            "ArchiveSHA256": archive_sha256,
            "ExecutableSHA256": executable_sha256,
            "SourceRepository": source["Repository"],
            "InstalledAtUTC": datetime.now(timezone.utc).isoformat(),
        })

        emit_progress(progress, 100, 'Install Complete', "Version 2.7")
        install_complete = True

        return result(
            True,
            "installed",
            f'Flycast Version {emulator_version(info)} installed successfully.',
            details={
                "module_version": module_version(info),
                "version": emulator_version(info),
                "path": str(EXECUTABLE_PATH),
                "systems": list(info["Systems"].keys()),
                "resource_results": resource_results,
                "firmware": firmware,
                "source": source["OfficialWebsite"],
            },
        )
    except PermissionError as exc:
        return result(
            False,
            "install_failed",
            "Flycast installation could not write one or more required files.",
            "permission_denied",
            str(exc),
        )
    except Exception as exc:
        return result(
            False,
            "install_failed",
            "Flycast installation failed unexpectedly.",
            "install_exception",
            str(exc),
        )
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        if not install_complete:
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
