from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

import FlycastInstaller
import FlycastUninstall
from _FlycastCommon import (
    DATA_DIR,
    EMULATOR_DIR,
    RECOVERY_PARENT,
    ProgressCallback,
    emit_progress,
    emulator_version,
    load_info,
    scaled_progress,
)


def managed_resource_names() -> set[str]:
    info = load_info()
    values: set[str] = set()
    for spec in info["Resources"].values():
        if spec.get("Mutable") is True:
            continue
        destination = Path(str(spec["Destination"]))
        try:
            relative = destination.relative_to("data")
        except ValueError:
            continue
        values.add(str(relative).replace("\\", "/"))
    return values


def preserve_state(state_dir: Path) -> list[str]:
    preserved: list[str] = []

    for name in ("emu.cfg", "mappings", "data"):
        source = EMULATOR_DIR / name
        if source.exists():
            shutil.move(str(source), str(state_dir / name))
            preserved.append(name)

    data = state_dir / "data"
    if data.is_dir():
        for relative in managed_resource_names():
            path = data / Path(relative)
            if path.is_file():
                path.unlink()
        for directory in sorted(
            (p for p in data.rglob("*") if p.is_dir()),
            key=lambda p: len(p.parts),
            reverse=True,
        ):
            try:
                directory.rmdir()
            except OSError:
                pass

    return preserved


def merge_restore(source: Path, destination: Path) -> None:
    if source.is_dir():
        destination.mkdir(parents=True, exist_ok=True)
        for child in list(source.iterdir()):
            merge_restore(child, destination / child.name)
        source.rmdir()
        return

    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        if destination.is_dir():
            shutil.rmtree(destination)
        else:
            destination.unlink()
    shutil.move(str(source), str(destination))


def restore_state(state_dir: Path) -> list[str]:
    restored: list[str] = []
    if not state_dir.exists():
        return restored

    for item in list(state_dir.iterdir()):
        restored.append(item.name)
        merge_restore(item, EMULATOR_DIR / item.name)

    return restored


def repair(progress: ProgressCallback | None = None) -> dict:
    emit_progress(progress, 3, 'Preparing Repair', "Emulators/Flycast")
    RECOVERY_PARENT.mkdir(parents=True, exist_ok=True)
    recovery_root = Path(
        tempfile.mkdtemp(prefix="Flycast-Repair-", dir=str(RECOVERY_PARENT))
    )
    state_dir = recovery_root / "state"
    state_dir.mkdir(parents=True, exist_ok=True)

    try:
        emit_progress(progress, 3, 'Preserving User Data', "emu.cfg + mappings/ + data/")
        preserved = preserve_state(state_dir) if EMULATOR_DIR.exists() else []

        uninstall_result = FlycastUninstall.uninstall(
            progress=scaled_progress(progress, 5, 18)
        )
        if not uninstall_result.get("success"):
            EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
            restored = restore_state(state_dir)
            return {
                "success": False,
                "module": "flycast",
                "operation": "repair",
                "state": "repair_failed",
                "error": uninstall_result.get("error", "uninstall_failed"),
                "message": "Flycast repair could not continue because the existing emulator could not be removed. Portable state was restored.",
                "details": {
                    "uninstall": uninstall_result,
                    "restored": restored,
                },
            }

        install_result = FlycastInstaller.install(
            progress=scaled_progress(progress, 18, 91)
        )
        if not install_result.get("success"):
            EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
            restored = restore_state(state_dir)
            return {
                "success": False,
                "module": "flycast",
                "operation": "repair",
                "state": "repair_failed",
                "error": install_result.get("error", "install_failed"),
                "message": (
                    "Flycast was removed successfully, but the clean reinstall failed. "
                    "Portable state was restored. "
                    + str(install_result.get("message", ""))
                ).strip(),
                "details": {
                    "install": install_result,
                    "restored": restored,
                },
            }

        emit_progress(progress, 93, 'Restoring User Data', "emu.cfg + mappings/ + data/")
        restored = restore_state(state_dir)

        emit_progress(progress, 100, 'Repair Complete', "Version 2.7")
        return {
            "success": True,
            "module": "flycast",
            "operation": "repair",
            "state": "repaired",
            "message": 'Flycast repaired successfully.',
            "details": {
                "install": install_result.get("details"),
                "preserved": preserved,
                "restored": restored,
            },
        }
    except Exception as exc:
        return {
            "success": False,
            "module": "flycast",
            "operation": "repair",
            "state": "repair_failed",
            "error": "repair_exception",
            "message": "Flycast repair failed unexpectedly.",
            "details": {
                "exception": str(exc),
                "recovery_path": str(recovery_root),
            },
        }
    finally:
        shutil.rmtree(recovery_root, ignore_errors=True)
