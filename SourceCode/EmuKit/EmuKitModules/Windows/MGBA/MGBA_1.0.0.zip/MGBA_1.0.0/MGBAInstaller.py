from __future__ import annotations

import shutil
import subprocess
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from _MGBACommon import (
    EMULATOR_DIR,
    EXECUTABLE_PATH,
    PORTABLE_MARKER,
    ProgressCallback,
    emit_progress,
    emulator_version,
    hash_file,
    is_supported_host,
    load_info,
    module_version,
    seven_zip_executable,
    write_receipt,
)


def result(
    success: bool,
    state: str,
    message: str,
    error: str | None = None,
    details: Any = None,
) -> dict[str, Any]:
    value = {
        "success": success,
        "module": "mgba",
        "operation": "install",
        "state": state,
        "message": message,
        "details": details,
    }
    if error:
        value["error"] = error
    return value


def download(
    url: str,
    destination: Path,
    progress: ProgressCallback | None = None,
) -> dict[str, Any] | None:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "EmuKit-mGBA/1.0.0", "Accept": "*/*"},
    )
    try:
        with urllib.request.urlopen(request, timeout=180) as response, destination.open("wb") as output:
            raw_total = response.headers.get("Content-Length")
            total = int(raw_total) if raw_total and raw_total.isdigit() else None
            received = 0
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                output.write(block)
                received += len(block)
                if total and total > 0:
                    emit_progress(progress, min(100, round(received * 100 / total)), 'Downloading Emulator', "mGBA-0.10.5-win64.7z")
        if not destination.is_file():
            return result(
                False,
                "download_failed",
                "The official mGBA Windows archive was not created.",
                "download_missing",
                {"url": url},
            )
        if destination.stat().st_size < 5_000_000:
            return result(
                False,
                "download_failed",
                "The downloaded MGBA archive is unexpectedly small.",
                "download_validation_failed",
                {"url": url, "size": destination.stat().st_size},
            )
        emit_progress(progress, 100, 'Downloading Emulator', "mGBA-0.10.5-win64.7z")
        return None
    except urllib.error.HTTPError as exc:
        return result(
            False,
            "download_failed",
            "The official mGBA Windows archive could not be downloaded.",
            "download_http_error",
            {"http_status": exc.code, "url": url},
        )
    except Exception as exc:
        return result(
            False,
            "download_failed",
            "The official mGBA Windows archive could not be downloaded.",
            "download_failed",
            str(exc),
        )


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Checking Host', "Windows x86_64")
    supported, reason = is_supported_host()
    if not supported:
        return result(
            False,
            "unsupported",
            reason or "MGBA is not supported on this host.",
            "unsupported_host",
        )

    seven_zip = seven_zip_executable()
    if seven_zip is None:
        return result(
            False,
            "install_failed",
            "mGBA requires the EmuKit 7-Zip core dependency, but 7z could not be located.",
            "missing_core_dependency",
            {"dependency": "7zip"},
        )

    info = load_info()
    version = emulator_version(info)
    source = info["Source"]

    if EMULATOR_DIR.exists():
        return result(
            False,
            "install_failed",
            "The MGBA managed emulator directory already exists. Use Repair for a clean reinstall.",
            "emulator_directory_already_exists",
            {"path": str(EMULATOR_DIR)},
        )

    emit_progress(progress, 7, 'Preparing Install', "mGBA-0.10.5-win64.7z")
    EMULATOR_DIR.mkdir(parents=True, exist_ok=False)
    temp_dir = EMULATOR_DIR / ".install"
    extract_dir = temp_dir / "extracted"
    archive_path = temp_dir / source["Asset"]
    temp_dir.mkdir(parents=True, exist_ok=True)
    extract_dir.mkdir(parents=True, exist_ok=True)
    install_complete = False

    try:
        def download_progress(
            percent: int | None = None,
            stage: str | None = None,
            message: str | None = None,
        ) -> None:
            mapped = None if percent is None else 10 + round(
                max(0, min(100, int(percent))) * 50 / 100
            )
            emit_progress(progress, mapped, stage, message)

        download_error = download(
            source["DownloadURL"],
            archive_path,
            download_progress,
        )
        if download_error is not None:
            return download_error

        emit_progress(progress, 63, 'Validating Emulator', "mGBA-0.10.5-win64.7z")
        archive_sha256 = hash_file(archive_path).lower()
        expected_sha256 = str(source.get("SHA256", "")).strip().lower()
        if expected_sha256 and archive_sha256 != expected_sha256:
            return result(
                False,
                "invalid_download",
                "The downloaded MGBA archive failed SHA-256 validation.",
                "archive_hash_mismatch",
                {
                    "expected_sha256": expected_sha256,
                    "actual_sha256": archive_sha256,
                    "path": str(archive_path),
                },
            )

        emit_progress(progress, 70, 'Extracting Emulator', "mGBA-0.10.5-win64.7z")
        completed = subprocess.run(
            [str(seven_zip), "x", str(archive_path), f"-o{extract_dir}", "-y"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
        )
        if completed.returncode != 0:
            return result(
                False,
                "extract_failed",
                "The MGBA archive downloaded correctly but 7-Zip could not extract it.",
                "archive_extract_failed",
                {
                    "exit_code": completed.returncode,
                    "stdout": completed.stdout[-4000:],
                    "stderr": completed.stderr[-4000:],
                },
            )

        extracted_executable = next(
            (
                path
                for path in extract_dir.rglob("*")
                if path.is_file() and path.name.casefold() == "mgba.exe"
            ),
            None,
        )
        if extracted_executable is None:
            return result(
                False,
                "install_failed",
                "The MGBA archive extracted successfully, but mGBA.exe was not found.",
                "executable_validation_failed",
                {"archive": str(archive_path)},
            )

        emit_progress(progress, 79, 'Installing Emulator', "mGBA.exe")
        extracted_root = extracted_executable.parent
        for item in extracted_root.iterdir():
            destination = EMULATOR_DIR / item.name
            if destination.exists():
                if destination.is_dir():
                    shutil.rmtree(destination)
                else:
                    destination.unlink()
            if item.is_dir():
                shutil.copytree(item, destination)
            else:
                shutil.copy2(item, destination)

        if not EXECUTABLE_PATH.is_file():
            return result(
                False,
                "install_failed",
                "MGBA extraction completed but mGBA.exe is missing.",
                "post_install_validation_failed",
                {"expected": str(EXECUTABLE_PATH)},
            )

        emit_progress(progress, 87, 'Configuring Emulator', "portable.ini")
        PORTABLE_MARKER.touch(exist_ok=True)
        if not PORTABLE_MARKER.is_file():
            return result(
                False,
                "install_failed",
                "MGBA portable mode could not be enabled.",
                "portable_mode_failed",
                {"path": str(PORTABLE_MARKER)},
            )

        emit_progress(progress, 92, 'Verifying Installation', "mGBA.exe")
        if EXECUTABLE_PATH.stat().st_size < 100_000:
            return result(
                False,
                "install_failed",
                "The installed mGBA executable is unexpectedly small.",
                "executable_validation_failed",
                {
                    "path": str(EXECUTABLE_PATH),
                    "size": EXECUTABLE_PATH.stat().st_size,
                },
            )
        executable_sha256 = hash_file(EXECUTABLE_PATH).lower()

        emit_progress(progress, 96, 'Writing Receipt', ".emukit_install.json")
        write_receipt(
            {
                "EmuKitModule": "mgba",
                "Name": info["Name"],
                "ModuleVersion": module_version(info),
                "EmulatorVersion": version,
                "ReleaseTag": source["ReleaseTag"],
                "ReleaseCommit": source.get("ReleaseCommit"),
                "Asset": source["Asset"],
                "DownloadURL": source["DownloadURL"],
                "ArchiveSHA256": archive_sha256,
                "ExecutableSHA256": executable_sha256,
                "PortableMode": True,
                "SourceRepository": source["Repository"],
                "InstalledAtUTC": datetime.now(timezone.utc).isoformat(),
            }
        )

        emit_progress(progress, 100, 'Install Complete', "Version 0.10.5")
        install_complete = True
        return result(
            True,
            "installed",
            f'MGBA Version {emulator_version(info)} installed successfully.',
            details={
                "module_version": module_version(info),
                "version": version,
                "path": str(EXECUTABLE_PATH),
                "systems": ["nintendo.gameboyadvance"],
                "archive_sha256": archive_sha256,
                "executable_sha256": executable_sha256,
                "portable_marker": str(PORTABLE_MARKER),
                "bios_required": False,
                "source": source["OfficialWebsite"],
            },
        )
    except PermissionError as exc:
        return result(
            False,
            "install_failed",
            "MGBA installation could not write one or more required files.",
            "permission_denied",
            str(exc),
        )
    except Exception as exc:
        return result(
            False,
            "install_failed",
            "MGBA installation failed unexpectedly.",
            "install_exception",
            str(exc),
        )
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        if not install_complete:
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
