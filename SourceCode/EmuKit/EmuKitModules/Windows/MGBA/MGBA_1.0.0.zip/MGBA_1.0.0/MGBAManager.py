from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

MODULE_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
if str(MODULE_DIR) not in sys.path:
    sys.path.insert(0, str(MODULE_DIR))

from _MGBACommon import (
    EMULATOR_DIR,
    EXECUTABLE_PATH,
    PORTABLE_MARKER,
    RECEIPT_PATH,
    ProgressCallback,
    emit_progress,
    emulator_version,
    hash_file,
    is_supported_host,
    load_info,
    module_version,
    read_receipt,
    scaled_progress,
)
import MGBAInstaller
import MGBARepair
import MGBAUninstall

MODULE_ID = "mgba"
MODULE_NAME = "MGBA"


def base(
    success: bool,
    operation: str,
    state: str,
    message: str,
    error: str | None = None,
    details: Any = None,
) -> dict[str, Any]:
    value = {
        "success": success,
        "module": MODULE_ID,
        "operation": operation,
        "state": state,
        "message": message,
        "details": details,
    }
    if error:
        value["error"] = error
    return value


def check(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 8, 'Checking Host', "Windows x86_64")
    supported, reason = is_supported_host()
    if not supported:
        return base(
            False,
            "check",
            "unsupported",
            reason or "MGBA is not supported on this host.",
            "unsupported_host",
        )

    info = load_info()
    version = emulator_version(info)
    source = info["Source"]

    if not EMULATOR_DIR.exists():
        return base(
            True,
            "check",
            "missing",
            "MGBA is not installed.",
            details={"expected_path": str(EMULATOR_DIR)},
        )

    emit_progress(progress, 22, 'Checking Emulator', "mGBA.exe")
    if not EXECUTABLE_PATH.is_file():
        return base(
            True,
            "check",
            "broken",
            "The MGBA managed emulator directory exists but mGBA.exe is missing.",
            details={"expected_executable": str(EXECUTABLE_PATH)},
        )

    emit_progress(progress, 35, 'Checking Configuration', "portable.ini")
    if not PORTABLE_MARKER.is_file():
        return base(
            True,
            "check",
            "broken",
            "MGBA is installed but portable.ini is missing.",
            details={"portable_marker": str(PORTABLE_MARKER)},
        )

    emit_progress(progress, 48, 'Checking Receipt', ".emukit_install.json")
    receipt = read_receipt()
    if receipt is None:
        return base(
            True,
            "check",
            "broken",
            "MGBA is present but its EmuKit installation receipt is missing or invalid.",
            details={"receipt": str(RECEIPT_PATH)},
        )

    installed_version = str(
        receipt.get("EmulatorVersion", receipt.get("Version", ""))
    )
    if installed_version != version:
        return base(
            True,
            "check",
            "broken",
            "The installed MGBA build does not match the emulator version pinned by this module.",
            details={
                "installed_version": installed_version or None,
                "pinned_version": version,
            },
        )

    for key, label in (
        ("ReleaseTag", "release tag"),
        ("ReleaseCommit", "release commit"),
        ("Asset", "Windows asset"),
    ):
        pinned = str(source.get(key, "") or "")
        installed = str(receipt.get(key, "") or "")
        if pinned and installed.casefold() != pinned.casefold():
            return base(
                True,
                "check",
                "broken",
                f"The MGBA installation receipt does not match the module-pinned {label}.",
                details={
                    f"installed_{key.casefold()}": installed or None,
                    f"pinned_{key.casefold()}": pinned,
                },
            )

    expected_archive_sha256 = str(source.get("SHA256", "")).lower()
    receipt_archive_sha256 = str(receipt.get("ArchiveSHA256", "")).lower()
    if expected_archive_sha256 and receipt_archive_sha256 != expected_archive_sha256:
        return base(
            True,
            "check",
            "broken",
            "The MGBA installation receipt does not match the pinned official archive checksum.",
            details={
                "installed_archive_sha256": receipt_archive_sha256 or None,
                "pinned_archive_sha256": expected_archive_sha256,
            },
        )

    emit_progress(progress, 72, 'Checking Integrity', "mGBA.exe")
    expected_executable_sha256 = str(receipt.get("ExecutableSHA256", "")).lower()
    if not expected_executable_sha256:
        return base(
            True,
            "check",
            "broken",
            "The MGBA EmuKit receipt does not contain its installed executable checksum.",
            details={"receipt": str(RECEIPT_PATH)},
        )

    try:
        actual_executable_sha256 = hash_file(EXECUTABLE_PATH).lower()
    except OSError as exc:
        return base(
            True,
            "check",
            "broken",
            "mGBA.exe could not be read for integrity validation.",
            details={
                "path": str(EXECUTABLE_PATH),
                "exception": str(exc),
            },
        )

    if actual_executable_sha256 != expected_executable_sha256:
        return base(
            True,
            "check",
            "broken",
            "mGBA.exe no longer matches the EmuKit-managed installation.",
            details={
                "expected_sha256": expected_executable_sha256,
                "actual_sha256": actual_executable_sha256,
                "path": str(EXECUTABLE_PATH),
            },
        )

    emit_progress(progress, 100, 'Check Complete', "Version 0.10.5")
    return base(
        True,
        "check",
        "installed",
        f'MGBA Version {version} is installed and valid.',
        details={
            "module_version": module_version(info),
            "version": version,
            "path": str(EXECUTABLE_PATH),
            "systems": ["nintendo.gameboyadvance"],
            "portable_marker": str(PORTABLE_MARKER),
            "bios_required": False,
            "source": source["OfficialWebsite"],
        },
    )


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return MGBAInstaller.install(progress=progress)


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return MGBAUninstall.uninstall(progress=progress)


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return MGBARepair.repair(progress=progress)


def update(progress: ProgressCallback | None = None) -> dict[str, Any]:
    current = check(progress=scaled_progress(progress, 0, 20))
    if not current.get("success") and current.get("state") == "unsupported":
        current["operation"] = "update"
        return current

    if current.get("state") == "installed":
        return base(
            True,
            "update",
            "already_current",
            f'MGBA Version {emulator_version()} is already current.',
            details=current.get("details"),
        )

    repaired = MGBARepair.repair(progress=scaled_progress(progress, 20, 100))
    repaired["operation"] = "update"
    repaired["state"] = "updated" if repaired.get("success") else "update_failed"
    if repaired.get("success"):
        repaired["message"] = f'MGBA Version {emulator_version()} updated successfully.'
    return repaired


def write_record(record: dict[str, Any]) -> None:
    print(
        json.dumps(
            record,
            ensure_ascii=False,
            default=str,
            separators=(",", ":"),
        ),
        flush=True,
    )


def stream_progress(
    percent: int | None = None,
    stage: str | None = None,
    message: str | None = None,
) -> None:
    write_record(
        {
            "type": "progress",
            "percent": percent,
            "stage": stage,
            "message": message,
        }
    )


def run_cli() -> int:
    raw_args = sys.argv[1:]
    json_flags = [arg for arg in raw_args if arg.casefold() == "--json"]
    args = [arg for arg in raw_args if arg.casefold() != "--json"]
    operation = args[0].casefold() if len(args) == 1 else ""
    handlers = {
        "check": check,
        "install": install,
        "uninstall": uninstall,
        "repair": repair,
        "update": update,
    }
    handler = handlers.get(operation)

    if len(json_flags) != 1 or handler is None:
        result = base(
            False,
            operation or "manager",
            "invalid_operation",
            "MGBAManager requires one lifecycle operation: check, install, uninstall, repair, or update.",
            "invalid_operation",
        )
    else:
        try:
            result = handler(progress=stream_progress)
        except Exception as exc:
            result = base(
                False,
                operation,
                f"{operation}_failed",
                f"MGBAManager failed during {operation}.",
                "manager_exception",
                str(exc),
            )

    write_record({"type": "result", "result": result})
    return 0 if result.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(run_cli())
