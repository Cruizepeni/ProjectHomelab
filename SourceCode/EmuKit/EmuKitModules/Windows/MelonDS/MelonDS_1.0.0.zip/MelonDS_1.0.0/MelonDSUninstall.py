from __future__ import annotations

import shutil
from typing import Any

from _MelonDSCommon import EMULATOR_DIR, ProgressCallback, emit_progress


def result(success: bool, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {
        "success": success,
        "module": "melonds",
        "operation": "uninstall",
        "state": state,
        "message": message,
        "details": details,
    }
    if error:
        value["error"] = error
    return value


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 10, 'Preparing Uninstall', "Emulators/MelonDS")
    try:
        if not EMULATOR_DIR.exists():
            emit_progress(progress, 100, 'Uninstall Complete', "Emulators/MelonDS")
            return result(True, "uninstalled", "MelonDS is already uninstalled.")
        emit_progress(progress, 45, "Removing Emulator", "Emulators/MelonDS")
        shutil.rmtree(EMULATOR_DIR)
        emit_progress(progress, 95, 'Verifying Uninstall', "Emulators/MelonDS")
        if EMULATOR_DIR.exists():
            return result(False, "uninstall_failed", "MelonDS uninstall completed but its managed emulator directory still exists.", "dependency_directory_remains", {"path": str(EMULATOR_DIR)})
        emit_progress(progress, 100, 'Uninstall Complete', "Emulators/MelonDS")
        return result(True, "uninstalled", 'MelonDS uninstalled successfully.')
    except PermissionError as exc:
        return result(False, "uninstall_failed", "MelonDS could not be uninstalled because files are in use or EmuKit lacks permission to remove them.", "permission_denied", str(exc))
    except Exception as exc:
        return result(False, "uninstall_failed", "MelonDS could not be uninstalled.", "uninstall_exception", str(exc))
