from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from typing import Any

import MelonDSInstaller
import MelonDSUninstall
from _MelonDSCommon import *


def result(success: bool, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {
        "success": success,
        "module": "melonds",
        "operation": "repair",
        "state": state,
        "message": message,
        "details": details,
    }
    if error:
        value["error"] = error
    return value


def _state_target(state_dir: Path, source: Path) -> Path:
    return state_dir / source.relative_to(EMULATOR_DIR)


def _move_state_out(state_dir: Path) -> list[str]:
    preserved: list[str] = []
    for source in (DS_PORTABLE_DIR, DSI_PORTABLE_DIR):
        if source.exists():
            target = _state_target(state_dir, source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(source), str(target))
            preserved.append(str(source.relative_to(EMULATOR_DIR)))
    for source in mutable_runtime_files():
        if source.exists() and valid_mutable_runtime_file(source):
            target = _state_target(state_dir, source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(source), str(target))
            preserved.append(str(source.relative_to(EMULATOR_DIR)))
    return preserved


def _restore_state(state_dir: Path) -> list[str]:
    restored: list[str] = []
    if not state_dir.exists():
        return restored
    files = [path for path in state_dir.rglob("*") if path.is_file()]
    for source in files:
        relative = source.relative_to(state_dir)
        destination = EMULATOR_DIR / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            destination.unlink()
        shutil.move(str(source), str(destination))
        restored.append(str(relative))
    for directory in sorted((path for path in state_dir.rglob("*") if path.is_dir()), key=lambda item: len(item.parts), reverse=True):
        try:
            directory.rmdir()
        except OSError:
            pass
    return restored


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, "Checking Host", "Windows x86_64")
    supported, reason = is_supported_host()
    if not supported:
        return result(False, "unsupported", reason or "MelonDS is not supported on this host.", "unsupported_host")

    CACHE_ROOT.mkdir(parents=True, exist_ok=True)
    recovery_root = Path(tempfile.mkdtemp(prefix="Repair-", dir=str(CACHE_ROOT)))
    state_dir = recovery_root / "state"
    state_dir.mkdir(parents=True, exist_ok=True)
    preserved: list[str] = []

    try:
        emit_progress(progress, 6, 'Preparing Repair', "Emulators/MelonDS")
        if EMULATOR_DIR.exists():
            preserved = _move_state_out(state_dir)

        uninstall_result = MelonDSUninstall.uninstall(progress=scaled_progress(progress, 8, 18))
        if not uninstall_result.get("success"):
            EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
            restored = _restore_state(state_dir)
            return result(False, "repair_failed", "MelonDS repair could not continue because the existing installation could not be removed. Preserved state was restored.", uninstall_result.get("error", "uninstall_failed"), {"uninstall": uninstall_result, "restored": restored})

        install_result = MelonDSInstaller.install(progress=scaled_progress(progress, 18, 90))
        if not install_result.get("success"):
            EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
            restored = _restore_state(state_dir)
            return result(False, "repair_failed", "MelonDS was removed, but the clean reinstall failed. Preserved state was restored.", install_result.get("error", "install_failed"), {"install": install_result, "restored": restored})

        emit_progress(progress, 92, 'Restoring User Data', "NintendoDS/portable/ + NintendoDSi/portable/")
        restored = _restore_state(state_dir)

        emit_progress(progress, 95, "Configuring Emulator", "NintendoDS/portable/melonDS.toml + NintendoDSi/portable/melonDS.toml")
        configure_profiles()

        emit_progress(progress, 98, "Verifying Installation", "NintendoDS/melonDS.exe + NintendoDSi/melonDS.exe")
        runtime = runtime_resource_status()
        configs = profile_config_status()
        if not runtime["ready"] or not configs["ready"]:
            return result(False, "repair_failed", "MelonDS was reinstalled but preserved state did not pass final validation.", "post_repair_validation_failed", {"runtime_resources": runtime, "profiles": configs, "preserved": preserved, "restored": restored})

        emit_progress(progress, 100, 'Repair Complete', "Version 1.1")
        return result(True, "repaired", 'MelonDS repaired successfully.', details={"install": install_result.get("details"), "preserved": preserved, "restored": restored})
    except Exception as exc:
        restored: list[str] = []
        try:
            EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
            restored = _restore_state(state_dir)
        except Exception:
            pass
        return result(False, "repair_failed", "MelonDS repair failed unexpectedly.", "repair_exception", {"exception": str(exc), "restored": restored, "recovery_path": str(recovery_root)})
    finally:
        try:
            if state_dir.exists() and not any(state_dir.rglob("*")):
                shutil.rmtree(recovery_root, ignore_errors=True)
            elif not state_dir.exists():
                shutil.rmtree(recovery_root, ignore_errors=True)
        except OSError:
            pass
