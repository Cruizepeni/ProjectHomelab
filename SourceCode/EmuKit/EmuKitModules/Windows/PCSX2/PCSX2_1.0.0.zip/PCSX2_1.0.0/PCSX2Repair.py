from __future__ import annotations

from _PCSX2Common import ProgressCallback, scaled_progress
import PCSX2Installer
import PCSX2Uninstall


def repair(progress: ProgressCallback | None = None) -> dict:
    removed = PCSX2Uninstall.uninstall(progress=scaled_progress(progress, 0, 15))
    if not removed.get("success"):
        return {"success": False, "module": "pcsx2", "operation": "repair", "state": "repair_failed", "error": removed.get("error", "uninstall_failed"), "message": "PCSX2 repair could not continue because the existing emulator could not be removed.", "details": removed}
    installed = PCSX2Installer.install(progress=scaled_progress(progress, 15, 98))
    if not installed.get("success"):
        return {"success": False, "module": "pcsx2", "operation": "repair", "state": "repair_failed", "error": installed.get("error", "install_failed"), "message": ("PCSX2 was removed successfully, but the clean reinstall failed. " + str(installed.get("message", ""))).strip(), "details": installed}
    return {"success": True, "module": "pcsx2", "operation": "repair", "state": "repaired", "message": "PCSX2 was repaired successfully using a clean reinstall.", "details": installed.get("details")}
