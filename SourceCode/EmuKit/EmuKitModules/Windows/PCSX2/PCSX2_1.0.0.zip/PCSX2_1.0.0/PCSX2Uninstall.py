from __future__ import annotations

import shutil
from typing import Any

from _PCSX2Common import EMULATOR_DIR, ProgressCallback, emit_progress


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    try:
        if not EMULATOR_DIR.exists():
            return {"success": True, "module": "pcsx2", "operation": "uninstall", "state": "uninstalled", "message": "PCSX2 is already uninstalled.", "details": None}
        emit_progress(progress, 25, "Removing")
        shutil.rmtree(EMULATOR_DIR)
        if EMULATOR_DIR.exists():
            return {"success": False, "module": "pcsx2", "operation": "uninstall", "state": "uninstall_failed", "error": "emulator_directory_remains", "message": "PCSX2 uninstall completed but its managed emulator directory still exists.", "details": {"path": str(EMULATOR_DIR)}}
        emit_progress(progress, 95, "Verifying")
        return {"success": True, "module": "pcsx2", "operation": "uninstall", "state": "uninstalled", "message": "PCSX2 was uninstalled successfully.", "details": None}
    except PermissionError as exc:
        return {"success": False, "module": "pcsx2", "operation": "uninstall", "state": "uninstall_failed", "error": "permission_denied", "message": "PCSX2 could not be uninstalled because one or more files are in use or EmuKit does not have permission.", "details": str(exc)}
    except Exception as exc:
        return {"success": False, "module": "pcsx2", "operation": "uninstall", "state": "uninstall_failed", "error": "uninstall_exception", "message": "PCSX2 could not be uninstalled.", "details": str(exc)}
