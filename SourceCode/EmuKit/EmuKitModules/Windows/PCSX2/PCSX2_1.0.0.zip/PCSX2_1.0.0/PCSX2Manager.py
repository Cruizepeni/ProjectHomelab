from __future__ import annotations

import configparser
import json
import sys
from pathlib import Path
from typing import Any

MODULE_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
if str(MODULE_DIR) not in sys.path:
    sys.path.insert(0, str(MODULE_DIR))

from _PCSX2Common import *
import PCSX2Installer
import PCSX2Repair
import PCSX2Uninstall


def base(success: bool, operation: str, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "pcsx2", "operation": operation, "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def configured_bios_name() -> str | None:
    if not CONFIG_PATH.is_file():
        return None
    parser = configparser.ConfigParser()
    parser.optionxform = str
    try:
        parser.read(CONFIG_PATH, encoding="utf-8")
    except Exception:
        return None
    if not parser.has_section("Filenames"):
        return None
    value = parser.get("Filenames", "BIOS", fallback="").strip()
    return value or None


def check(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 10, 'Checking Host', "Windows x86_64")
    supported, reason = is_supported_host()
    if not supported:
        return base(False, "check", "unsupported", reason or "PCSX2 is not supported on this host.", "unsupported_host")
    info = load_info()
    version = emulator_version(info)
    if not EMULATOR_DIR.exists():
        return base(True, "check", "missing", "PCSX2 is not installed.", details={"expected_path": str(EMULATOR_DIR)})
    emit_progress(progress, 30, 'Checking Emulator', "pcsx2-qt.exe")
    if not EXECUTABLE_PATH.is_file():
        return base(True, "check", "broken", "The PCSX2 emulator directory exists but pcsx2-qt.exe is missing.", details={"expected_executable": str(EXECUTABLE_PATH)})
    if not PORTABLE_MARKER.is_file():
        return base(True, "check", "broken", "PCSX2 is installed but portable mode is not enabled.", details={"expected": str(PORTABLE_MARKER)})
    if not CONFIG_PATH.is_file():
        return base(True, "check", "broken", "PCSX2 is installed but its portable configuration is missing.", details={"expected": str(CONFIG_PATH)})
    emit_progress(progress, 50, 'Checking Resources', "bios/")
    configured_bios = configured_bios_name()
    expected_bios = str(info["Resources"]["BIOS"]["SelectedBIOS"])
    if configured_bios != expected_bios:
        return base(True, "check", "broken", "PCSX2's configured BIOS does not match the module-selected BIOS.", details={"configured": configured_bios, "expected": expected_bios})
    bios_path = INSTALLED_BIOS_DIR / expected_bios
    if not bios_path.is_file():
        return base(True, "check", "broken", "PCSX2's configured PlayStation 2 BIOS file is missing.", details={"expected": str(bios_path)})
    specification = selected_bios_specification(info)
    if specification is None:
        return base(True, "check", "broken", "PCSX2's selected BIOS metadata is invalid.", details=None)
    actual_size = bios_path.stat().st_size
    actual_sha256 = hash_file(bios_path, "sha256").lower()
    actual_md5 = hash_file(bios_path, "md5").lower()
    if actual_size != int(specification["Size"]) or actual_sha256 != str(specification["SHA256"]).lower() or actual_md5 != str(specification["MD5"]).lower():
        return base(True, "check", "broken", "PCSX2's selected BIOS failed checksum validation.", details={"path": str(bios_path), "size": actual_size, "sha256": actual_sha256, "md5": actual_md5})
    romver = parse_romver(bios_path)
    if romver is None:
        return base(True, "check", "broken", "PCSX2's selected BIOS failed ROMVER validation.", details={"path": str(bios_path)})
    emit_progress(progress, 75, 'Checking Receipt', ".emukit_install.json")
    receipt = read_receipt()
    if receipt is None:
        return base(True, "check", "broken", "PCSX2 is present but its EmuKit installation receipt is missing or invalid.", details={"receipt": str(RECEIPT_PATH)})
    if receipt.get("EmulatorVersion") != version:
        return base(True, "check", "broken", "The installed PCSX2 build does not match the module-pinned emulator version.", details={"installed_version": receipt.get("EmulatorVersion"), "pinned_version": version})
    if str(receipt.get("ArchiveSHA256", "")).lower() != str(info["Source"]["SHA256"]).lower():
        return base(True, "check", "broken", "The installed PCSX2 receipt does not match the pinned archive checksum.", details={"installed_sha256": receipt.get("ArchiveSHA256"), "pinned_sha256": info["Source"]["SHA256"]})
    emit_progress(progress, 100, 'Check Complete', "Version 2.8.2")
    return base(
        True,
        "check",
        "installed",
        f'PCSX2 Version {version} is installed and valid.',
        details={
            "module_version": module_version(info),
            "version": version,
            "path": str(EXECUTABLE_PATH),
            "portable": True,
            "bios": {"file": expected_bios, "region": romver["region"], "version": romver["version"], "romver": romver["romver"], "sha256": actual_sha256},
            "source": info["Source"]["OfficialRepository"],
        },
    )


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return PCSX2Installer.install(progress=progress)


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return PCSX2Uninstall.uninstall(progress=progress)


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return PCSX2Repair.repair(progress=progress)


def update(progress: ProgressCallback | None = None) -> dict[str, Any]:
    current = check(progress=scaled_progress(progress, 0, 20))
    if not current.get("success") and current.get("state") == "unsupported":
        current["operation"] = "update"
        return current
    if current.get("state") == "installed":
        return base(True, "update", "already_current", f'PCSX2 Version {emulator_version()} is already current.', details=current.get("details"))
    repaired = PCSX2Repair.repair(progress=scaled_progress(progress, 20, 98))
    repaired["operation"] = "update"
    repaired["state"] = "updated" if repaired.get("success") else "update_failed"
    if repaired.get("success"):
        repaired["message"] = f'PCSX2 Version {emulator_version()} updated successfully.'
    return repaired


def _write_record(record: dict[str, Any]) -> None:
    print(json.dumps(record, ensure_ascii=False, default=str, separators=(",", ":")), flush=True)


def _stream_progress(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
    _write_record({"type": "progress", "percent": percent, "stage": stage, "message": message})


def _run_cli() -> int:
    raw_args = sys.argv[1:]
    json_flags = [arg for arg in raw_args if arg.casefold() == "--json"]
    args = [arg for arg in raw_args if arg.casefold() != "--json"]
    operation = args[0].casefold() if len(args) == 1 else ""
    handlers = {
        "check": check,
        "install": install,
        "uninstall": uninstall,
        "repair": repair,
        "update": update,
    }
    handler = handlers.get(operation)
    if len(json_flags) != 1 or handler is None:
        result = base(
            False,
            operation or "manager",
            "invalid_operation",
            "PCSX2Manager requires one lifecycle operation: check, install, uninstall, repair, or update.",
            "invalid_operation",
        )
    else:
        try:
            result = handler(progress=_stream_progress)
        except Exception as exc:
            result = base(
                False,
                operation,
                f"{operation}_failed",
                f"PCSX2Manager failed during {operation}.",
                "manager_exception",
                str(exc),
            )
    _write_record({"type": "result", "result": result})
    return 0 if result.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(_run_cli())
