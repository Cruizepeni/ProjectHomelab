from __future__ import annotations

import hashlib
import json
import platform
import sys
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Callable

MODULE_DIR = (
    Path(sys.executable).resolve().parent
    if getattr(sys, "frozen", False)
    else Path(__file__).resolve().parent
)
INFO_PATH = MODULE_DIR / "EmuKitDuckStationInfo.json"
ROOT_MARKER = ".AppRoot"
ProgressCallback = Callable[[int | None, str | None, str | None], None]


def resolve_root() -> Path:
    current = MODULE_DIR.resolve()
    for candidate in (current, *current.parents):
        if (candidate / ROOT_MARKER).is_file():
            return candidate
    if MODULE_DIR.parent.name.casefold() == "emukitmodules":
        return MODULE_DIR.parent.parent
    return MODULE_DIR


ROOT = resolve_root()
EMULATOR_DIR = ROOT / "Emulators" / "DuckStation"
EXECUTABLE_PATH = EMULATOR_DIR / "duckstation-qt-x64-ReleaseLTCG.exe"
PORTABLE_MARKER = EMULATOR_DIR / "portable.txt"
INSTALLED_BIOS_DIR = EMULATOR_DIR / "bios"
RECEIPT_PATH = EMULATOR_DIR / ".emukit_install.json"


def load_info() -> dict[str, Any]:
    return json.loads(INFO_PATH.read_text(encoding="utf-8"))


def module_version(info: dict[str, Any] | None = None) -> str:
    source = info if isinstance(info, dict) else load_info()
    return str(source["ModuleVersion"])


def emulator_version(info: dict[str, Any] | None = None) -> str:
    source = info if isinstance(info, dict) else load_info()
    return str(source["EmulatorVersion"])


def emit_progress(progress: ProgressCallback | None, percent: int | None, stage: str | None, message: str | None = None) -> None:
    if progress is not None:
        progress(percent, stage, message)


def scaled_progress(progress: ProgressCallback | None, start: int, end: int) -> ProgressCallback | None:
    if progress is None:
        return None

    def callback(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
        if percent is None:
            mapped = None
        else:
            bounded = max(0, min(100, int(percent)))
            mapped = start + round((end - start) * bounded / 100)
        progress(mapped, stage, message)

    return callback


def is_supported_host() -> tuple[bool, str | None]:
    if platform.system().lower() != "windows":
        return False, "DuckStation module 1.0.0 currently supports Windows only."
    if platform.machine().lower() not in {"amd64", "x86_64"}:
        return False, f'DuckStation module 1.0.0 requires Windows x86_64. Current architecture: "{platform.machine()}".'
    return True, None


def hash_file(path: Path, algorithm: str) -> str:
    digest = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_receipt() -> dict[str, Any] | None:
    try:
        value = json.loads(RECEIPT_PATH.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def request_json(url: str, timeout: int = 30) -> dict[str, Any]:
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": "ProjectHomelab-EmuKit-DuckStation/1.0.0",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        value = json.loads(response.read().decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Remote JSON root is not an object.")
    return value


def load_resource_catalog(info: dict[str, Any]) -> dict[str, dict[str, Any]]:
    manifest = request_json(str(info["ResourceCatalog"]["ManifestURL"]))
    resources = manifest.get("resources")
    if not isinstance(resources, list):
        raise ValueError("EmuKit resource manifest does not contain a resources list.")
    mapping: dict[str, dict[str, Any]] = {}
    for entry in resources:
        if isinstance(entry, dict) and isinstance(entry.get("path"), str):
            mapping[entry["path"]] = entry
    return mapping


def validate_catalog_entry(catalog: dict[str, dict[str, Any]], specification: dict[str, Any]) -> dict[str, Any]:
    path = str(specification["Path"])
    entry = catalog.get(path)
    if not isinstance(entry, dict):
        raise ValueError(f'Required EmuKit resource is not registered: "{path}".')
    if int(entry.get("size", -1)) != int(specification["Size"]):
        raise ValueError(f'Resource size changed for "{path}".')
    if str(entry.get("sha256", "")).lower() != str(specification["SHA256"]).lower():
        raise ValueError(f'Resource SHA-256 changed for "{path}".')
    if str(entry.get("md5", "")).lower() != str(specification["MD5"]).lower():
        raise ValueError(f'Resource MD5 changed for "{path}".')
    return entry


def resource_url(info: dict[str, Any], relative_path: str) -> str:
    base = str(info["ResourceCatalog"]["RawBaseURL"]).rstrip("/")
    return base + "/" + urllib.parse.quote(relative_path, safe="/")


def known_bios_by_md5(info: dict[str, Any]) -> dict[str, dict[str, Any]]:
    accepted = info.get("Resources", {}).get("BIOS", {}).get("Accepted", [])
    mapping: dict[str, dict[str, Any]] = {}
    if not isinstance(accepted, list):
        return mapping
    for entry in accepted:
        if isinstance(entry, dict) and isinstance(entry.get("MD5"), str):
            mapping[str(entry["MD5"]).lower()] = entry
    return mapping


def scan_bios_directory(directory: Path, info: dict[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    known = known_bios_by_md5(info)
    recognized: list[dict[str, Any]] = []
    ignored: list[dict[str, Any]] = []
    seen_hashes: set[str] = set()
    if not directory.is_dir():
        return recognized, ignored
    for path in sorted(directory.iterdir()):
        if not path.is_file() or path.suffix.lower() != ".bin":
            continue
        try:
            size = path.stat().st_size
            md5 = hash_file(path, "md5").lower()
            sha256 = hash_file(path, "sha256").lower()
        except OSError as exc:
            ignored.append({"path": str(path), "reason": "read_failed", "details": str(exc)})
            continue
        record = known.get(md5)
        if record is None:
            ignored.append({"path": str(path), "reason": "unrecognized_checksum", "size": size, "md5": md5})
            continue
        if size != int(record.get("Size", -1)):
            ignored.append({"path": str(path), "reason": "size_mismatch", "size": size, "expected_size": record.get("Size"), "md5": md5})
            continue
        if sha256 != str(record.get("SHA256", "")).lower():
            ignored.append({"path": str(path), "reason": "sha256_mismatch", "sha256": sha256, "expected_sha256": record.get("SHA256")})
            continue
        if md5 in seen_hashes:
            ignored.append({"path": str(path), "reason": "duplicate_bios", "md5": md5})
            continue
        seen_hashes.add(md5)
        recognized.append({
            "path": path,
            "md5": md5,
            "sha256": sha256,
            "size": size,
            "name": record.get("Name"),
            "region": record.get("Region"),
            "install_as": record.get("InstallAs"),
        })
    return recognized, ignored
