from __future__ import annotations

import shutil
from typing import Any
from _DuckStationCommon import EMULATOR_DIR, ProgressCallback, emit_progress


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Preparing Uninstall', "Emulators/DuckStation")
    try:
        if not EMULATOR_DIR.exists():
            emit_progress(progress, 100, 'Uninstall Complete', "Emulators/DuckStation")
            return {"success": True, "module": "duckstation", "operation": "uninstall", "state": "uninstalled", "message": "DuckStation is already uninstalled.", "details": None}
        emit_progress(progress, 25, 'Removing Emulator', "Emulators/DuckStation")
        shutil.rmtree(EMULATOR_DIR)
        if EMULATOR_DIR.exists():
            return {"success": False, "module": "duckstation", "operation": "uninstall", "state": "uninstall_failed", "error": "emulator_directory_remains", "message": "DuckStation uninstall completed but its managed emulator directory still exists.", "details": {"path": str(EMULATOR_DIR)}}
        emit_progress(progress, 95, 'Verifying Uninstall', "Emulators/DuckStation")
        emit_progress(progress, 100, 'Uninstall Complete', "Emulators/DuckStation")
        return {"success": True, "module": "duckstation", "operation": "uninstall", "state": "uninstalled", "message": "DuckStation uninstalled successfully.", "details": None}
    except PermissionError as exc:
        return {"success": False, "module": "duckstation", "operation": "uninstall", "state": "uninstall_failed", "error": "permission_denied", "message": "DuckStation could not be uninstalled because one or more files are in use or EmuKit does not have permission.", "details": str(exc)}
    except Exception as exc:
        return {"success": False, "module": "duckstation", "operation": "uninstall", "state": "uninstall_failed", "error": "uninstall_exception", "message": "DuckStation could not be uninstalled.", "details": str(exc)}
