from __future__ import annotations

from _DuckStationCommon import ProgressCallback, scaled_progress
import DuckStationInstaller
import DuckStationUninstall


def repair(progress: ProgressCallback | None = None) -> dict:
    emit_progress(progress, 3, 'Preparing Repair', "Emulators/DuckStation")
    removed = DuckStationUninstall.uninstall(progress=scaled_progress(progress, 0, 15))
    if not removed.get("success"):
        return {"success": False, "module": "duckstation", "operation": "repair", "state": "repair_failed", "error": removed.get("error", "uninstall_failed"), "message": "DuckStation repair could not continue because the existing emulator could not be removed.", "details": removed}
    installed = DuckStationInstaller.install(progress=scaled_progress(progress, 15, 98))
    if not installed.get("success"):
        return {"success": False, "module": "duckstation", "operation": "repair", "state": "repair_failed", "error": installed.get("error", "install_failed"), "message": ("DuckStation was removed successfully, but the clean reinstall failed. " + str(installed.get("message", ""))).strip(), "details": installed}
    emit_progress(progress, 100, 'Repair Complete', "Version 20260912-gc66b2694")
    return {"success": True, "module": "duckstation", "operation": "repair", "state": "repaired", "message": 'DuckStation repaired successfully.', "details": installed.get("details")}
