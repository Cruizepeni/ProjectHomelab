from __future__ import annotations

import shutil
from typing import Any

from _MednafenCommon import EMULATOR_DIR, ProgressCallback, emit_progress


def result(
    success: bool,
    state: str,
    message: str,
    error: str | None = None,
    details: Any = None,
) -> dict[str, Any]:
    value = {
        "success": success,
        "module": "mednafen",
        "operation": "uninstall",
        "state": state,
        "message": message,
        "details": details,
    }
    if error:
        value["error"] = error
    return value


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Preparing Uninstall', "Emulators/Mednafen")
    emit_progress(progress, 10, 'Removing Emulator', "Emulators/Mednafen")
    try:
        if not EMULATOR_DIR.exists():
            return result(True, "uninstalled", "Mednafen is already uninstalled.")

        shutil.rmtree(EMULATOR_DIR)
        emit_progress(progress, 90, 'Verifying Uninstall', "Emulators/Mednafen")

        if EMULATOR_DIR.exists():
            return result(
                False,
                "uninstall_failed",
                "Mednafen uninstall completed but its managed emulator directory still exists.",
                "emulator_directory_remains",
                {"path": str(EMULATOR_DIR)},
            )

        emit_progress(progress, 100, 'Uninstall Complete', "Emulators/Mednafen")
        return result(True, "uninstalled", 'Mednafen uninstalled successfully.')
    except PermissionError as exc:
        return result(
            False,
            "uninstall_failed",
            "Mednafen could not be uninstalled because one or more files are in use or EmuKit does not have permission to remove them.",
            "permission_denied",
            str(exc),
        )
    except Exception as exc:
        return result(
            False,
            "uninstall_failed",
            "Mednafen could not be uninstalled.",
            "uninstall_exception",
            str(exc),
        )
