from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

import MednafenInstaller
import MednafenUninstall
from _MednafenCommon import (
    EMULATOR_DIR,
    PERSISTENT_ENTRIES,
    RECOVERY_PARENT,
    ProgressCallback,
    emit_progress,
    emulator_version,
    scaled_progress,
)


def move_state_out(state_dir: Path) -> list[str]:
    preserved: list[str] = []
    for name in PERSISTENT_ENTRIES:
        source = EMULATOR_DIR / name
        if not source.exists():
            continue
        shutil.move(str(source), str(state_dir / name))
        preserved.append(name)
    return preserved


def restore_state(state_dir: Path) -> list[str]:
    restored: list[str] = []
    if not state_dir.exists():
        return restored

    for item in list(state_dir.iterdir()):
        destination = EMULATOR_DIR / item.name
        if destination.exists():
            if destination.is_dir():
                shutil.rmtree(destination)
            else:
                destination.unlink()
        shutil.move(str(item), str(destination))
        restored.append(item.name)

    return restored


def repair(progress: ProgressCallback | None = None) -> dict:
    emit_progress(progress, 3, 'Preparing Repair', "Emulators/Mednafen")
    RECOVERY_PARENT.mkdir(parents=True, exist_ok=True)
    recovery_root = Path(
        tempfile.mkdtemp(prefix="Mednafen-Repair-", dir=str(RECOVERY_PARENT))
    )
    state_dir = recovery_root / "state"
    state_dir.mkdir(parents=True, exist_ok=True)
    preserved: list[str] = []

    try:
        emit_progress(progress, 3, 'Preserving User Data', "mednafen.cfg + sav/ + mcs/ + mcm/ + mcd/ + cheats/ + snaps/ + palettes/ + pgconfig/")
        if EMULATOR_DIR.exists():
            preserved = move_state_out(state_dir)

        uninstall_result = MednafenUninstall.uninstall(
            progress=scaled_progress(progress, 5, 18)
        )

        if not uninstall_result.get("success"):
            try:
                EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
                restored = restore_state(state_dir)
            except Exception as restore_exc:
                return {
                    "success": False,
                    "module": "mednafen",
                    "operation": "repair",
                    "state": "repair_failed",
                    "error": "uninstall_and_restore_failed",
                    "message": "Mednafen repair could not remove the existing emulator and portable-state recovery also failed.",
                    "details": {
                        "uninstall": uninstall_result,
                        "restore_exception": str(restore_exc),
                        "recovery_path": str(recovery_root),
                    },
                }

            return {
                "success": False,
                "module": "mednafen",
                "operation": "repair",
                "state": "repair_failed",
                "error": uninstall_result.get("error", "uninstall_failed"),
                "message": "Mednafen repair could not continue because the existing emulator could not be removed. Portable state was restored.",
                "details": {"uninstall": uninstall_result, "restored": restored},
            }

        install_result = MednafenInstaller.install(
            progress=scaled_progress(progress, 18, 91)
        )

        if not install_result.get("success"):
            try:
                EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
                restored = restore_state(state_dir)
            except Exception as restore_exc:
                return {
                    "success": False,
                    "module": "mednafen",
                    "operation": "repair",
                    "state": "repair_failed",
                    "error": "install_and_restore_failed",
                    "message": "Mednafen reinstall failed and portable-state recovery could not be completed automatically.",
                    "details": {
                        "install": install_result,
                        "restore_exception": str(restore_exc),
                        "recovery_path": str(recovery_root),
                    },
                }

            return {
                "success": False,
                "module": "mednafen",
                "operation": "repair",
                "state": "repair_failed",
                "error": install_result.get("error", "install_failed"),
                "message": (
                    "Mednafen was removed successfully, but the clean reinstall failed. "
                    "Portable state was restored. "
                    + str(install_result.get("message", ""))
                ).strip(),
                "details": {"install": install_result, "restored": restored},
            }

        emit_progress(progress, 93, 'Restoring User Data', "mednafen.cfg + sav/ + mcs/ + mcm/ + mcd/ + cheats/ + snaps/ + palettes/ + pgconfig/")

        try:
            restored = restore_state(state_dir)
        except Exception as exc:
            return {
                "success": False,
                "module": "mednafen",
                "operation": "repair",
                "state": "repair_failed",
                "error": "state_restore_failed",
                "message": "Mednafen was reinstalled, but its preserved portable state could not be restored automatically.",
                "details": {
                    "install": install_result,
                    "exception": str(exc),
                    "recovery_path": str(recovery_root),
                },
            }

        emit_progress(progress, 100, 'Repair Complete', "Version 1.32.1")

        return {
            "success": True,
            "module": "mednafen",
            "operation": "repair",
            "state": "repaired",
            "message": 'Mednafen repaired successfully.',
            "details": {
                "install": install_result.get("details"),
                "preserved": preserved,
                "restored": restored,
            },
        }
    finally:
        shutil.rmtree(recovery_root, ignore_errors=True)
