from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from typing import Any

import CemuInstaller
import CemuUninstall
from _CemuCommon import (
    EMULATOR_DIR,
    PORTABLE_DIR,
    PRESERVED_ROOT_FILES,
    RECOVERY_PARENT,
    ProgressCallback,
    emit_progress,
    emulator_version,
    scaled_progress,
)


def move_state_out(state_dir: Path) -> list[str]:
    preserved: list[str] = []
    if PORTABLE_DIR.exists():
        shutil.move(str(PORTABLE_DIR), str(state_dir / "portable"))
        preserved.append("portable")
    for name in PRESERVED_ROOT_FILES:
        source = EMULATOR_DIR / name
        if source.exists():
            shutil.move(str(source), str(state_dir / name))
            preserved.append(name)
    return preserved


def restore_state(state_dir: Path) -> list[str]:
    restored: list[str] = []
    portable = state_dir / "portable"
    if portable.exists():
        if PORTABLE_DIR.exists():
            shutil.rmtree(PORTABLE_DIR)
        shutil.move(str(portable), str(PORTABLE_DIR))
        restored.append("portable")
    for name in PRESERVED_ROOT_FILES:
        source = state_dir / name
        if source.exists():
            destination = EMULATOR_DIR / name
            if destination.exists():
                if destination.is_dir():
                    shutil.rmtree(destination)
                else:
                    destination.unlink()
            shutil.move(str(source), str(destination))
            restored.append(name)
    return restored


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Preparing Repair', "Emulators/Cemu")
    RECOVERY_PARENT.mkdir(parents=True, exist_ok=True)
    recovery_root = Path(
        tempfile.mkdtemp(prefix="Cemu-Repair-", dir=str(RECOVERY_PARENT))
    )
    state_dir = recovery_root / "state"
    state_dir.mkdir(parents=True, exist_ok=True)
    preserved: list[str] = []

    try:
        emit_progress(progress, 3, 'Preserving User Data', "portable/ + keys.txt + otp.bin + seeprom.bin")
        if EMULATOR_DIR.exists():
            preserved = move_state_out(state_dir)

        uninstall_result = CemuUninstall.uninstall(
            progress=scaled_progress(progress, 5, 18)
        )
        if not uninstall_result.get("success"):
            try:
                EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
                restore_state(state_dir)
            except Exception as restore_exc:
                return {
                    "success": False,
                    "module": "cemu",
                    "operation": "repair",
                    "state": "repair_failed",
                    "error": "uninstall_and_restore_failed",
                    "message": "Cemu repair could not remove the existing emulator and portable state recovery also failed.",
                    "details": {
                        "uninstall": uninstall_result,
                        "restore_exception": str(restore_exc),
                        "recovery_path": str(recovery_root),
                    },
                }
            return {
                "success": False,
                "module": "cemu",
                "operation": "repair",
                "state": "repair_failed",
                "error": uninstall_result.get("error", "uninstall_failed"),
                "message": "Cemu repair could not continue because the existing emulator could not be removed. Portable state was restored.",
                "details": uninstall_result,
            }

        install_result = CemuInstaller.install(
            progress=scaled_progress(progress, 18, 91)
        )
        if not install_result.get("success"):
            try:
                EMULATOR_DIR.mkdir(parents=True, exist_ok=True)
                restore_state(state_dir)
            except Exception as restore_exc:
                return {
                    "success": False,
                    "module": "cemu",
                    "operation": "repair",
                    "state": "repair_failed",
                    "error": "install_and_restore_failed",
                    "message": "Cemu reinstall failed and portable state recovery could not be completed automatically.",
                    "details": {
                        "install": install_result,
                        "restore_exception": str(restore_exc),
                        "recovery_path": str(recovery_root),
                    },
                }
            return {
                "success": False,
                "module": "cemu",
                "operation": "repair",
                "state": "repair_failed",
                "error": install_result.get("error", "install_failed"),
                "message": (
                    "Cemu was removed successfully, but the clean reinstall failed. "
                    "Portable state was restored. "
                    + str(install_result.get("message", ""))
                ).strip(),
                "details": install_result,
            }

        emit_progress(progress, 93, 'Restoring User Data', "portable/ + keys.txt + otp.bin + seeprom.bin")
        try:
            restored = restore_state(state_dir)
        except Exception as exc:
            return {
                "success": False,
                "module": "cemu",
                "operation": "repair",
                "state": "repair_failed",
                "error": "state_restore_failed",
                "message": "Cemu was reinstalled, but its preserved portable state could not be restored automatically.",
                "details": {
                    "install": install_result,
                    "exception": str(exc),
                    "recovery_path": str(recovery_root),
                },
            }

        emit_progress(progress, 100, 'Repair Complete', "Version 2.6")
        return {
            "success": True,
            "module": "cemu",
            "operation": "repair",
            "state": "repaired",
            "message": 'Cemu repaired successfully.',
            "details": {
                "install": install_result.get("details"),
                "preserved": preserved,
                "restored": restored,
            },
        }
    finally:
        try:
            if state_dir.exists() and not any(state_dir.iterdir()):
                shutil.rmtree(recovery_root, ignore_errors=True)
            elif not state_dir.exists():
                shutil.rmtree(recovery_root, ignore_errors=True)
        except OSError:
            pass
