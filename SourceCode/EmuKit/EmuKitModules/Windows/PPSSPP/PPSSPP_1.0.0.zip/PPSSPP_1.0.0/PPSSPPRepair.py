from __future__ import annotations

from typing import Any

from _PPSSPPCommon import ProgressCallback, scaled_progress
import PPSSPPInstaller
import PPSSPPUninstall


def result(success: bool, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "ppsspp", "operation": "repair", "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Preparing Repair', "Emulators/PPSSPP")
    removed = PPSSPPUninstall.uninstall(progress=scaled_progress(progress, 0, 15))
    if not removed.get("success"):
        return result(False, "repair_failed", "PPSSPP repair could not continue because the existing emulator could not be removed.", str(removed.get("error") or "uninstall_failed"), removed)
    installed = PPSSPPInstaller.install(progress=scaled_progress(progress, 15, 98))
    if not installed.get("success"):
        return result(False, "repair_failed", "PPSSPP was removed successfully, but the clean reinstall failed.", str(installed.get("error") or "install_failed"), installed)
    emit_progress(progress, 100, 'Repair Complete', "Version 1.20.4")
    return result(True, "repaired", 'PPSSPP repaired successfully.', details=installed.get("details"))
