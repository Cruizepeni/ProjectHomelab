from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

MODULE_DIR = (
    Path(sys.executable).resolve().parent
    if getattr(sys, "frozen", False)
    else Path(__file__).resolve().parent
)
if str(MODULE_DIR) not in sys.path:
    sys.path.insert(0, str(MODULE_DIR))

from _PPSSPPCommon import EMULATOR_DIR, EXECUTABLE_PATH, INSTALLED_MARKER, MEMSTICK_DIR, RECEIPT_PATH, ProgressCallback, emit_progress, emulator_version, is_supported_host, load_info, module_version, read_receipt, scaled_progress
import PPSSPPInstaller
import PPSSPPRepair
import PPSSPPUninstall


def base(success: bool, operation: str, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "ppsspp", "operation": operation, "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def check(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 15, 'Checking Host', "Windows x86_64")
    supported, reason = is_supported_host()
    if not supported:
        return base(False, "check", "unsupported", reason or "PPSSPP is not supported on this host.", "unsupported_host")

    info = load_info()
    version = emulator_version(info)
    if not EMULATOR_DIR.exists():
        return base(True, "check", "missing", "PPSSPP is not installed.", details={"expected_path": str(EMULATOR_DIR)})

    emit_progress(progress, 35, 'Checking Emulator', "PPSSPPWindows64.exe")
    if not EXECUTABLE_PATH.is_file():
        return base(True, "check", "broken", "The PPSSPP emulator directory exists but PPSSPPWindows64.exe is missing.", details={"expected": str(EXECUTABLE_PATH)})

    emit_progress(progress, 55, 'Checking Configuration', "installed.txt + memstick/")
    if INSTALLED_MARKER.exists():
        return base(True, "check", "broken", "PPSSPP is installed but installed.txt is present, so its Memory Stick may be redirected outside the EmuKit-managed emulator directory.", details={"unexpected_marker": str(INSTALLED_MARKER), "expected_memstick": str(MEMSTICK_DIR)})
    if not MEMSTICK_DIR.is_dir():
        return base(True, "check", "broken", "PPSSPP is installed but its local portable memstick is missing.", details={"expected": str(MEMSTICK_DIR)})

    emit_progress(progress, 75, 'Checking Receipt', ".emukit_install.json")
    receipt = read_receipt()
    if receipt is None:
        return base(True, "check", "broken", "PPSSPP is present but its EmuKit installation receipt is missing or invalid.", details={"receipt": str(RECEIPT_PATH)})
    if receipt.get("ModuleVersion") != module_version(info):
        return base(True, "check", "broken", "The PPSSPP install receipt does not match this module version.", details={"installed_module_version": receipt.get("ModuleVersion"), "module_version": module_version(info)})
    if receipt.get("EmulatorVersion") != version:
        return base(True, "check", "broken", "The installed PPSSPP build does not match the emulator version pinned by this module.", details={"installed_version": receipt.get("EmulatorVersion"), "pinned_version": version})
    if str(receipt.get("ReleaseCommit", "")).lower() != str(info["Source"]["ReleaseCommit"]).lower():
        return base(True, "check", "broken", "The PPSSPP install receipt does not match the module-pinned release commit.", details={"installed_commit": receipt.get("ReleaseCommit"), "pinned_commit": info["Source"]["ReleaseCommit"]})
    if str(receipt.get("AssetSHA256", "")).lower() != str(info["Source"]["SHA256"]).lower():
        return base(True, "check", "broken", "The PPSSPP install receipt does not match the module-pinned release archive checksum.", details={"installed_sha256": receipt.get("AssetSHA256"), "pinned_sha256": info["Source"]["SHA256"]})

    emit_progress(progress, 100, 'Check Complete', "Version 1.20.4")
    return base(True, "check", "installed", f'PPSSPP Version {version} is installed and valid.', details={"module_version": module_version(info), "version": version, "path": str(EXECUTABLE_PATH), "portable": True, "memstick": str(MEMSTICK_DIR), "source": info["Source"]["OfficialRepository"]})


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return PPSSPPInstaller.install(progress=progress)


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return PPSSPPUninstall.uninstall(progress=progress)


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return PPSSPPRepair.repair(progress=progress)


def update(progress: ProgressCallback | None = None) -> dict[str, Any]:
    current = check(progress=scaled_progress(progress, 0, 20))
    if not current.get("success") and current.get("state") == "unsupported":
        current["operation"] = "update"
        return current
    if current.get("state") == "installed":
        return base(True, "update", "already_current", f'PPSSPP Version {emulator_version()} is already current.', details=current.get("details"))
    repaired = PPSSPPRepair.repair(progress=scaled_progress(progress, 20, 98))
    repaired["operation"] = "update"
    repaired["state"] = "updated" if repaired.get("success") else "update_failed"
    if repaired.get("success"):
        repaired["message"] = f'PPSSPP Version {emulator_version()} updated successfully.'
    return repaired


def write_record(record: dict[str, Any]) -> None:
    print(json.dumps(record, ensure_ascii=False, default=str, separators=(",", ":")), flush=True)


def stream_progress(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
    write_record({"type": "progress", "percent": percent, "stage": stage, "message": message})


def run_cli() -> int:
    raw_args = sys.argv[1:]
    json_flags = [arg for arg in raw_args if arg.casefold() == "--json"]
    args = [arg for arg in raw_args if arg.casefold() != "--json"]
    operation = args[0].casefold() if len(args) == 1 else ""
    handlers = {"check": check, "install": install, "uninstall": uninstall, "repair": repair, "update": update}
    handler = handlers.get(operation)
    if len(json_flags) != 1 or handler is None:
        outcome = base(False, operation or "manager", "invalid_operation", "PPSSPPManager requires one lifecycle operation: check, install, uninstall, repair, or update.", "invalid_operation")
    else:
        try:
            outcome = handler(progress=stream_progress)
        except Exception as exc:
            outcome = base(False, operation, f"{operation}_failed", f"PPSSPPManager failed during {operation}.", "manager_exception", str(exc))
    write_record({"type": "result", "result": outcome})
    return 0 if outcome.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(run_cli())
