from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

if not getattr(sys, "frozen", False):
    module_dir = Path(__file__).resolve().parent
    if str(module_dir) not in sys.path:
        sys.path.insert(0, str(module_dir))

from _XeniaCommon import *
import XeniaInstaller
import XeniaRepair
import XeniaUninstall


def base(success: bool, operation: str, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "xenia", "operation": operation, "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def check(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 5, 'Checking Host', "Windows x86_64")
    supported, reason = is_supported_host()
    if not supported:
        return base(False, "check", "unsupported", reason or "Xenia is not supported on this host.", "unsupported_host")
    info = load_info()
    pinned_version = emulator_version(info)
    if not EMULATOR_DIR.exists():
        return base(True, "check", "missing", "Xenia is not installed.", details={"expected_path": str(EMULATOR_DIR)})
    if not EXECUTABLE_PATH.is_file():
        return base(True, "check", "broken", "The Xenia emulator directory exists but xenia_canary.exe is missing.", details={"expected_executable": str(EXECUTABLE_PATH)})
    emit_progress(progress, 50, 'Checking Emulator', "xenia_canary.exe")
    if EXECUTABLE_PATH.stat().st_size < 100000:
        return base(True, "check", "broken", "xenia_canary.exe exists but failed basic file validation.", details={"path": str(EXECUTABLE_PATH), "size": EXECUTABLE_PATH.stat().st_size})
    emit_progress(progress, 75, 'Checking Receipt', ".emukit_install.json")
    receipt = read_receipt()
    if receipt is None:
        return base(True, "check", "broken", "Xenia is present but its EmuKit installation receipt is missing or invalid.", details={"receipt": str(RECEIPT_PATH)})
    installed_version = receipt.get("Version")
    if installed_version != pinned_version:
        return base(True, "check", "broken", "The installed Xenia build does not match the version pinned by this EmuKit module.", details={"installed_version": installed_version, "pinned_version": pinned_version})
    if receipt.get("AssetSHA256") != info["Source"]["SHA256"]:
        return base(True, "check", "broken", "The installed Xenia receipt does not match the pinned archive checksum.", details={"installed_sha256": receipt.get("AssetSHA256"), "pinned_sha256": info["Source"]["SHA256"]})
    emit_progress(progress, 100, 'Check Complete', "Version aee0871")
    return base(True, "check", "installed", f'Xenia Canary Version {pinned_version} is installed and valid.', details={"version": pinned_version, "path": str(EXECUTABLE_PATH), "source": info["Source"]["OfficialRepository"]})


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return XeniaInstaller.install(progress=progress)


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return XeniaUninstall.uninstall(progress=progress)


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return XeniaRepair.repair(progress=progress)


def update(progress: ProgressCallback | None = None) -> dict[str, Any]:
    current = check(progress=scaled_progress(progress, 0, 20))
    if not current.get("success") and current.get("state") == "unsupported":
        current["operation"] = "update"
        return current
    if current.get("state") == "installed":
        return base(True, "update", "already_current", f'Xenia Canary Version {emulator_version()} is already current.', details=current.get("details"))
    repaired = XeniaRepair.repair(progress=scaled_progress(progress, 20, 98))
    repaired["operation"] = "update"
    repaired["state"] = "updated" if repaired.get("success") else "update_failed"
    if repaired.get("success"):
        repaired["message"] = f'Xenia Canary Version {emulator_version()} updated successfully.'
    return repaired


def _write_record(record: dict[str, Any]) -> None:
    print(json.dumps(record, ensure_ascii=False, default=str, separators=(",", ":")), flush=True)


def _stream_progress(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
    _write_record({"type": "progress", "percent": percent, "stage": stage, "message": message})


def cli() -> int:
    raw_args = sys.argv[1:]
    json_flags = [arg for arg in raw_args if arg.casefold() == "--json"]
    args = [arg for arg in raw_args if arg.casefold() != "--json"]
    operation = args[0].casefold() if len(args) == 1 else ""
    handlers = {
        "check": check,
        "install": install,
        "uninstall": uninstall,
        "repair": repair,
        "update": update,
    }
    handler = handlers.get(operation)
    if len(json_flags) != 1 or handler is None:
        result = base(
            False,
            operation or "manager",
            "invalid_operation",
            "XeniaManager requires one lifecycle operation: check, install, uninstall, repair, or update.",
            "invalid_operation",
        )
    else:
        try:
            result = handler(progress=_stream_progress)
        except Exception as exc:
            result = base(
                False,
                operation,
                f"{operation}_failed",
                f"XeniaManager failed during {operation}.",
                "manager_exception",
                str(exc),
            )
    _write_record({"type": "result", "result": result})
    return 0 if result.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(cli())
