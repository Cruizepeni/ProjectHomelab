from __future__ import annotations

import shutil
from _XeniaCommon import EMULATOR_DIR, ProgressCallback, emit_progress


def uninstall(progress: ProgressCallback | None = None) -> dict:
    emit_progress(progress, 3, 'Preparing Uninstall', "Emulators/Xenia")
    try:
        if not EMULATOR_DIR.exists():
            emit_progress(progress, 100, 'Uninstall Complete', "Emulators/Xenia")
            return {"success": True, "module": "xenia", "operation": "uninstall", "state": "uninstalled", "message": "Xenia is already uninstalled.", "details": None}
        emit_progress(progress, 25, 'Removing Emulator', "Emulators/Xenia")
        shutil.rmtree(EMULATOR_DIR)
        if EMULATOR_DIR.exists():
            return {"success": False, "module": "xenia", "operation": "uninstall", "state": "uninstall_failed", "error": "emulator_directory_remains", "message": "Xenia uninstall completed but its emulator directory still exists.", "details": {"path": str(EMULATOR_DIR)}}
        emit_progress(progress, 95, 'Verifying Uninstall', "Emulators/Xenia")
        emit_progress(progress, 100, 'Uninstall Complete', "Emulators/Xenia")
        return {"success": True, "module": "xenia", "operation": "uninstall", "state": "uninstalled", "message": "Xenia Canary uninstalled successfully.", "details": None}
    except PermissionError as exc:
        return {"success": False, "module": "xenia", "operation": "uninstall", "state": "uninstall_failed", "error": "permission_denied", "message": "Xenia could not be uninstalled because one or more files are in use or EmuKit does not have permission to remove them.", "details": str(exc)}
    except Exception as exc:
        return {"success": False, "module": "xenia", "operation": "uninstall", "state": "uninstall_failed", "error": "uninstall_exception", "message": "Xenia could not be uninstalled.", "details": str(exc)}
