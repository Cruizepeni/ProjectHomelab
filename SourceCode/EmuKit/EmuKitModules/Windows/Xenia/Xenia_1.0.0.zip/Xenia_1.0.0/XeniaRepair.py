from __future__ import annotations

from _XeniaCommon import ProgressCallback, scaled_progress
import XeniaInstaller
import XeniaUninstall


def repair(progress: ProgressCallback | None = None) -> dict:
    emit_progress(progress, 3, 'Preparing Repair', "Emulators/Xenia")
    removed = XeniaUninstall.uninstall(progress=scaled_progress(progress, 0, 15))
    if not removed.get("success"):
        return {"success": False, "module": "xenia", "operation": "repair", "state": "repair_failed", "error": removed.get("error", "uninstall_failed"), "message": "Xenia repair could not continue because the existing emulator directory could not be removed.", "details": removed}
    installed = XeniaInstaller.install(progress=scaled_progress(progress, 15, 98))
    if not installed.get("success"):
        return {"success": False, "module": "xenia", "operation": "repair", "state": "repair_failed", "error": installed.get("error", "install_failed"), "message": "Xenia was removed successfully, but the clean reinstall failed. " + str(installed.get("message", "")), "details": installed}
    emit_progress(progress, 100, 'Repair Complete', "Version aee0871")
    return {"success": True, "module": "xenia", "operation": "repair", "state": "repaired", "message": 'Xenia Canary repaired successfully.', "details": installed.get("details")}
