from __future__ import annotations

import shutil
from typing import Any

from _Vita3KCommon import EMULATOR_DIR, ProgressCallback, emit_progress


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, 'Preparing Uninstall', "Emulators/Vita3K")
    emit_progress(progress, 10, 'Removing Emulator', "Emulators/Vita3K")
    try:
        if not EMULATOR_DIR.exists():
            emit_progress(progress, 100, 'Uninstall Complete', "Emulators/Vita3K")
            return {
                "success": True,
                "module": "vita3k",
                "operation": "uninstall",
                "state": "uninstalled",
                "message": "Vita3K is already uninstalled.",
                "details": None,
            }
        shutil.rmtree(EMULATOR_DIR)
        emit_progress(progress, 90, 'Verifying Uninstall', "Emulators/Vita3K")
        if EMULATOR_DIR.exists():
            return {
                "success": False,
                "module": "vita3k",
                "operation": "uninstall",
                "state": "uninstall_failed",
                "error": "emulator_directory_remains",
                "message": "Vita3K uninstall completed but its managed emulator directory still exists.",
                "details": {"path": str(EMULATOR_DIR)},
            }
        emit_progress(progress, 100, 'Uninstall Complete', "Emulators/Vita3K")
        return {
            "success": True,
            "module": "vita3k",
            "operation": "uninstall",
            "state": "uninstalled",
            "message": "Vita3K uninstalled successfully.",
            "details": None,
        }
    except PermissionError as exc:
        return {
            "success": False,
            "module": "vita3k",
            "operation": "uninstall",
            "state": "uninstall_failed",
            "error": "permission_denied",
            "message": "Vita3K could not be uninstalled because one or more files are in use or EmuKit does not have permission to remove them.",
            "details": str(exc),
        }
    except Exception as exc:
        return {
            "success": False,
            "module": "vita3k",
            "operation": "uninstall",
            "state": "uninstall_failed",
            "error": "uninstall_exception",
            "message": "Vita3K could not be uninstalled.",
            "details": str(exc),
        }
