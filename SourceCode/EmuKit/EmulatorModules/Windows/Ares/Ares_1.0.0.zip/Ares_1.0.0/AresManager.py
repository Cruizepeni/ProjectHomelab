from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

MODULE_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
if str(MODULE_DIR) not in sys.path:
    sys.path.insert(0, str(MODULE_DIR))

from _AresCommon import EMULATOR_DIR, EXECUTABLE_PATH, RECEIPT_PATH, SETTINGS_PATH, ProgressCallback, emit_progress, emulator_version, hash_file, is_supported_host, load_info, module_version, read_receipt, resource_health, scaled_progress, settings_health
import AresInstaller
import AresRepair
import AresUninstall


def base(success: bool, operation: str, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "ares", "operation": operation, "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def check(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 10, "Checking host")
    supported, reason = is_supported_host()
    if not supported:
        return base(False, "check", "unsupported", reason or "Ares is not supported on this host.", "unsupported_host")

    info = load_info()
    version = emulator_version(info)
    if not EMULATOR_DIR.exists():
        return base(True, "check", "missing", "Ares is not installed.", details={"expected_path": str(EMULATOR_DIR)})

    emit_progress(progress, 28, "Checking executable")
    if not EXECUTABLE_PATH.is_file():
        return base(True, "check", "broken", "The Ares emulator directory exists but ares.exe is missing.", details={"expected_executable": str(EXECUTABLE_PATH)})

    emit_progress(progress, 42, "Checking settings")
    if not SETTINGS_PATH.is_file() or not settings_health(info):
        return base(True, "check", "broken", "Ares is installed but its EmuKit-managed settings are missing or invalid.", details={"settings": str(SETTINGS_PATH)})

    emit_progress(progress, 54, "Checking receipt")
    receipt = read_receipt()
    if receipt is None:
        return base(True, "check", "broken", "Ares is present but its EmuKit installation receipt is missing or invalid.", details={"receipt": str(RECEIPT_PATH)})
    if receipt.get("ModuleVersion") != module_version(info):
        return base(True, "check", "broken", "The Ares install receipt does not match this module version.", details={"installed_module_version": receipt.get("ModuleVersion"), "module_version": module_version(info)})
    if receipt.get("EmulatorVersion") != version:
        return base(True, "check", "broken", "The installed Ares build does not match the emulator version pinned by this module.", details={"installed_version": receipt.get("EmulatorVersion"), "pinned_version": version})
    if str(receipt.get("ReleaseCommit", "")).lower() != str(info["Source"]["ReleaseCommit"]).lower():
        return base(True, "check", "broken", "The Ares install receipt does not match the module-pinned upstream release commit.", details={"installed_commit": receipt.get("ReleaseCommit"), "pinned_commit": info["Source"]["ReleaseCommit"]})
    if str(receipt.get("ArchiveSHA256", "")).lower() != str(info["Source"]["SHA256"]).lower():
        return base(True, "check", "broken", "The Ares install receipt does not match the module-pinned archive checksum.", details={"installed_sha256": receipt.get("ArchiveSHA256"), "pinned_sha256": info["Source"]["SHA256"]})

    emit_progress(progress, 68, "Checking executable integrity")
    expected_executable = str(receipt.get("ExecutableSHA256", "")).lower()
    actual_executable = hash_file(EXECUTABLE_PATH).lower()
    if not expected_executable or actual_executable != expected_executable:
        return base(True, "check", "broken", "ares.exe no longer matches the EmuKit-managed installation.", details={"expected_sha256": expected_executable or None, "actual_sha256": actual_executable})

    emit_progress(progress, 82, "Checking firmware")
    resources = resource_health(info)
    if not resources["valid"]:
        return base(True, "check", "broken", "One or more EmuKit-managed Ares firmware resources are missing or invalid.", details=resources)

    emit_progress(progress, 95, "Ready")
    return base(True, "check", "installed", f'Ares "{version}" is installed and valid.', details={"module_version": module_version(info), "version": version, "path": str(EXECUTABLE_PATH), "settings": str(SETTINGS_PATH), "resource_count": len(resources["valid_resources"]), "systems": sorted(info["Systems"].keys()), "source": info["Source"]["OfficialRepository"]})


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return AresInstaller.install(progress=progress)


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return AresUninstall.uninstall(progress=progress)


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return AresRepair.repair(progress=progress)


def update(progress: ProgressCallback | None = None) -> dict[str, Any]:
    current = check(progress=scaled_progress(progress, 0, 20))
    if not current.get("success") and current.get("state") == "unsupported":
        current["operation"] = "update"
        return current
    version = emulator_version()
    if current.get("state") == "installed":
        return base(True, "update", "already_current", f'Ares "{version}" is already the module-pinned stable version.', details=current.get("details"))
    repaired = AresRepair.repair(progress=scaled_progress(progress, 20, 98))
    repaired["operation"] = "update"
    repaired["state"] = "updated" if repaired.get("success") else "update_failed"
    if repaired.get("success"):
        repaired["message"] = f'Ares was updated to pinned version "{version}".'
    return repaired


def write_record(record: dict[str, Any]) -> None:
    print(json.dumps(record, ensure_ascii=False, default=str, separators=(",", ":")), flush=True)


def stream_progress(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
    write_record({"type": "progress", "percent": percent, "stage": stage, "message": message})


def run_cli() -> int:
    raw_args = sys.argv[1:]
    json_flags = [arg for arg in raw_args if arg.casefold() == "--json"]
    args = [arg for arg in raw_args if arg.casefold() != "--json"]
    operation = args[0].casefold() if len(args) == 1 else ""
    handlers = {"check": check, "install": install, "uninstall": uninstall, "repair": repair, "update": update}
    handler = handlers.get(operation)
    if len(json_flags) != 1 or handler is None:
        outcome = base(False, operation or "manager", "invalid_operation", "AresManager requires one lifecycle operation: check, install, uninstall, repair, or update.", "invalid_operation")
    else:
        try:
            outcome = handler(progress=stream_progress)
        except Exception as exc:
            outcome = base(False, operation, f"{operation}_failed", f"AresManager failed during {operation}.", "manager_exception", str(exc))
    write_record({"type": "result", "result": outcome})
    return 0 if outcome.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(run_cli())
