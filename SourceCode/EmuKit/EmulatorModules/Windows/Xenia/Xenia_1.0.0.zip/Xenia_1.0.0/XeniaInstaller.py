from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from _XeniaCommon import *


def result(success: bool, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "xenia", "operation": "install", "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download(url: str, destination: Path, expected_sha256: str, progress: ProgressCallback | None = None):
    request = urllib.request.Request(url, headers={"User-Agent": "EmuKit-Xenia/1.0"})
    try:
        with urllib.request.urlopen(request, timeout=60) as response, destination.open("wb") as output:
            raw_length = response.headers.get("Content-Length")
            total = int(raw_length) if raw_length and raw_length.isdigit() else None
            downloaded = 0
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)
                downloaded += len(chunk)
                percent = min(100, int(downloaded * 100 / total)) if total else None
                emit_progress(progress, percent, "Downloading Emulator", destination.name)
        emit_progress(progress, 100, "Downloading Emulator", destination.name)
        emit_progress(progress, 100, "Validating Emulator", destination.name)
        if not destination.is_file() or destination.stat().st_size < 100000:
            return result(False, "download_failed", "The downloaded Xenia archive is missing or unexpectedly small.", "download_validation_failed", {"path": str(destination), "size": destination.stat().st_size if destination.exists() else 0})
        actual_sha256 = sha256_file(destination)
        if actual_sha256 != expected_sha256:
            return result(False, "download_failed", "The downloaded Xenia archive failed SHA-256 verification.", "checksum_mismatch", {"expected": expected_sha256, "actual": actual_sha256})
        return None
    except urllib.error.HTTPError as exc:
        return result(False, "download_failed", "The official Xenia release asset could not be downloaded.", "download_http_error", {"http_status": exc.code, "url": url})
    except Exception as exc:
        return result(False, "download_failed", "The official Xenia release asset could not be downloaded.", "download_failed", str(exc))


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, "Checking Host")
    supported, reason = is_supported_host()
    if not supported:
        return result(False, "unsupported", reason or "Unsupported host.", "unsupported_host")
    seven_zip = seven_zip_executable()
    if seven_zip is None:
        return result(False, "install_failed", "EmuKit Core 7-Zip dependency was not found.", "core_dependency_missing")
    info = load_info()
    source = info["Source"]
    version = emulator_version(info)
    if EMULATOR_DIR.exists():
        return result(False, "install_failed", "The Xenia emulator directory already exists. Use repair for a clean reinstall.", "emulator_directory_already_exists", {"path": str(EMULATOR_DIR)})
    EMULATOR_DIR.mkdir(parents=True)
    temp_dir = EMULATOR_DIR / ".install"
    temp_dir.mkdir()
    archive_path = temp_dir / source["Asset"]
    extract_dir = temp_dir / "extracted"
    extract_dir.mkdir()
    try:
        download_error = download(source["DownloadURL"], archive_path, source["SHA256"], scaled_progress(progress, 10, 68))
        if download_error is not None:
            return download_error
        emit_progress(progress, 72, "Extracting Emulator", archive_path.name)
        completed = subprocess.run([str(seven_zip), "x", str(archive_path), f"-o{extract_dir}", "-y"], capture_output=True, text=True, check=False)
        if completed.returncode != 0:
            return result(False, "extract_failed", "The Xenia archive downloaded successfully but could not be extracted.", "archive_extract_failed", {"exit_code": completed.returncode, "stdout": completed.stdout[-4000:], "stderr": completed.stderr[-4000:]})
        extracted_executable = extract_dir / "xenia_canary.exe"
        if not extracted_executable.is_file() or extracted_executable.stat().st_size < 100000:
            return result(False, "install_failed", "The Xenia archive was extracted, but xenia_canary.exe was not found or failed basic validation.", "executable_validation_failed", {"expected": str(extracted_executable)})
        emit_progress(progress, 82, "Installing Emulator", extracted_executable.name)
        for item in extract_dir.iterdir():
            destination = EMULATOR_DIR / item.name
            if destination.exists():
                if destination.is_dir():
                    shutil.rmtree(destination)
                else:
                    destination.unlink()
            if item.is_dir():
                shutil.copytree(item, destination)
            else:
                shutil.copy2(item, destination)
        if not EXECUTABLE_PATH.is_file():
            return result(False, "install_failed", "Xenia extraction completed but the managed executable is missing.", "post_install_validation_failed", {"expected": str(EXECUTABLE_PATH)})
        emit_progress(progress, 94, "Writing Receipt", RECEIPT_PATH.name)
        receipt = {"EmuKitModule": "xenia", "Name": info["Name"], "Version": version, "ReleaseTag": source["ReleaseTag"], "Asset": source["Asset"], "AssetSHA256": source["SHA256"], "SourceRepository": source["Repository"], "InstalledAtUTC": datetime.now(timezone.utc).isoformat()}
        RECEIPT_PATH.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        emit_progress(progress, 98, "Verifying Installation", EXECUTABLE_PATH.name)
        return result(True, "installed", f'Xenia Canary version "{version}" installed successfully.', details={"version": version, "path": str(EXECUTABLE_PATH), "source": source["OfficialRepository"]})
    except PermissionError as exc:
        return result(False, "install_failed", "Xenia installation could not write one or more required files.", "permission_denied", str(exc))
    except Exception as exc:
        return result(False, "install_failed", "Xenia installation failed unexpectedly.", "install_exception", str(exc))
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        if not EXECUTABLE_PATH.exists():
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
