from __future__ import annotations

import shutil
from typing import Any

from _RPCS3Common import EMULATOR_DIR, ProgressCallback, emit_progress


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 10, "Removing")
    try:
        if not EMULATOR_DIR.exists():
            return {"success": True, "module": "rpcs3", "operation": "uninstall", "state": "uninstalled", "message": "RPCS3 is already uninstalled.", "details": None}
        shutil.rmtree(EMULATOR_DIR)
        emit_progress(progress, 90, "Verifying")
        if EMULATOR_DIR.exists():
            return {"success": False, "module": "rpcs3", "operation": "uninstall", "state": "uninstall_failed", "error": "emulator_directory_remains", "message": "RPCS3 uninstall completed but its managed emulator directory still exists.", "details": {"path": str(EMULATOR_DIR)}}
        return {"success": True, "module": "rpcs3", "operation": "uninstall", "state": "uninstalled", "message": "RPCS3 was uninstalled successfully.", "details": None}
    except PermissionError as exc:
        return {"success": False, "module": "rpcs3", "operation": "uninstall", "state": "uninstall_failed", "error": "permission_denied", "message": "RPCS3 could not be uninstalled because one or more files are in use or EmuKit does not have permission to remove them.", "details": str(exc)}
    except Exception as exc:
        return {"success": False, "module": "rpcs3", "operation": "uninstall", "state": "uninstall_failed", "error": "uninstall_exception", "message": "RPCS3 could not be uninstalled.", "details": str(exc)}
