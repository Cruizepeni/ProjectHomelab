from __future__ import annotations

from typing import Any

from _RPCS3Common import ProgressCallback, scaled_progress
import RPCS3Installer
import RPCS3Uninstall


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    removed = RPCS3Uninstall.uninstall(progress=scaled_progress(progress, 0, 15))
    if not removed.get("success"):
        return {"success": False, "module": "rpcs3", "operation": "repair", "state": "repair_failed", "error": removed.get("error", "uninstall_failed"), "message": "RPCS3 repair could not continue because the existing emulator installation could not be removed.", "details": removed}

    installed = RPCS3Installer.install(progress=scaled_progress(progress, 15, 98))
    if not installed.get("success"):
        return {"success": False, "module": "rpcs3", "operation": "repair", "state": "repair_failed", "error": installed.get("error", "install_failed"), "message": ("RPCS3 was removed successfully, but the clean reinstall failed. " + str(installed.get("message", ""))).strip(), "details": installed}

    return {"success": True, "module": "rpcs3", "operation": "repair", "state": "repaired", "message": "RPCS3 was repaired successfully using a clean emulator and firmware reinstall.", "details": installed.get("details")}
