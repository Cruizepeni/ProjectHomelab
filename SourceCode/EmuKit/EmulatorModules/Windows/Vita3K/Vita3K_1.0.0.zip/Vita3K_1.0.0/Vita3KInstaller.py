from __future__ import annotations

import json
import re
import shutil
import subprocess
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from _Vita3KCommon import CONFIG_PATH, EMULATOR_DIR, EXECUTABLE_PATH, PORTABLE_DIR, RECEIPT_PATH, ProgressCallback, emit_progress, emulator_version, firmware_health, hash_file, is_supported_host, load_info, module_version, run_external_process, scaled_progress, seven_zip_executable


def result(success: bool, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "vita3k", "operation": "install", "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def download(url: str, destination: Path, minimum_size: int, label: str, progress: ProgressCallback | None = None) -> dict[str, Any] | None:
    request = urllib.request.Request(url, headers={"User-Agent": "EmuKit-Vita3K/1.0.0", "Accept": "*/*"})
    try:
        with urllib.request.urlopen(request, timeout=300) as response:
            total_raw = response.headers.get("Content-Length")
            total = int(total_raw) if total_raw and total_raw.isdigit() else None
            downloaded = 0
            with destination.open("wb") as output:
                while True:
                    chunk = response.read(1024 * 1024)
                    if not chunk:
                        break
                    output.write(chunk)
                    downloaded += len(chunk)
                    percent = round(downloaded * 100 / total) if total else None
                    emit_progress(progress, percent, "Downloading System Data" if label == "PS Vita system data" else ("Downloading Firmware" if label == "PS Vita firmware" else "Downloading Emulator"), destination.name)
        if not destination.is_file():
            return result(False, "download_failed", f"The {label} download did not create a file.", "download_missing", {"url": url})
        size = destination.stat().st_size
        if size < minimum_size:
            return result(False, "download_failed", f"The downloaded {label} file is unexpectedly small.", "download_validation_failed", {"url": url, "size": size, "minimum_size": minimum_size})
        return None
    except urllib.error.HTTPError as exc:
        return result(False, "download_failed", f"The official {label} file could not be downloaded.", "download_http_error", {"http_status": exc.code, "url": url})
    except Exception as exc:
        return result(False, "download_failed", f"The official {label} file could not be downloaded.", "download_failed", str(exc))


def download_firmware(specification: dict[str, Any], destination: Path, label: str, progress: ProgressCallback | None = None) -> dict[str, Any] | None:
    attempts: list[dict[str, Any]] = []
    for key in ("PrimaryURL", "FallbackURL"):
        url = specification.get(key)
        if not isinstance(url, str) or not url:
            continue
        if destination.exists():
            destination.unlink()
        error = download(url, destination, 1000000, label, progress)
        if error is None:
            return None
        attempts.append({"url": url, "error": error.get("error"), "details": error.get("details")})
    return result(False, "download_failed", f"The official Sony {label} could not be downloaded.", "sony_firmware_download_failed", {"attempts": attempts})


def validate_archive(path: Path, info: dict[str, Any]) -> dict[str, Any] | None:
    expected = str(info["Source"]["SHA256"]).lower()
    actual = hash_file(path).lower()
    if actual != expected:
        return result(False, "invalid_download", "The downloaded Vita3K archive failed SHA-256 validation.", "archive_hash_mismatch", {"expected_sha256": expected, "actual_sha256": actual, "path": str(path)})
    return None


def validate_firmware(path: Path, specification: dict[str, Any], label: str) -> dict[str, Any] | None:
    expected = str(specification["MD5"]).lower()
    actual = hash_file(path, "md5").lower()
    if actual != expected:
        return result(False, "invalid_firmware", f"The downloaded {label} failed MD5 validation.", "firmware_md5_mismatch", {"expected_md5": expected, "actual_md5": actual, "path": str(path)})
    return None


def configure_portable() -> None:
    text = CONFIG_PATH.read_text(encoding="utf-8")
    replacements = {
        "show-welcome": "false",
        "check-for-updates": "false",
    }
    for key, value in replacements.items():
        pattern = rf"(?m)^(\s*{re.escape(key)}\s*:\s*)(?:true|false)(\s*)$"
        updated, count = re.subn(pattern, rf"\g<1>{value}\g<2>", text, count=1)
        if count:
            text = updated
    CONFIG_PATH.write_text(text, encoding="utf-8")


def bootstrap_portable(temp_dir: Path) -> dict[str, Any] | None:
    if CONFIG_PATH.is_file():
        return None
    stdout_path = temp_dir / "vita3k-bootstrap-stdout.log"
    stderr_path = temp_dir / "vita3k-bootstrap-stderr.log"
    try:
        with stdout_path.open("wb") as stdout_handle, stderr_path.open("wb") as stderr_handle:
            completed = run_external_process(
                [str(EXECUTABLE_PATH), "--version"],
                isolate_console=True,
                cwd=str(EMULATOR_DIR),
                stdin=subprocess.DEVNULL,
                stdout=stdout_handle,
                stderr=stderr_handle,
                check=False,
                timeout=60,
            )
    except subprocess.TimeoutExpired:
        return result(False, "portable_bootstrap_failed", "Vita3K did not finish its portable first-run bootstrap within the allowed time.", "portable_bootstrap_timeout", {"timeout_seconds": 60})
    except Exception as exc:
        return result(False, "portable_bootstrap_failed", "Vita3K could not be started for portable first-run bootstrap.", "portable_bootstrap_exception", str(exc))
    if completed.returncode != 0 or not CONFIG_PATH.is_file():
        return result(False, "portable_bootstrap_failed", "Vita3K's first-run bootstrap did not create portable/config.yml.", "portable_config_missing", {"exit_code": completed.returncode, "expected_config": str(CONFIG_PATH)})
    configure_portable()
    return None


def install_firmware(path: Path, info: dict[str, Any], label: str, temp_dir: Path) -> dict[str, Any] | None:
    arguments = [str(path) if value == "{firmware}" else str(value) for value in info["Firmware"]["InstallArguments"]]
    safe_label = re.sub(r"[^A-Za-z0-9]+", "-", label).strip("-").lower()
    stdout_path = temp_dir / f"vita3k-{safe_label}-stdout.log"
    stderr_path = temp_dir / f"vita3k-{safe_label}-stderr.log"
    try:
        with stdout_path.open("wb") as stdout_handle, stderr_path.open("wb") as stderr_handle:
            completed = run_external_process(
                [str(EXECUTABLE_PATH), *arguments],
                isolate_console=True,
                cwd=str(EMULATOR_DIR),
                stdin=subprocess.DEVNULL,
                stdout=stdout_handle,
                stderr=stderr_handle,
                check=False,
                timeout=900,
            )
    except subprocess.TimeoutExpired:
        return result(False, "firmware_install_failed", f"Vita3K did not finish installing the {label} within the allowed time.", "firmware_install_timeout", {"timeout_seconds": 900})
    except Exception as exc:
        return result(False, "firmware_install_failed", f"Vita3K could not be started to install the {label}.", "firmware_install_exception", str(exc))
    if completed.returncode != 0:
        return result(False, "firmware_install_failed", f"Vita3K returned an error while installing the {label}.", "firmware_installer_exit_failure", {"exit_code": completed.returncode})
    return None


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, "Checking Host")
    supported, reason = is_supported_host()
    if not supported:
        return result(False, "unsupported", reason or "Unsupported host.", "unsupported_host")

    seven_zip = seven_zip_executable()
    if seven_zip is None:
        return result(False, "dependency_missing", "Vita3K requires the EmuKit 7-Zip core dependency.", "seven_zip_missing")

    info = load_info()
    version = emulator_version(info)
    if EMULATOR_DIR.exists():
        return result(False, "install_failed", "The Vita3K emulator directory already exists. Use repair for a clean reinstall.", "emulator_directory_exists", {"path": str(EMULATOR_DIR)})

    emit_progress(progress, 8, "Preparing Install", info["Source"]["Asset"])
    EMULATOR_DIR.mkdir(parents=True, exist_ok=False)
    temp_dir = EMULATOR_DIR / ".install"
    extract_dir = temp_dir / "extracted"
    temp_dir.mkdir(parents=True, exist_ok=True)
    extract_dir.mkdir(parents=True, exist_ok=True)
    archive_path = temp_dir / info["Source"]["Asset"]
    main_path = temp_dir / info["Firmware"]["Main"]["FileName"]
    font_path = temp_dir / info["Firmware"]["FontPackage"]["FileName"]
    complete = False

    try:
        error = download(info["Source"]["DownloadURL"], archive_path, 10000000, "Vita3K", scaled_progress(progress, 10, 36))
        if error is not None:
            return error

        emit_progress(progress, 38, "Validating Emulator", archive_path.name)
        error = validate_archive(archive_path, info)
        if error is not None:
            return error

        emit_progress(progress, 42, "Extracting Emulator", archive_path.name)
        completed = run_external_process(
            [str(seven_zip), "x", str(archive_path), f"-o{extract_dir}", "-y"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
        )
        if completed.returncode != 0:
            return result(False, "extract_failed", "The Vita3K archive downloaded correctly but 7-Zip could not extract it.", "archive_extract_failed", {"exit_code": completed.returncode, "stdout": completed.stdout[-4000:], "stderr": completed.stderr[-4000:]})

        extracted_executable = next(extract_dir.rglob("Vita3K.exe"), None)
        if extracted_executable is None or not extracted_executable.is_file():
            return result(False, "install_failed", "The Vita3K archive was extracted but Vita3K.exe was not found.", "executable_validation_failed")

        emit_progress(progress, 50, "Installing Emulator", extracted_executable.name)
        extracted_root = extracted_executable.parent
        for item in extracted_root.iterdir():
            destination = EMULATOR_DIR / item.name
            if destination.exists():
                if destination.is_dir():
                    shutil.rmtree(destination)
                else:
                    destination.unlink()
            if item.is_dir():
                shutil.copytree(item, destination)
            else:
                shutil.copy2(item, destination)

        if not EXECUTABLE_PATH.is_file():
            return result(False, "install_failed", "Vita3K extraction completed but Vita3K.exe is missing.", "post_install_validation_failed", {"expected": str(EXECUTABLE_PATH)})

        emit_progress(progress, 56, "Configuring Emulator", "portable/config.yml")
        PORTABLE_DIR.mkdir(parents=True, exist_ok=True)
        error = bootstrap_portable(temp_dir)
        if error is not None:
            return error

        main_spec = info["Firmware"]["Main"]
        error = download_firmware(main_spec, main_path, "PS Vita firmware", scaled_progress(progress, 58, 70))
        if error is not None:
            return error

        emit_progress(progress, 72, "Validating Firmware", main_path.name)
        error = validate_firmware(main_path, main_spec, "PS Vita firmware")
        if error is not None:
            return error

        emit_progress(progress, 76, "Installing Firmware", main_path.name)
        error = install_firmware(main_path, info, "PS Vita firmware", temp_dir)
        if error is not None:
            return error

        missing_main = [str(EMULATOR_DIR / relative) for relative in main_spec["Sentinels"] if not (EMULATOR_DIR / relative).is_file()]
        if missing_main:
            return result(False, "firmware_install_failed", "Vita3K finished the PS Vita firmware command, but required firmware files are missing.", "main_firmware_post_validation_failed", {"missing": missing_main})

        font_spec = info["Firmware"]["FontPackage"]
        error = download_firmware(font_spec, font_path, "PS Vita system data", scaled_progress(progress, 80, 88))
        if error is not None:
            return error

        emit_progress(progress, 89, "Validating System Data", font_path.name)
        error = validate_firmware(font_path, font_spec, "PS Vita system-data package")
        if error is not None:
            return error

        emit_progress(progress, 91, "Installing System Data", font_path.name)
        error = install_firmware(font_path, info, "PS Vita system-data package", temp_dir)
        if error is not None:
            return error

        emit_progress(progress, 94, "Verifying Installation", EXECUTABLE_PATH.name)
        health = firmware_health(info)
        if not health.get("valid"):
            return result(False, "firmware_install_failed", "Vita3K firmware provisioning did not pass final validation.", "firmware_final_validation_failed", health)

        executable_sha256 = hash_file(EXECUTABLE_PATH)
        receipt = {
            "EmuKitModule": "vita3k",
            "ModuleVersion": module_version(info),
            "Name": info["Name"],
            "EmulatorVersion": version,
            "BuildNumber": info["Source"]["BuildNumber"],
            "BuildCommit": info["Source"]["BuildCommit"],
            "Asset": info["Source"]["Asset"],
            "ArchiveSHA256": info["Source"]["SHA256"],
            "ExecutableSHA256": executable_sha256,
            "SourceRepository": info["Source"]["SourceRepository"],
            "BinaryRepository": info["Source"]["Repository"],
            "PortableMode": {
                "Enabled": True,
                "Root": str(PORTABLE_DIR),
                "Config": str(CONFIG_PATH)
            },
            "Firmware": {
                "Main": {
                    "Version": main_spec["Version"],
                    "FileName": main_spec["FileName"],
                    "MD5": main_spec["MD5"],
                    "Provider": main_spec["Provider"]
                },
                "FontPackage": {
                    "FileName": font_spec["FileName"],
                    "MD5": font_spec["MD5"],
                    "Provider": font_spec["Provider"]
                }
            },
            "InstalledAtUTC": datetime.now(timezone.utc).isoformat()
        }

        emit_progress(progress, 97, "Writing Receipt")
        RECEIPT_PATH.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        complete = True
        return result(True, "installed", f'Vita3K version "{version}" installed successfully.', details={"module_version": module_version(info), "version": version, "build_number": info["Source"]["BuildNumber"], "build_commit": info["Source"]["ShortCommit"], "path": str(EXECUTABLE_PATH), "portable": True, "firmware_version": main_spec["Version"], "font_package_installed": True, "auto_update_disabled": True, "source": info["Source"]["OfficialRepository"]})
    except PermissionError as exc:
        return result(False, "install_failed", "Vita3K installation could not write one or more required files.", "permission_denied", str(exc))
    except Exception as exc:
        return result(False, "install_failed", "Vita3K installation failed unexpectedly.", "install_exception", str(exc))
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        if not complete:
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
