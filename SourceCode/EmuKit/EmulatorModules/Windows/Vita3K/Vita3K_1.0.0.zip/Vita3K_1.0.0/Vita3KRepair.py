from __future__ import annotations

from typing import Any

from _Vita3KCommon import ProgressCallback, scaled_progress
import Vita3KInstaller
import Vita3KUninstall


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    uninstall_result = Vita3KUninstall.uninstall(progress=scaled_progress(progress, 0, 15))
    if not uninstall_result.get("success"):
        return {
            "success": False,
            "module": "vita3k",
            "operation": "repair",
            "state": "repair_failed",
            "error": uninstall_result.get("error", "uninstall_failed"),
            "message": "Vita3K repair could not continue because the existing emulator could not be removed.",
            "details": uninstall_result,
        }
    install_result = Vita3KInstaller.install(progress=scaled_progress(progress, 15, 98))
    if not install_result.get("success"):
        return {
            "success": False,
            "module": "vita3k",
            "operation": "repair",
            "state": "repair_failed",
            "error": install_result.get("error", "install_failed"),
            "message": ("Vita3K was removed successfully, but the clean reinstall failed. " + str(install_result.get("message", ""))).strip(),
            "details": install_result,
        }
    return {
        "success": True,
        "module": "vita3k",
        "operation": "repair",
        "state": "repaired",
        "message": "Vita3K was repaired successfully using a clean emulator and firmware reinstall.",
        "details": install_result.get("details"),
    }
