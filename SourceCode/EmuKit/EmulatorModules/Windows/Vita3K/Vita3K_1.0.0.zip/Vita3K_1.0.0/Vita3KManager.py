from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

MODULE_DIR = (
    Path(sys.executable).resolve().parent
    if getattr(sys, "frozen", False)
    else Path(__file__).resolve().parent
)
if str(MODULE_DIR) not in sys.path:
    sys.path.insert(0, str(MODULE_DIR))

from _Vita3KCommon import CONFIG_PATH, EMULATOR_DIR, EXECUTABLE_PATH, PORTABLE_DIR, RECEIPT_PATH, ProgressCallback, emit_progress, emulator_version, firmware_health, hash_file, is_supported_host, load_info, module_version, read_receipt, scaled_progress
import Vita3KInstaller
import Vita3KRepair
import Vita3KUninstall


def base(success: bool, operation: str, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "vita3k", "operation": operation, "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def check(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 10, "Checking host")
    supported, reason = is_supported_host()
    if not supported:
        return base(False, "check", "unsupported", reason or "Vita3K is not supported on this host.", "unsupported_host")

    info = load_info()
    version = emulator_version(info)
    if not EMULATOR_DIR.exists():
        return base(True, "check", "missing", "Vita3K is not installed.", details={"expected_path": str(EMULATOR_DIR)})

    emit_progress(progress, 28, "Checking executable")
    if not EXECUTABLE_PATH.is_file():
        return base(True, "check", "broken", "The Vita3K emulator directory exists but Vita3K.exe is missing.", details={"expected_executable": str(EXECUTABLE_PATH)})

    emit_progress(progress, 40, "Checking portable mode")
    if not PORTABLE_DIR.is_dir() or not CONFIG_PATH.is_file():
        return base(True, "check", "broken", "Vita3K is installed but its EmuKit portable environment is incomplete.", details={"portable_root": str(PORTABLE_DIR), "config": str(CONFIG_PATH)})

    emit_progress(progress, 52, "Checking receipt")
    receipt = read_receipt()
    if receipt is None:
        return base(True, "check", "broken", "Vita3K is present but its EmuKit installation receipt is missing or invalid.", details={"receipt": str(RECEIPT_PATH)})
    if receipt.get("ModuleVersion") != module_version(info):
        return base(True, "check", "broken", "The Vita3K install receipt does not match this module version.", details={"installed_module_version": receipt.get("ModuleVersion"), "module_version": module_version(info)})
    if receipt.get("EmulatorVersion") != version:
        return base(True, "check", "broken", "The installed Vita3K build does not match the emulator version pinned by this module.", details={"installed_version": receipt.get("EmulatorVersion"), "pinned_version": version})
    if str(receipt.get("BuildCommit", "")).lower() != str(info["Source"]["BuildCommit"]).lower():
        return base(True, "check", "broken", "The Vita3K install receipt does not match the module-pinned upstream build commit.", details={"installed_commit": receipt.get("BuildCommit"), "pinned_commit": info["Source"]["BuildCommit"]})
    if str(receipt.get("ArchiveSHA256", "")).lower() != str(info["Source"]["SHA256"]).lower():
        return base(True, "check", "broken", "The Vita3K install receipt does not match the module-pinned archive checksum.", details={"installed_sha256": receipt.get("ArchiveSHA256"), "pinned_sha256": info["Source"]["SHA256"]})

    emit_progress(progress, 68, "Checking executable integrity")
    expected_executable_sha256 = str(receipt.get("ExecutableSHA256", "")).lower()
    if not expected_executable_sha256:
        return base(True, "check", "broken", "Vita3K's EmuKit receipt does not contain its installed executable checksum.", details={"receipt": str(RECEIPT_PATH)})
    actual_executable_sha256 = hash_file(EXECUTABLE_PATH).lower()
    if actual_executable_sha256 != expected_executable_sha256:
        return base(True, "check", "broken", "Vita3K.exe no longer matches the pinned EmuKit installation.", details={"expected_sha256": expected_executable_sha256, "actual_sha256": actual_executable_sha256})

    emit_progress(progress, 84, "Checking firmware")
    health = firmware_health(info)
    if not health.get("valid"):
        return base(True, "check", "broken", str(health.get("message", "Vita3K firmware is missing or invalid.")), details=health.get("details"))

    emit_progress(progress, 95, "Ready")
    return base(True, "check", "installed", f'Vita3K "{version}" is installed and valid with PS Vita firmware {info["Firmware"]["Main"]["Version"]}.', details={"module_version": module_version(info), "version": version, "build_number": info["Source"]["BuildNumber"], "build_commit": info["Source"]["ShortCommit"], "path": str(EXECUTABLE_PATH), "portable": True, "portable_root": str(PORTABLE_DIR), "config": str(CONFIG_PATH), "firmware_version": info["Firmware"]["Main"]["Version"], "font_package_installed": True, "source": info["Source"]["OfficialRepository"]})


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return Vita3KInstaller.install(progress=progress)


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return Vita3KUninstall.uninstall(progress=progress)


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return Vita3KRepair.repair(progress=progress)


def update(progress: ProgressCallback | None = None) -> dict[str, Any]:
    current = check(progress=scaled_progress(progress, 0, 20))
    if not current.get("success") and current.get("state") == "unsupported":
        current["operation"] = "update"
        return current
    info = load_info()
    version = emulator_version(info)
    if current.get("state") == "installed":
        return base(True, "update", "already_current", f'Vita3K "{version}" with PS Vita firmware {info["Firmware"]["Main"]["Version"]} is already the module-pinned environment.', details=current.get("details"))
    repaired = Vita3KRepair.repair(progress=scaled_progress(progress, 20, 98))
    repaired["operation"] = "update"
    repaired["state"] = "updated" if repaired.get("success") else "update_failed"
    if repaired.get("success"):
        repaired["message"] = f'Vita3K was updated to pinned build "{version}" with PS Vita firmware {info["Firmware"]["Main"]["Version"]}.'
    return repaired


def write_record(record: dict[str, Any]) -> None:
    print(json.dumps(record, ensure_ascii=False, default=str, separators=(",", ":")), flush=True)


def stream_progress(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
    write_record({"type": "progress", "percent": percent, "stage": stage, "message": message})


def run_cli() -> int:
    raw_args = sys.argv[1:]
    json_flags = [arg for arg in raw_args if arg.casefold() == "--json"]
    args = [arg for arg in raw_args if arg.casefold() != "--json"]
    operation = args[0].casefold() if len(args) == 1 else ""
    handlers = {"check": check, "install": install, "uninstall": uninstall, "repair": repair, "update": update}
    handler = handlers.get(operation)

    if len(json_flags) != 1 or handler is None:
        outcome = base(False, operation or "manager", "invalid_operation", "Vita3KManager requires one lifecycle operation: check, install, uninstall, repair, or update.", "invalid_operation")
    else:
        try:
            outcome = handler(progress=stream_progress)
        except Exception as exc:
            outcome = base(False, operation, f"{operation}_failed", f"Vita3KManager failed during {operation}.", "manager_exception", str(exc))

    write_record({"type": "result", "result": outcome})
    return 0 if outcome.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(run_cli())
