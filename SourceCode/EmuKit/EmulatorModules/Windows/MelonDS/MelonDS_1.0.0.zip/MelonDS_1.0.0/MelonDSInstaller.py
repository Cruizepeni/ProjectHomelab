from __future__ import annotations

import json
import shutil
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

from _MelonDSCommon import *


def result(success: bool, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {
        "success": success,
        "module": "melonds",
        "operation": "install",
        "state": state,
        "message": message,
        "details": details,
    }
    if error:
        value["error"] = error
    return value


def _lfs_pointer(path: Path) -> dict[str, Any] | None:
    try:
        if path.stat().st_size > 1024:
            return None
        lines = path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeDecodeError):
        return None
    if not lines or lines[0].strip() != "version https://git-lfs.github.com/spec/v1":
        return None
    oid = ""
    size = -1
    for line in lines[1:]:
        if line.startswith("oid sha256:"):
            oid = line.removeprefix("oid sha256:").strip().lower()
        elif line.startswith("size "):
            try:
                size = int(line.removeprefix("size ").strip())
            except ValueError:
                size = -1
    if len(oid) != 64 or size < 0:
        return None
    return {"sha256": oid, "size": size}


def _github_lfs_media_url(url: str) -> str | None:
    parsed = urllib.parse.urlsplit(url)
    if parsed.netloc.casefold() != "raw.githubusercontent.com":
        return None
    parts = parsed.path.lstrip("/").split("/")
    if len(parts) < 4:
        return None
    owner, repository, ref = parts[:3]
    resource_path = "/".join(parts[3:])
    return f"https://media.githubusercontent.com/media/{owner}/{repository}/{ref}/{resource_path}"


def _download_file(url: str, destination: Path, progress: ProgressCallback | None, start: int, end: int, stage: str, message: str, resolve_lfs: bool = True) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(url, headers={"User-Agent": "ProjectHomelab-EmuKit/1.0", "Accept": "*/*"})
    with urllib.request.urlopen(request, timeout=240) as response, destination.open("wb") as output:
        raw_total = response.headers.get("Content-Length")
        total = int(raw_total) if raw_total and raw_total.isdigit() else None
        tracked_total = total if total and total > 4096 else None
        received = 0
        emit_progress(progress, start, stage, message)
        while True:
            block = response.read(1024 * 1024)
            if not block:
                break
            output.write(block)
            received += len(block)
            if tracked_total:
                mapped = start + round((end - start) * received / tracked_total)
                emit_progress(progress, min(end, mapped), stage, message)
    pointer = _lfs_pointer(destination)
    if pointer is not None:
        if not resolve_lfs:
            raise ValueError(json.dumps({"git_lfs_pointer_unresolved": pointer, "url": url}, separators=(",", ":")))
        media_url = _github_lfs_media_url(url)
        if not media_url:
            raise ValueError(json.dumps({"git_lfs_pointer_without_media_url": pointer, "url": url}, separators=(",", ":")))
        _download_file(media_url, destination, progress, start, end, stage, message, resolve_lfs=False)
        return
    emit_progress(progress, end, stage, message)


def _fetch_json(url: str) -> dict[str, Any]:
    request = urllib.request.Request(url, headers={"User-Agent": "ProjectHomelab-EmuKit/1.0", "Accept": "application/json"})
    with urllib.request.urlopen(request, timeout=120) as response:
        value = json.loads(response.read().decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Remote JSON root must be an object.")
    return value


def _catalog_map(info: dict[str, Any]) -> dict[str, dict[str, Any]]:
    manifest_url = str(info["ResourceCatalog"]["ManifestURL"])
    catalog = _fetch_json(manifest_url)
    resources = catalog.get("resources")
    if not isinstance(resources, list):
        raise ValueError("EmuKit resource catalog does not contain a resources list.")
    result_map: dict[str, dict[str, Any]] = {}
    for entry in resources:
        if isinstance(entry, dict) and isinstance(entry.get("path"), str):
            result_map[str(entry["path"])] = entry
    return result_map


def _validate_catalog(info: dict[str, Any]) -> None:
    catalog = _catalog_map(info)
    mismatches: list[dict[str, Any]] = []
    for spec in resource_specs(info):
        path = str(spec["Path"])
        entry = catalog.get(path)
        if entry is None:
            mismatches.append({"path": path, "error": "missing_from_catalog"})
            continue
        expected_size = int(spec["Size"])
        expected_sha = str(spec["SHA256"]).lower()
        actual_size = int(entry.get("size", -1))
        actual_sha = str(entry.get("sha256", "")).lower()
        if actual_size != expected_size or actual_sha != expected_sha:
            mismatches.append({
                "path": path,
                "expected_size": expected_size,
                "catalog_size": actual_size,
                "expected_sha256": expected_sha,
                "catalog_sha256": actual_sha,
            })
    if mismatches:
        raise ValueError(json.dumps({"resource_catalog_mismatches": mismatches}, separators=(",", ":")))


def _safe_extract(archive: zipfile.ZipFile, destination: Path) -> None:
    root = destination.resolve()
    for member in archive.infolist():
        path = PurePosixPath(member.filename.replace("\\", "/"))
        if path.is_absolute() or ".." in path.parts:
            raise ValueError(f'Unsafe archive member: "{member.filename}"')
        target = (destination / Path(*path.parts)).resolve()
        if target != root and root not in target.parents:
            raise ValueError(f'Unsafe archive member: "{member.filename}"')
    archive.extractall(destination)


def _copy_distribution(source_root: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    for item in source_root.iterdir():
        target = destination / item.name
        if item.is_dir():
            shutil.copytree(item, target)
        else:
            shutil.copy2(item, target)


def _resource_stages(resource_type: str) -> tuple[str, str, str]:
    value = resource_type.casefold()
    if value == "firmware":
        return "Downloading Firmware", "Validating Firmware", "Installing Firmware"
    if value == "systemdata":
        return "Downloading System Data", "Validating System Data", "Installing System Data"
    return "Downloading Resources", "Validating Resources", "Installing Resources"


def _install_resources(info: dict[str, Any], temp_dir: Path, progress: ProgressCallback | None, start: int, end: int) -> list[dict[str, Any]]:
    specs = resource_specs(info)
    total_bytes = sum(int(spec["Size"]) for spec in specs)
    raw_base = str(info["ResourceCatalog"]["RawBaseURL"]).rstrip("/")
    completed = 0
    installed: list[dict[str, Any]] = []
    for index, spec in enumerate(specs):
        size = int(spec["Size"])
        span_start = start + round((end - start) * completed / total_bytes)
        span_end = start + round((end - start) * (completed + size) / total_bytes)
        span_end = max(span_start + 1, span_end)
        download_end = span_start + max(1, round((span_end - span_start) * 0.78))
        validate_end = download_end + max(1, round((span_end - span_start) * 0.08))
        validate_end = min(span_end, validate_end)
        download_stage, validate_stage, install_stage = _resource_stages(str(spec.get("Type", "Resources")))
        source_name = str(spec["SourceName"])
        encoded_path = urllib.parse.quote(str(spec["Path"]), safe="/")
        url = f"{raw_base}/{encoded_path}"
        download_path = temp_dir / "resources" / f"{index:02d}_{source_name}"
        _download_file(url, download_path, progress, span_start, download_end, download_stage, source_name)
        emit_progress(progress, validate_end, validate_stage, source_name)
        actual_size = download_path.stat().st_size
        actual_sha = hash_file(download_path).lower()
        expected_size = int(spec["Size"])
        expected_sha = str(spec["SHA256"]).lower()
        if actual_size != expected_size or actual_sha != expected_sha:
            raise ValueError(json.dumps({
                "resource": str(spec["Path"]),
                "expected_size": expected_size,
                "actual_size": actual_size,
                "expected_sha256": expected_sha,
                "actual_sha256": actual_sha,
            }, separators=(",", ":")))
        destination = Path(spec["RuntimePath"])
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(download_path, destination)
        emit_progress(progress, span_end, install_stage, str(spec["RuntimeName"]))
        installed.append({
            "path": str(spec["Path"]),
            "runtime": str(destination),
            "sha256": actual_sha,
            "mutable": bool(spec.get("MutableAtRuntime", False)),
        })
        completed += size
    return installed


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, "Checking Host")
    supported, reason = is_supported_host()
    if not supported:
        return result(False, "unsupported", reason or "melonDS is not supported on this host.", "unsupported_host")

    info = load_info()
    source = info["Source"]
    version = emulator_version(info)

    emit_progress(progress, 6, "Checking Release", str(source["Asset"]))
    expected_archive_size = int(source["Size"])
    expected_archive_sha = str(source["SHA256"]).lower()
    expected_executable_sha = str(source["ExecutableSHA256"]).lower()

    if EMULATOR_DIR.exists():
        return result(False, "install_failed", "The melonDS managed emulator directory already exists. Use repair for a clean reinstall.", "dependency_already_exists", {"path": str(EMULATOR_DIR)})

    emit_progress(progress, 8, "Preparing Install")
    EMULATOR_DIR.mkdir(parents=True, exist_ok=False)
    temp_dir = EMULATOR_DIR / ".install"
    extract_dir = temp_dir / "extracted"
    archive_path = temp_dir / str(source["Asset"])
    temp_dir.mkdir(parents=True, exist_ok=True)
    extract_dir.mkdir(parents=True, exist_ok=True)
    install_complete = False

    try:
        _download_file(str(source["DownloadURL"]), archive_path, progress, 10, 40, "Downloading Emulator", str(source["Asset"]))

        emit_progress(progress, 44, "Validating Emulator", str(source["Asset"]))
        actual_archive_size = archive_path.stat().st_size
        actual_archive_sha = hash_file(archive_path).lower()
        if actual_archive_size != expected_archive_size or actual_archive_sha != expected_archive_sha:
            return result(False, "invalid_download", "The downloaded melonDS archive failed validation.", "archive_validation_failed", {
                "expected_size": expected_archive_size,
                "actual_size": actual_archive_size,
                "expected_sha256": expected_archive_sha,
                "actual_sha256": actual_archive_sha,
            })

        try:
            with zipfile.ZipFile(archive_path, "r") as archive:
                bad_member = archive.testzip()
                if bad_member is not None:
                    return result(False, "extract_failed", f'The official melonDS ZIP failed its internal CRC check at "{bad_member}".', "archive_crc_failed", {"member": bad_member})
                emit_progress(progress, 48, "Extracting Emulator", str(source["Asset"]))
                _safe_extract(archive, extract_dir)
        except (zipfile.BadZipFile, ValueError) as exc:
            return result(False, "extract_failed", "The downloaded melonDS archive could not be safely extracted.", "invalid_archive", str(exc))

        matches = [path for path in extract_dir.rglob("melonDS.exe") if path.is_file()]
        if len(matches) != 1:
            return result(False, "install_failed", "The melonDS archive did not contain exactly one melonDS.exe.", "executable_validation_failed", {"matches": [str(path) for path in matches]})

        distribution_root = matches[0].parent
        actual_upstream_executable_sha = hash_file(matches[0]).lower()
        if actual_upstream_executable_sha != expected_executable_sha:
            return result(False, "install_failed", "The melonDS executable does not match the module-pinned official build.", "executable_hash_mismatch", {
                "expected_sha256": expected_executable_sha,
                "actual_sha256": actual_upstream_executable_sha,
            })

        emit_progress(progress, 52, "Installing Emulator", "Nintendo DS profile")
        _copy_distribution(distribution_root, DS_DIR)
        emit_progress(progress, 57, "Installing Emulator", "Nintendo DSi profile")
        _copy_distribution(distribution_root, DSI_DIR)
        DS_PORTABLE_DIR.mkdir(parents=True, exist_ok=True)
        DSI_PORTABLE_DIR.mkdir(parents=True, exist_ok=True)

        if not DS_EXECUTABLE.is_file() or not DSI_EXECUTABLE.is_file():
            return result(False, "install_failed", "melonDS profile installation completed but one or more launch executables are missing.", "post_install_validation_failed", {"ds": str(DS_EXECUTABLE), "dsi": str(DSI_EXECUTABLE)})

        emit_progress(progress, 60, "Preparing Resources", "EmuKit resource catalog")
        try:
            _validate_catalog(info)
        except Exception as exc:
            return result(False, "resources_invalid", "The controlled EmuKit resource catalog does not match the melonDS module requirements.", "resource_catalog_validation_failed", str(exc))

        installed_resources = _install_resources(info, temp_dir, progress, 62, 91)

        emit_progress(progress, 93, "Configuring Emulator", "Portable DS and DSi profiles")
        configure_profiles()

        emit_progress(progress, 96, "Writing Receipt", ".emukit_install.json")
        receipt = {
            "EmuKitModule": "melonds",
            "ModuleVersion": module_version(info),
            "Name": info["Name"],
            "Version": version,
            "ReleaseTag": source["ReleaseTag"],
            "ReleaseCommit": source["ReleaseCommit"],
            "Asset": source["Asset"],
            "DownloadURL": source["DownloadURL"],
            "ArchiveSHA256": actual_archive_sha,
            "ExecutableSHA256": actual_upstream_executable_sha,
            "SourceRepository": source["Repository"],
            "Systems": ["nintendods", "nintendodsi"],
            "Resources": installed_resources,
            "InstalledAtUTC": datetime.now(timezone.utc).isoformat(),
        }
        write_receipt(receipt)

        emit_progress(progress, 98, "Verifying Installation", "Managed files and profiles")
        runtime = runtime_resource_status()
        configs = profile_config_status()
        ds_hash = hash_file(DS_EXECUTABLE).lower()
        dsi_hash = hash_file(DSI_EXECUTABLE).lower()
        if not runtime["ready"] or not configs["ready"] or ds_hash != expected_executable_sha or dsi_hash != expected_executable_sha:
            return result(False, "install_failed", "melonDS installation completed but final verification failed.", "post_install_validation_failed", {
                "runtime_resources": runtime,
                "profiles": configs,
                "ds_sha256": ds_hash,
                "dsi_sha256": dsi_hash,
                "expected_executable_sha256": expected_executable_sha,
            })

        install_complete = True
        return result(True, "installed", f'melonDS "{version}" installed successfully with Nintendo DS and Nintendo DSi portable profiles.', details={
            "version": version,
            "systems": ["nintendods", "nintendodsi"],
            "ds_path": str(DS_EXECUTABLE),
            "dsi_path": str(DSI_EXECUTABLE),
            "archive_sha256": actual_archive_sha,
            "executable_sha256": actual_upstream_executable_sha,
        })
    except urllib.error.HTTPError as exc:
        return result(False, "download_failed", "A required melonDS or EmuKit resource download failed.", "download_http_error", {"http_status": exc.code, "url": getattr(exc, "url", None)})
    except urllib.error.URLError as exc:
        return result(False, "download_failed", "A required melonDS or EmuKit resource download failed.", "download_failed", str(exc))
    except PermissionError as exc:
        return result(False, "install_failed", "melonDS installation could not write one or more required files.", "permission_denied", str(exc))
    except Exception as exc:
        return result(False, "install_failed", "melonDS installation failed unexpectedly.", "install_exception", str(exc))
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        if not install_complete:
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
