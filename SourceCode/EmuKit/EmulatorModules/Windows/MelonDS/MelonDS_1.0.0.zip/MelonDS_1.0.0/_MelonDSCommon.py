from __future__ import annotations

import hashlib
import json
import platform
import re
import sys
import tomllib
from pathlib import Path
from typing import Any, Callable

MODULE_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
INFO_PATH = MODULE_DIR / "EmuKitMelonDSInfo.json"
ROOT_MARKER = ".ProjectHomelabRoot"
ProgressCallback = Callable[[int | None, str | None, str | None], None]


def resolve_root() -> Path:
    current = MODULE_DIR.resolve()
    for candidate in (current, *current.parents):
        if (candidate / ROOT_MARKER).is_file():
            return candidate
    for candidate in (current, *current.parents):
        if ((candidate / "EmuKit.py").is_file() or (candidate / "EmuKit.exe").is_file()) and (candidate / "EmuKitModules").is_dir():
            return candidate
    if MODULE_DIR.parent.name.casefold() == "emukitmodules":
        return MODULE_DIR.parent.parent
    return MODULE_DIR.parent


ROOT = resolve_root()
EMULATOR_DIR = ROOT / "Emulators" / "MelonDS"
DS_DIR = EMULATOR_DIR / "NintendoDS"
DSI_DIR = EMULATOR_DIR / "NintendoDSi"
DS_EXECUTABLE = DS_DIR / "melonDS.exe"
DSI_EXECUTABLE = DSI_DIR / "melonDS.exe"
DS_PORTABLE_DIR = DS_DIR / "portable"
DSI_PORTABLE_DIR = DSI_DIR / "portable"
DS_CONFIG_PATH = DS_PORTABLE_DIR / "melonDS.toml"
DSI_CONFIG_PATH = DSI_PORTABLE_DIR / "melonDS.toml"
DS_SYSTEM_DIR = DS_DIR / "SystemFiles"
DSI_SYSTEM_DIR = DSI_DIR / "SystemFiles"
RECEIPT_PATH = EMULATOR_DIR / ".emukit_install.json"
CACHE_ROOT = ROOT / "Appdata" / "Cache" / "EmuKit" / "MelonDS"


def load_info() -> dict[str, Any]:
    return json.loads(INFO_PATH.read_text(encoding="utf-8"))


def module_version(info: dict[str, Any] | None = None) -> str:
    source = info if isinstance(info, dict) else load_info()
    return str(source["ModuleVersion"])


def emulator_version(info: dict[str, Any] | None = None) -> str:
    source = info if isinstance(info, dict) else load_info()
    return str(source["EmulatorVersion"])


def emit_progress(progress: ProgressCallback | None, percent: int | None, stage: str | None, message: str | None = None) -> None:
    if progress is not None:
        progress(percent, stage, message)


def scaled_progress(progress: ProgressCallback | None, start: int, end: int) -> ProgressCallback | None:
    if progress is None:
        return None

    def callback(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
        if percent is None:
            mapped = None
        else:
            bounded = max(0, min(100, int(percent)))
            mapped = start + round((end - start) * bounded / 100)
        progress(mapped, stage, message)

    return callback


def is_supported_host() -> tuple[bool, str | None]:
    if platform.system().casefold() != "windows":
        return False, "MelonDS 1.0.0 currently supports Windows only."
    if platform.machine().casefold() not in {"amd64", "x86_64"}:
        return False, f'MelonDS 1.0.0 requires Windows x86_64. Current architecture: "{platform.machine()}".'
    return True, None


def hash_file(path: Path, algorithm: str = "sha256") -> str:
    digest = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_receipt() -> dict[str, Any] | None:
    try:
        value = json.loads(RECEIPT_PATH.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def write_receipt(value: dict[str, Any]) -> None:
    RECEIPT_PATH.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def resource_specs(info: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    source = info if isinstance(info, dict) else load_info()
    result: list[dict[str, Any]] = []
    for system_name, group in source.get("Resources", {}).items():
        runtime_root = EMULATOR_DIR / str(group["RuntimeDirectory"])
        for source_name, spec in group.get("Files", {}).items():
            value = dict(spec)
            value["System"] = system_name
            value["SourceName"] = source_name
            value["RuntimePath"] = runtime_root / str(spec["RuntimeName"])
            result.append(value)
    return result


def _valid_dsi_nand(path: Path) -> bool:
    try:
        if path.stat().st_size != 251658304:
            return False
        with path.open("rb") as handle:
            handle.seek(-64, 2)
            footer = handle.read(64)
        return footer.startswith(b"DSi eMMC CID/CPU")
    except OSError:
        return False


def runtime_resource_status() -> dict[str, Any]:
    systems: dict[str, Any] = {}
    all_ready = True
    for spec in resource_specs():
        system_name = str(spec["System"])
        entry = systems.setdefault(system_name, {"ready": True, "files": []})
        path = Path(spec["RuntimePath"])
        item: dict[str, Any] = {
            "name": str(spec["RuntimeName"]),
            "path": str(path),
            "ready": False,
            "mutable": bool(spec.get("MutableAtRuntime", False)),
        }
        valid = False
        if path.is_file():
            size = path.stat().st_size
            item["size"] = size
            runtime_name = str(spec["RuntimeName"])
            if runtime_name == "firmware.bin":
                valid = size in {131072, 262144, 524288}
            elif runtime_name == "dsi_firmware.bin":
                valid = size == 131072
            elif runtime_name == "dsi_nand.bin":
                valid = _valid_dsi_nand(path)
            elif size == int(spec["Size"]):
                actual = hash_file(path).lower()
                item["sha256"] = actual
                valid = actual == str(spec["SHA256"]).lower()
        item["ready"] = valid
        item["state"] = "ready" if valid else ("invalid" if path.exists() else "missing")
        entry["files"].append(item)
        entry["ready"] = bool(entry["ready"]) and valid
        all_ready = all_ready and valid
    return {"ready": all_ready, "systems": systems}


def mutable_runtime_files() -> list[Path]:
    return [Path(spec["RuntimePath"]) for spec in resource_specs() if bool(spec.get("MutableAtRuntime", False))]


def valid_mutable_runtime_file(path: Path) -> bool:
    if path == DS_SYSTEM_DIR / "firmware.bin":
        return path.is_file() and path.stat().st_size in {131072, 262144, 524288}
    if path == DSI_SYSTEM_DIR / "dsi_firmware.bin":
        return path.is_file() and path.stat().st_size == 131072
    if path == DSI_SYSTEM_DIR / "dsi_nand.bin":
        return path.is_file() and _valid_dsi_nand(path)
    return False


def _toml_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    return json.dumps(str(value), ensure_ascii=False)


def _upsert_toml(path: Path, required: dict[str, dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = path.read_text(encoding="utf-8").splitlines() if path.is_file() else []
    seen_sections: set[str] = set()
    seen_keys: dict[str, set[str]] = {section: set() for section in required}
    output: list[str] = []
    current = ""
    key_pattern = re.compile(r"^\s*([A-Za-z0-9_.-]+)\s*=")

    def append_missing(section: str) -> None:
        if section not in required:
            return
        for key, value in required[section].items():
            if key not in seen_keys[section]:
                output.append(f"{key} = {_toml_value(value)}")
                seen_keys[section].add(key)

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            append_missing(current)
            current = stripped[1:-1].strip()
            seen_sections.add(current)
            output.append(line)
            continue
        match = key_pattern.match(line)
        if current in required and match and match.group(1) in required[current]:
            key = match.group(1)
            output.append(f"{key} = {_toml_value(required[current][key])}")
            seen_keys[current].add(key)
        else:
            output.append(line)

    append_missing(current)

    for section, values in required.items():
        if section in seen_sections:
            continue
        if output and output[-1].strip():
            output.append("")
        output.append(f"[{section}]")
        for key, value in values.items():
            output.append(f"{key} = {_toml_value(value)}")

    path.write_text("\n".join(output).rstrip() + "\n", encoding="utf-8")


def _path_value(path: Path) -> str:
    return path.resolve().as_posix()


def configure_profiles() -> None:
    _upsert_toml(
        DS_CONFIG_PATH,
        {
            "Emu": {
                "ConsoleType": 0,
                "DirectBoot": True,
                "ExternalBIOSEnable": True,
            },
            "DS": {
                "BIOS7Path": _path_value(DS_SYSTEM_DIR / "bios7.bin"),
                "BIOS9Path": _path_value(DS_SYSTEM_DIR / "bios9.bin"),
                "FirmwarePath": _path_value(DS_SYSTEM_DIR / "firmware.bin"),
            },
        },
    )
    _upsert_toml(
        DSI_CONFIG_PATH,
        {
            "Emu": {
                "ConsoleType": 1,
                "DirectBoot": True,
            },
            "DSi": {
                "ExternalBIOSEnable": True,
                "BIOS7Path": _path_value(DSI_SYSTEM_DIR / "dsi_bios7.bin"),
                "BIOS9Path": _path_value(DSI_SYSTEM_DIR / "dsi_bios9.bin"),
                "FirmwarePath": _path_value(DSI_SYSTEM_DIR / "dsi_firmware.bin"),
                "NANDPath": _path_value(DSI_SYSTEM_DIR / "dsi_nand.bin"),
            },
            "DSi.DSP": {
                "HLE": True,
            },
        },
    )


def _norm_path(value: Any) -> str:
    return str(value).replace("\\", "/").rstrip("/").casefold()


def profile_config_status() -> dict[str, Any]:
    checks = {
        "NintendoDS": (
            DS_CONFIG_PATH,
            {
                "Emu": {
                    "ConsoleType": 0,
                    "DirectBoot": True,
                    "ExternalBIOSEnable": True,
                },
                "DS": {
                    "BIOS7Path": _path_value(DS_SYSTEM_DIR / "bios7.bin"),
                    "BIOS9Path": _path_value(DS_SYSTEM_DIR / "bios9.bin"),
                    "FirmwarePath": _path_value(DS_SYSTEM_DIR / "firmware.bin"),
                },
            },
        ),
        "NintendoDSi": (
            DSI_CONFIG_PATH,
            {
                "Emu": {
                    "ConsoleType": 1,
                    "DirectBoot": True,
                },
                "DSi": {
                    "ExternalBIOSEnable": True,
                    "BIOS7Path": _path_value(DSI_SYSTEM_DIR / "dsi_bios7.bin"),
                    "BIOS9Path": _path_value(DSI_SYSTEM_DIR / "dsi_bios9.bin"),
                    "FirmwarePath": _path_value(DSI_SYSTEM_DIR / "dsi_firmware.bin"),
                    "NANDPath": _path_value(DSI_SYSTEM_DIR / "dsi_nand.bin"),
                },
                "DSi.DSP": {
                    "HLE": True,
                },
            },
        ),
    }
    result: dict[str, Any] = {}
    all_ready = True
    for name, (path, expected) in checks.items():
        ready = True
        details: list[dict[str, Any]] = []
        try:
            with path.open("rb") as handle:
                data = tomllib.load(handle)
        except Exception as exc:
            result[name] = {"ready": False, "path": str(path), "error": str(exc)}
            all_ready = False
            continue
        for section, values in expected.items():
            table: Any = data
            for part in section.split("."):
                table = table.get(part, {}) if isinstance(table, dict) else {}
            for key, expected_value in values.items():
                actual = table.get(key) if isinstance(table, dict) else None
                match = _norm_path(actual) == _norm_path(expected_value) if key.endswith("Path") else actual == expected_value
                details.append({"section": section, "key": key, "ready": match})
                ready = ready and match
        result[name] = {"ready": ready, "path": str(path), "checks": details}
        all_ready = all_ready and ready
    return {"ready": all_ready, "profiles": result}
