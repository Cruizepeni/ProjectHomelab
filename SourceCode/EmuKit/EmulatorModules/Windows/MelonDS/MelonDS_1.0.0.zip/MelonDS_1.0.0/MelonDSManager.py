from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

MODULE_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
if str(MODULE_DIR) not in sys.path:
    sys.path.insert(0, str(MODULE_DIR))

from _MelonDSCommon import *
import MelonDSInstaller
import MelonDSRepair
import MelonDSUninstall

MODULE_ID = "melonds"
MODULE_NAME = "MelonDS"


def base(success: bool, operation: str, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {
        "success": success,
        "module": MODULE_ID,
        "operation": operation,
        "state": state,
        "message": message,
        "details": details,
    }
    if error:
        value["error"] = error
    return value


def check(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 5, "Checking Host")
    supported, reason = is_supported_host()
    if not supported:
        return base(False, "check", "unsupported", reason or "MelonDS is not supported on this host.", "unsupported_host")
    info = load_info()
    source = info["Source"]
    version = emulator_version(info)
    if not EMULATOR_DIR.exists():
        return base(True, "check", "missing", "MelonDS is not installed.", details={"expected_path": str(EMULATOR_DIR)})

    emit_progress(progress, 25, "Verifying Installation", "Managed executables")
    missing = [str(path) for path in (DS_EXECUTABLE, DSI_EXECUTABLE) if not path.is_file()]
    if missing:
        return base(True, "check", "broken", "The MelonDS installation is missing one or more managed profile executables.", details={"missing": missing})

    emit_progress(progress, 40, "Verifying Installation", "Installation receipt")
    receipt = read_receipt()
    if receipt is None:
        return base(True, "check", "broken", "MelonDS is present but its EmuKit installation receipt is missing or invalid.", details={"receipt": str(RECEIPT_PATH)})
    expected_receipt = {
        "ModuleVersion": module_version(info),
        "Version": version,
        "ReleaseTag": str(source["ReleaseTag"]),
        "ReleaseCommit": str(source["ReleaseCommit"]),
        "Asset": str(source["Asset"]),
        "ArchiveSHA256": str(source["SHA256"]).lower(),
    }
    receipt_values = {
        "ModuleVersion": str(receipt.get("ModuleVersion", "")),
        "Version": str(receipt.get("Version", "")),
        "ReleaseTag": str(receipt.get("ReleaseTag", "")),
        "ReleaseCommit": str(receipt.get("ReleaseCommit", "")),
        "Asset": str(receipt.get("Asset", "")),
        "ArchiveSHA256": str(receipt.get("ArchiveSHA256", "")).lower(),
    }
    if receipt_values != expected_receipt:
        return base(True, "check", "broken", "The MelonDS installation receipt does not match this module's pinned build.", details={"installed": receipt_values, "expected": expected_receipt})

    emit_progress(progress, 55, "Verifying Installation", "Executable integrity")
    expected_executable = str(source.get("ExecutableSHA256", "")).lower()
    try:
        ds_hash = hash_file(DS_EXECUTABLE).lower()
        dsi_hash = hash_file(DSI_EXECUTABLE).lower()
    except OSError as exc:
        return base(True, "check", "broken", "One or more MelonDS executables could not be read for integrity validation.", details=str(exc))
    if not expected_executable or ds_hash != expected_executable or dsi_hash != expected_executable:
        return base(True, "check", "broken", "One or more MelonDS profile executables do not match the pinned official build.", details={"expected_sha256": expected_executable or None, "ds_sha256": ds_hash, "dsi_sha256": dsi_hash})

    emit_progress(progress, 72, "Verifying Installation", "Firmware and system data")
    runtime = runtime_resource_status()
    if not runtime["ready"]:
        return base(True, "check", "broken", "MelonDS is installed, but one or more managed Nintendo DS or Nintendo DSi resources are missing or invalid.", details={"runtime_resources": runtime})

    emit_progress(progress, 88, "Verifying Installation", "Portable profiles")
    configs = profile_config_status()
    if not configs["ready"]:
        return base(True, "check", "broken", "MelonDS is installed, but one or more portable profiles are not configured for the managed system files.", details={"profiles": configs, "runtime_resources": runtime})

    emit_progress(progress, 98, "Verifying Installation", "Ready")
    return base(
        True,
        "check",
        "installed",
        f'MelonDS "{version}" is installed and valid for Nintendo DS and Nintendo DSi.',
        details={
            "module_version": module_version(info),
            "version": version,
            "systems": ["nintendods", "nintendodsi"],
            "ds_path": str(DS_EXECUTABLE),
            "dsi_path": str(DSI_EXECUTABLE),
            "profiles": configs,
            "runtime_resources": runtime,
        },
    )


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return MelonDSInstaller.install(progress=progress)


def uninstall(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return MelonDSUninstall.uninstall(progress=progress)


def repair(progress: ProgressCallback | None = None) -> dict[str, Any]:
    return MelonDSRepair.repair(progress=progress)


def update(progress: ProgressCallback | None = None) -> dict[str, Any]:
    current = check(progress=scaled_progress(progress, 0, 20))
    if not current.get("success") and current.get("state") == "unsupported":
        current["operation"] = "update"
        return current
    if current.get("state") == "installed":
        return base(
            True,
            "update",
            "already_current",
            f'MelonDS "{emulator_version()}" is already the module-pinned version.',
            details=current.get("details"),
        )
    repaired = MelonDSRepair.repair(progress=scaled_progress(progress, 20, 98))
    repaired["operation"] = "update"
    repaired["state"] = "updated" if repaired.get("success") else "update_failed"
    if repaired.get("success"):
        repaired["message"] = f'MelonDS was updated to pinned version "{emulator_version()}".'
    return repaired


def _write_record(record: dict[str, Any]) -> None:
    print(json.dumps(record, ensure_ascii=False, default=str, separators=(",", ":")), flush=True)


def _stream_progress(percent: int | None = None, stage: str | None = None, message: str | None = None) -> None:
    _write_record({"type": "progress", "percent": percent, "stage": stage, "message": message})


def _run_cli() -> int:
    raw_args = sys.argv[1:]
    json_flags = [arg for arg in raw_args if arg.casefold() == "--json"]
    args = [arg for arg in raw_args if arg.casefold() != "--json"]
    operation = args[0].casefold() if len(args) == 1 else ""
    handlers = {
        "check": check,
        "install": install,
        "uninstall": uninstall,
        "repair": repair,
        "update": update,
    }
    handler = handlers.get(operation)
    if len(json_flags) != 1 or handler is None:
        result = base(
            False,
            operation or "manager",
            "invalid_operation",
            "MelonDSManager requires one lifecycle operation: check, install, uninstall, repair, or update.",
            "invalid_operation",
        )
    else:
        try:
            result = handler(progress=_stream_progress)
        except Exception as exc:
            result = base(
                False,
                operation,
                f"{operation}_failed",
                f"MelonDSManager failed during {operation}.",
                "manager_exception",
                str(exc),
            )
    _write_record({"type": "result", "result": result})
    return 0 if result.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(_run_cli())
