from __future__ import annotations

import json
import shutil
import urllib.error
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from _XemuCommon import *


def result(success: bool, state: str, message: str, error: str | None = None, details: Any = None) -> dict[str, Any]:
    value = {"success": success, "module": "xemu", "operation": "install", "state": state, "message": message, "details": details}
    if error:
        value["error"] = error
    return value


def download_file(url: str, destination: Path, expected_sha256: str, expected_size: int | None, progress: ProgressCallback | None = None, stage: str = "Downloading Emulator", validation_stage: str = "Validating Emulator") -> dict[str, Any] | None:
    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
        request = urllib.request.Request(url, headers={"User-Agent": "ProjectHomelab-EmuKit-Xemu/1.0.0"})
        with urllib.request.urlopen(request, timeout=90) as response, destination.open("wb") as output:
            raw_length = response.headers.get("Content-Length")
            total = int(raw_length) if raw_length and raw_length.isdigit() else expected_size
            downloaded = 0
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)
                downloaded += len(chunk)
                percent = min(100, int(downloaded * 100 / total)) if total else None
                emit_progress(progress, percent, stage, destination.name)
        emit_progress(progress, 100, stage, destination.name)
        emit_progress(progress, 100, validation_stage, destination.name)
        if expected_size is not None and destination.stat().st_size != int(expected_size):
            return result(False, "download_failed", "A downloaded file failed size validation.", "download_size_mismatch", {"url": url, "expected_size": expected_size, "actual_size": destination.stat().st_size})
        actual = hash_file(destination, "sha256").lower()
        if actual != expected_sha256.lower():
            return result(False, "download_failed", "A downloaded file failed SHA-256 validation.", "download_hash_mismatch", {"url": url, "expected_sha256": expected_sha256.lower(), "actual_sha256": actual})
        return None
    except urllib.error.HTTPError as exc:
        return result(False, "download_failed", "A required file could not be downloaded.", "download_http_error", {"url": url, "http_status": exc.code})
    except Exception as exc:
        return result(False, "download_failed", "A required file could not be downloaded.", "download_failed", {"url": url, "exception": str(exc)})


def stage_resources(info: dict[str, Any], destination: Path, progress: ProgressCallback | None = None):
    emit_progress(progress, 2, "Preparing Resources")
    try:
        catalog = load_resource_catalog(info)
    except Exception as exc:
        return None, result(False, "resource_failed", "The EmuKit resource catalogue could not be loaded.", "resource_catalog_unavailable", str(exc))

    resources = info["Resources"]
    specifications: list[tuple[str, dict[str, Any]]] = []
    for bios in resources["BIOS"]["Accepted"]:
        specifications.append(("bios", bios))
    specifications.append(("boot", resources["BootROM"]))
    specifications.append(("hdd", resources["HardDisk"]))

    try:
        for _, specification in specifications:
            validate_catalog_entry(catalog, specification)
    except Exception as exc:
        return None, result(False, "resource_failed", "A required Xbox resource no longer matches the Xemu module contract.", "resource_catalog_mismatch", str(exc))

    staged: dict[str, Any] = {"bios": []}
    steps = len(specifications)
    for index, (kind, specification) in enumerate(specifications):
        start = round(index * 100 / steps)
        end = round((index + 1) * 100 / steps)
        target = destination / kind / Path(str(specification["Path"])).name
        error = download_file(
            resource_url(info, str(specification["Path"])),
            target,
            str(specification["SHA256"]),
            int(specification["Size"]),
            scaled_progress(progress, start, end),
            "Downloading Resources",
            "Validating Resources",
        )
        if error:
            return None, error
        if kind == "bios":
            staged["bios"].append(target)
        else:
            staged[kind] = target

    boot_md5 = hash_file(staged["boot"], "md5").lower()
    expected_md5 = str(resources["BootROM"]["MD5"]).lower()
    known_bad = str(resources["BootROM"].get("KnownBadMD5", "")).lower()
    if boot_md5 == known_bad:
        return None, result(False, "resource_failed", "The downloaded MCPX Boot ROM matches Xemu's known bad dump.", "known_bad_mcpx", {"md5": boot_md5})
    if boot_md5 != expected_md5:
        return None, result(False, "resource_failed", "The downloaded MCPX Boot ROM failed MD5 validation.", "invalid_mcpx", {"md5": boot_md5, "expected_md5": expected_md5})

    return staged, None


def safe_extract(archive_path: Path, destination: Path) -> None:
    destination = destination.resolve()
    with zipfile.ZipFile(archive_path) as archive:
        for member in archive.infolist():
            target = (destination / member.filename).resolve()
            if target != destination and destination not in target.parents:
                raise ValueError("Archive contains an unsafe path.")
        archive.extractall(destination)


def copy_resources(info: dict[str, Any], staged: dict[str, Any], progress: ProgressCallback | None = None) -> tuple[str, list[str]]:
    INSTALLED_BOOT_ROM.parent.mkdir(parents=True, exist_ok=True)
    INSTALLED_HDD.parent.mkdir(parents=True, exist_ok=True)
    INSTALLED_BIOS_DIR.mkdir(parents=True, exist_ok=True)

    operations = [(staged["boot"], INSTALLED_BOOT_ROM), (staged["hdd"], INSTALLED_HDD)]
    operations.extend((source, INSTALLED_BIOS_DIR / source.name) for source in staged["bios"])
    copied: list[str] = []
    total = len(operations)
    for index, (source, target) in enumerate(operations):
        percent = round(index * 100 / total) if total else 100
        emit_progress(progress, percent, "Installing Resources", target.name)
        shutil.copy2(source, target)
        if target.parent == INSTALLED_BIOS_DIR:
            copied.append(target.name)
    if operations:
        emit_progress(progress, 100, "Installing Resources", operations[-1][1].name)

    preferred = str(info["Resources"]["BIOS"]["Preferred"])
    selected = preferred if preferred in copied else copied[0]
    return selected, copied


def write_config(selected_bios: str) -> None:
    paths = expected_config_paths(selected_bios)
    text = (
        "[general]\n"
        "show_welcome = false\n\n"
        "[sys.files]\n"
        f"bootrom_path = {toml_literal(paths['bootrom_path'])}\n"
        f"flashrom_path = {toml_literal(paths['flashrom_path'])}\n"
        f"eeprom_path = {toml_literal(paths['eeprom_path'])}\n"
        f"hdd_path = {toml_literal(paths['hdd_path'])}\n"
    )
    CONFIG_PATH.write_text(text, encoding="utf-8")


def install(progress: ProgressCallback | None = None) -> dict[str, Any]:
    emit_progress(progress, 3, "Checking Host")
    supported, reason = is_supported_host()
    if not supported:
        return result(False, "unsupported", reason or "Unsupported host.", "unsupported_host")

    info = load_info()
    version = emulator_version(info)

    if EMULATOR_DIR.exists():
        return result(False, "install_failed", "The Xemu emulator directory already exists. Use repair for a clean reinstall.", "emulator_already_exists", {"path": str(EMULATOR_DIR)})

    EMULATOR_DIR.mkdir(parents=True)
    temp = EMULATOR_DIR / ".install"
    resource_stage = temp / "resources"
    extract = temp / "extracted"
    archive_path = temp / str(info["Source"]["Asset"])
    resource_stage.mkdir(parents=True)
    extract.mkdir()

    try:
        emit_progress(progress, 7, "Downloading Resources", f'{len(info["Resources"]["BIOS"]["Accepted"]) + 2} managed files')
        staged, error = stage_resources(info, resource_stage, scaled_progress(progress, 7, 37))
        if error:
            return error

        emit_progress(progress, 40, "Downloading Emulator", archive_path.name)
        source = info["Source"]
        error = download_file(
            str(source["DownloadURL"]),
            archive_path,
            str(source["SHA256"]),
            None,
            scaled_progress(progress, 40, 70),
        )
        if error:
            return error

        emit_progress(progress, 73, "Extracting Emulator", archive_path.name)
        try:
            safe_extract(archive_path, extract)
        except (zipfile.BadZipFile, ValueError) as exc:
            return result(False, "extract_failed", "The Xemu release archive could not be safely extracted.", "archive_extract_failed", str(exc))

        executable = next(extract.rglob("xemu.exe"), None)
        if executable is None or not executable.is_file():
            return result(False, "install_failed", "The Xemu archive was extracted but xemu.exe was not found.", "executable_validation_failed")

        emit_progress(progress, 80, "Installing Emulator", executable.name)
        for item in executable.parent.iterdir():
            target = EMULATOR_DIR / item.name
            if item.is_dir():
                shutil.copytree(item, target, dirs_exist_ok=True)
            else:
                shutil.copy2(item, target)

        if not EXECUTABLE_PATH.is_file():
            return result(False, "install_failed", "Xemu extraction completed but xemu.exe is missing.", "post_install_validation_failed")

        emit_progress(progress, 88, "Installing Resources", f'{len(info["Resources"]["BIOS"]["Accepted"]) + 2} managed files')
        selected, copied = copy_resources(info, staged, scaled_progress(progress, 88, 93))

        emit_progress(progress, 94, "Configuring Emulator", CONFIG_PATH.name)
        write_config(selected)

        receipt = {
            "EmuKitModule": "xemu",
            "ModuleVersion": module_version(info),
            "EmulatorVersion": version,
            "ReleaseTag": source["ReleaseTag"],
            "Asset": source["Asset"],
            "ArchiveSHA256": source["SHA256"],
            "SourceRepository": source["Repository"],
            "ResourceManifest": info["ResourceCatalog"]["ManifestURL"],
            "SelectedBIOS": selected,
            "InstalledResources": {
                "BIOS": copied,
                "BootROM": info["Resources"]["BootROM"]["Path"],
                "HardDisk": info["Resources"]["HardDisk"]["Path"]
            },
            "InstalledAtUTC": datetime.now(timezone.utc).isoformat()
        }
        emit_progress(progress, 97, "Writing Receipt", RECEIPT_PATH.name)
        RECEIPT_PATH.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")

        emit_progress(progress, 98, "Verifying Installation", EXECUTABLE_PATH.name)
        return result(
            True,
            "installed",
            f'Xemu "{version}" installed successfully.',
            details={
                "module_version": module_version(info),
                "version": version,
                "path": str(EXECUTABLE_PATH),
                "config": str(CONFIG_PATH),
                "selected_bios": selected,
                "copied_bios": copied,
                "boot_rom": str(INSTALLED_BOOT_ROM),
                "hard_disk": str(INSTALLED_HDD),
                "source": source["OfficialRepository"]
            },
        )
    except PermissionError as exc:
        return result(False, "install_failed", "Xemu installation could not write one or more required files.", "permission_denied", str(exc))
    except Exception as exc:
        return result(False, "install_failed", "Xemu installation failed unexpectedly.", "install_exception", str(exc))
    finally:
        shutil.rmtree(temp, ignore_errors=True)
        if not EXECUTABLE_PATH.exists():
            shutil.rmtree(EMULATOR_DIR, ignore_errors=True)
